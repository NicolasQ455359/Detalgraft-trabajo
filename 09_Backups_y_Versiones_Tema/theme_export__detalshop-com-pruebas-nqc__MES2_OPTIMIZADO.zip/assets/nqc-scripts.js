
    // CATÁLOGO OFICIAL COMPLETO DE DETALSHOP (486 PRODUCTOS CON FOTOS REALES)
        // PRODUCTO OFICIAL CON DESCUENTO REAL (IMAGEN 1)
    const TAPABOCA_DISCOUNT_PRODUCT = {
      "id": "905152021238",
      "title": "TAPABOCA CIRUGIA BLANCO CAJA X 50 UNDS - INVIMA - TERMOSELLADOS TRES CAPAS",
      "category": "Quimicos",
      "subcat": "Bioseguridad & Salud",
      "price": 9280,
      "compare_price": 25000,
      "sku": "021238",
      "invima": "INVIMA OK",
      "badge": "AHORRA $15.720 COP",
      "unit": "Caja x 50",
      "rating": "4.9 ★★★★★ (48 clientes B2B)",
      "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-0621.jpg?v=1789132618",
      "handle": "tapaboca-cirugia-blanco-caja-x-50-unds",
      "specs": {"ph": "Neutro", "bio": "Termosellado 3 Capas"},
      "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-0621.jpg?v=1789132618"]
    };
    let PRODUCTS_DATA = [TAPABOCA_DISCOUNT_PRODUCT, {"id": "9624669618434", "title": "WYPALL X-75 PLUS INDUSTRIAL AZUL ROLLO X 60 PAÑOS", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 44602, "compare_price": null, "sku": "011018", "invima": "INVIMA 2021618434", "badge": "Marca Líder", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-0621.jpg?v=1789132618", "handle": "untitled-sep11_08-16-11", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-0621.jpg?v=1789132618"]}, {"id": "9445152522498", "title": "STRECH TRANSPARENTE FILM 30 CM X 300 MTS CL 0.6", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 22747, "compare_price": null, "sku": "081551", "invima": "INVIMA 2021522498", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-8307.jpg?v=1780515130", "handle": "strech-transparente-film-30-cm-x-300-mts-cl-0-6", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-8307.jpg?v=1780515130"]}, {"id": "9402589610242", "title": "MEZCLADOR EL SOL REDONDO DE MADERA 14 CM PAQ. X 1000 UND", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 12187, "compare_price": null, "sku": "032554", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-8134.jpg?v=1779217128", "handle": "mezclador-el-sol-redondo-de-madera-14-cm-paq-x-1000-und", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-8134.jpg?v=1779217128"]}, {"id": "9370930839810", "title": "TECLADO USB GENIUS KB-118 NEGRO ESPAÑOL", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 39866, "compare_price": null, "sku": "051620", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7800_11ed8125-ff36-48d7-85fa-9d570c6f7674.jpg?v=1777409260", "handle": "teclado-usb-genius-kb-118-negro-espanol", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7800_11ed8125-ff36-48d7-85fa-9d570c6f7674.jpg?v=1777409260"]}, {"id": "9370620363010", "title": "SOBRE YOYO OFICIO VERTICAL AZUL OSCURO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 2213, "compare_price": null, "sku": "061205", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7799.jpg?v=1777398858", "handle": "sobre-yoyo-oficio-vertical-azul-oscuro", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7799.jpg?v=1777398858"]}, {"id": "9362319180034", "title": "GUANTE DOMESTICO NEGRO CAL. 18 TALLA 8 - LATEXPORT", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4828, "compare_price": null, "sku": "024130", "invima": "INVIMA 2021180034", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7661.jpg?v=1776702751", "handle": "guante-domestico-negro-cal-18-talla-8-latexport", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7661.jpg?v=1776702751"]}, {"id": "9315478044930", "title": "BOLSILLO LAMINACION CARTA PAQ X 100 CL. 5", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 65411, "compare_price": null, "sku": "059877", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Paquete", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7010.jpg?v=1773264390", "handle": "bolsillo-laminacion-carta-paq-x-100-cl-5", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7010.jpg?v=1773264390"]}, {"id": "9307433959682", "title": "JABON MANOS ESPUMA KLEENEX FOAM X 1000 ML SIN COLORANTES SIN AROMA", "category": "Aseo", "subcat": "Aseo Profesional", "price": 68425, "compare_price": null, "sku": "011141", "invima": "INVIMA 2021059682", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011141.jpg?v=1772549345", "handle": "jabon-manos-espuma-kleenex-foam-x-1000-ml-sin-colorantes-sin-aroma", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011141.jpg?v=1772549345"]}, {"id": "9307433206018", "title": "COMBO 1 DISPENSADOR (83454) + 1 ROLLO JUMBO MINI (71198) TORK", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 78723, "compare_price": null, "sku": "011112", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011112.jpg?v=1772549068", "handle": "pano-de-limpieza-larga-duracion-rojo-40x40x17-7-cm-paq-x-40-und-tork-copia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011112.jpg?v=1772549068"]}, {"id": "9307433042178", "title": "PAÑO DE LIMPIEZA LARGA DURACION ROJO 40X40X17.7 CM PAQ. X 40 UND - TORK", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 38426, "compare_price": null, "sku": "011131", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Paquete", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011131.jpg?v=1772548895", "handle": "pano-de-limpieza-larga-duracion-verde-40x40x17-7-cm-paq-x-40-und-tork-copia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011131.jpg?v=1772548895"]}, {"id": "9307432911106", "title": "PAÑO DE LIMPIEZA LARGA DURACION VERDE 40X40X17.7 CM PAQ. X 40 UND - TORK", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 38426, "compare_price": null, "sku": "011132", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Paquete", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011132.jpg?v=1772548819", "handle": "pano-de-limpieza-l-duracion-verde-40x40x17-7-cm-paq-x-40-und-tork", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011132.jpg?v=1772548819"]}, {"id": "9307432681730", "title": "PAÑO DE LIMPIEZA LARGA DURACION AZUL 40X40X17.7 CM PAQ. X 40 UND - TORK", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 38426, "compare_price": null, "sku": "011133", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Paquete", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011133.jpg?v=1772548736", "handle": "pano-de-limpieza-larga-duracion-azul-40x40x17-7-cm-paq-x-40-und-tork", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011133.jpg?v=1772548736"]}, {"id": "9307432354050", "title": "PAÑO DE LIMPIEZA LARGA DURACION AMARILLO 40X40X17.7 CM PQ. X 40 UND-TORK", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 38426, "compare_price": null, "sku": "011130", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011130.jpg?v=1772548656", "handle": "pano-de-limpieza-larga-duracion-amarillo-40x40x17-7-cm-pq-x-40-und-tork", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011130.jpg?v=1772548656"]}, {"id": "9271079469314", "title": "DISPENSADOR WYPALL DE PARED METALICO NEGRO - KIMBERLY", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 315330, "compare_price": null, "sku": "010070", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010070.jpg?v=1768830469", "handle": "dispensador-wypall-de-pared-metalico-negro-kimberly", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010070.jpg?v=1768830469"]}, {"id": "9225266168066", "title": "SET MOPA PLANA MICROACTIVA 43 CM SIN MANGO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 31980, "compare_price": null, "sku": "023202", "invima": "INVIMA 2021168066", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-5013.jpg?v=1764883570", "handle": "set-mopa-plana-microactiva-43-cm-sin-mango", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-5013.jpg?v=1764883570"]}, {"id": "9225242640642", "title": "MOPA PLANA REPUESTO MICROACTIVA 43 CM RPTO TASK", "category": "Aseo", "subcat": "Aseo Profesional", "price": 18618, "compare_price": null, "sku": "023203", "invima": "INVIMA 2021640642", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-5012.jpg?v=1764880031", "handle": "mopa-plana-repuesto-microactiva-43-cm-rpto-task", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-5012.jpg?v=1764880031"]}, {"id": "9202091360514", "title": "AROMATICA INFUSION PIÑA/TE VERDE/FLOR JAMAICA CJ X 10 SOBRES ISASHII", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 19066, "compare_price": null, "sku": "032624", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032624.png?v=1762960265", "handle": "aromatica-infusion-pina-te-verde-flor-jamaica-cj-x-10-sobres-isashii", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032624.png?v=1762960265"]}, {"id": "9202091262210", "title": "AROMATICA INFUSION MANGO COCO Y MENTA CAJA X 10 SOBRES ISASHII", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 19636, "compare_price": null, "sku": "032623", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032623.png?v=1762960214", "handle": "aromatica-infusion-mango-coco-y-menta-caja-x-10-sobres-isashii", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032623.png?v=1762960214"]}, {"id": "9202091163906", "title": "AROMATICA INFUSION PITAHAYA/MORA/FRESA/LIMONARIA CX10 SOBRES ISASHII", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 20646, "compare_price": null, "sku": "032622", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032622.png?v=1762960143", "handle": "aromatica-infusion-pitahaya-mora-fresa-limonaria-cx10-sobres-isashii", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032622.png?v=1762960143"]}, {"id": "9202090803458", "title": "AROMATICA INFUSION UCHUVA Y TE NEGRO CAJA X 10 SOBRES ISASHII", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 16404, "compare_price": null, "sku": "032621", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032621.png?v=1762960090", "handle": "aromatica-infusion-uchuva-y-te-negro-caja-x-10-sobres-isashii", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032621.png?v=1762960090"]}, {"id": "9157703008514", "title": "TOALLA MANO Z NATURAL H.D. 21.4 X 23.8 CM PQ. X 150 UD TORK", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 8754, "compare_price": null, "sku": "011108", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011108.jpg?v=1774882164", "handle": "toalla-mano-z-natural-h-d-21-x-24-cm-pq-x-150-ud-f-73553-copia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011108.jpg?v=1774882164"]}, {"id": "9157676237058", "title": "DISPENSADOR TOALLA DE MANOS EN ROLLO BASIC COMPACTO TAPA LATERAL", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 101227, "compare_price": null, "sku": "011004", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011004.jpg?v=1761229688", "handle": "dispensador-toalla-de-manos-en-rollo-basic-compacto-tapa-lateral", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011004.jpg?v=1761229688"]}, {"id": "9132397854978", "title": "DISPENSADOR DE CINTA DE EMPAQUE TESA", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 35295, "compare_price": null, "sku": "052355", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/052355.jpg?v=1760021959", "handle": "dispensador-de-cinta-de-empaque-tesa", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/052355.jpg?v=1760021959"]}, {"id": "9124316938498", "title": "CREOLINA CONCENTRADA GALON X  3800 C.C. - PROASEO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 20084, "compare_price": null, "sku": "027146", "invima": "INVIMA 2021038498", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027146.jpg?v=1759420229", "handle": "creolina-concentrada-galon-x-3800-c-c-proaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027146.jpg?v=1759420229"]}, {"id": "9117659496706", "title": "PAPEL KRAFT POR ROLLO 24\" X 150 MTS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 47707, "compare_price": null, "sku": "051006", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/051006.jpg?v=1758727047", "handle": "papel-kraft-por-rollo-24-x-150-mts", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/051006.jpg?v=1758727047"]}, {"id": "9098346103042", "title": "ESPONJILLA SABRA-PAÑO ABRASIVO 9.5 X 13 CM  COLOR AZUL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 408, "compare_price": null, "sku": "023916", "invima": "INVIMA 2021103042", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023916.jpg?v=1757429409", "handle": "esponjilla-sabra-pano-abrasivo-9-5-x-13-cm-color-azul", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023916.jpg?v=1757429409"]}, {"id": "9093031854338", "title": "INFUSION FRUTAL HINDU SURTIDA CAJA X 100 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 50237, "compare_price": null, "sku": "032585", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032585.png?v=1756756762", "handle": "infusion-frutal-hindu-surtida-caja-x-100-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032585.png?v=1756756762"]}, {"id": "9065242001666", "title": "DISPENSADOR SERVILLETA MEGA DISPENSADOR DE PEDESTAL", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 441435, "compare_price": null, "sku": "011045", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011045.jpg?v=1753109216", "handle": "dispensador-servilleta-mega-dispensador-de-pedestal", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011045.jpg?v=1753109216"]}, {"id": "9061898158338", "title": "VASO CARTON 7 OZ PAQ. X 40 SIN IMPRESION BLANCO - BARVAL", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5591, "compare_price": null, "sku": "032250", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031381.jpg?v=1588387963", "handle": "vaso-carton-7-oz-paq-x-40-sin-impresion-blanco-barval", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031381.jpg?v=1588387963"]}, {"id": "9051526627586", "title": "PAÑITOS HUMEDOS ANTIBACTERIAL DAMPY CON ALOE VERA X 150 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 11211, "compare_price": null, "sku": "024079", "invima": "INVIMA 2021627586", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/024079.jpg?v=1751557196", "handle": "panitos-humedos-antibacterial-dampy-con-aloe-vera-x-150-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/024079.jpg?v=1751557196"]}, {"id": "9051522793730", "title": "GUANTE NITRILO SIN POLVO NEGRO CAJA X 100 UD TALLA L", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 24324, "compare_price": null, "sku": "081214", "invima": "INVIMA 2021793730", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081214.jpg?v=1751557036", "handle": "guante-nitrilo-sin-polvo-negro-caja-x-100-ud-talla-m-copia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081214.jpg?v=1751557036"]}, {"id": "9051521384706", "title": "GUANTE NITRILO SIN POLVO NEGRO CAJA X 100 UD TALLA M", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 24324, "compare_price": null, "sku": "081213", "invima": "INVIMA 2021384706", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081213.jpg?v=1751556924", "handle": "guante-nitrilo-sin-polvo-negro-caja-x-100-ud-talla-m", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081213.jpg?v=1751556924"]}, {"id": "9051521024258", "title": "GUANTE NITRILO SIN POLVO NEGRO CAJA X 100 UD TALLA S", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 24324, "compare_price": null, "sku": "081212", "invima": "INVIMA 2021024258", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081212_434d4801-6dc2-460e-bf43-d4642cb6cd2a.jpg?v=1751556764", "handle": "guante-nitrilo-sin-polvo-negro-caja-x-100-ud-talla-s", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081212_434d4801-6dc2-460e-bf43-d4642cb6cd2a.jpg?v=1751556764"]}, {"id": "9051514274050", "title": "GUANTE NITRILO SIN POLVO AZUL CAJA X 100 UD TALLA L", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 23547, "compare_price": null, "sku": "040682", "invima": "INVIMA 2021274050", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040682.jpg?v=1751556356", "handle": "guante-nitrilo-s-polvo-azul-caja-x-100-ud-talla-l", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040682.jpg?v=1751556356"]}, {"id": "9051512570114", "title": "GUANTE NITRILO SIN POLVO AZUL CAJA X 100 UD TALLA M", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 23547, "compare_price": null, "sku": "081183", "invima": "INVIMA 2021570114", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081183.jpg?v=1751556115", "handle": "guante-nitrilo-s-polvo-azul-caja-x-100-ud-talla-m", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081183.jpg?v=1751556115"]}, {"id": "9051510178050", "title": "GUANTE NITRILO SIN POLVO AZUL CAJA X 100 UD TALLA S", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 23547, "compare_price": null, "sku": "081173", "invima": "INVIMA 2021178050", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081173.jpg?v=1751555875", "handle": "guante-nitrilo-s-polvo-azul-caja-x-100-ud-talla-s", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/081173.jpg?v=1751555875"]}, {"id": "9041872093442", "title": "ROLLO TERMICO P/REGISTRADORA 48 GR. 80 MM X 60 MTS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 4284, "compare_price": null, "sku": "062701", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062701_17f1429a-76bd-46fa-a563-39ce81f746b8.jpg?v=1750801008", "handle": "rollo-termico-p-registradora-48-gr-80-mm-x-60-mts", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062701_17f1429a-76bd-46fa-a563-39ce81f746b8.jpg?v=1750801008"]}, {"id": "9037396279554", "title": "LIMPIADOR PISOS LAMINADO GALON X 3000 CC", "category": "Aseo", "subcat": "Aseo Profesional", "price": 59976, "compare_price": null, "sku": "040875", "invima": "INVIMA 2021279554", "badge": "Mayorista Ahorro", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040875.jpg?v=1750191401", "handle": "limpiador-pisos-laminado-galon-x-3000-cc", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040875.jpg?v=1750191401"]}, {"id": "9036493029634", "title": "SERVILLETA TORK NATURAL COCKTAIL PAQ. X 200 UD FSC FAMILIA - F-72063", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 5767, "compare_price": null, "sku": "011090", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Paquete", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011090.jpg?v=1750088607", "handle": "servilleta-tork-natural-cocktail-paq-x-200-ud-fsc-familia-f-72063", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011090.jpg?v=1750088607"]}, {"id": "9034470818050", "title": "AZUCAR MORENA X 1000 GRS. MANUELITA", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5558, "compare_price": null, "sku": "030228", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030226.jpg?v=1749754261", "handle": "azucar-morena-x-1000-grs-manuelita", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030226.jpg?v=1749754261"]}, {"id": "9027130196226", "title": "PANELA MASAROMA SOBRES X 6 GRS. PAQUETE X 100 UND", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 9240, "compare_price": null, "sku": "032493", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032493.jpg?v=1749050092", "handle": "panela-masaroma-sobres-x-6-grs-paquete-x-100-und", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032493.jpg?v=1749050092"]}, {"id": "4894704468100", "title": "INFUSION FRUTAL HINDU FRUTOS SALVAJES CAJA X 20 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 12315, "compare_price": null, "sku": "031817", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031817.jpg?v=1588383792", "handle": "hin-1010115-infusion-frutal-hindu-frutos-salvajes-caja-x-20-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031817.jpg?v=1588383792"]}, {"id": "8982466461954", "title": "COSEDORA 20 HJS 300 1/2 T. RANK 1060", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 12337, "compare_price": null, "sku": "060442", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060442.png?v=1743635990", "handle": "cosedora-20-hjs-300-1-2-t-rank-1060", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060442.png?v=1743635990"]}, {"id": "9002422534402", "title": "TRAPERO HILO BLANCO COPA COLOR AMARILLO 500 GR. REF. 900 SIN MANGO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 11840, "compare_price": null, "sku": "023891", "invima": "INVIMA 2021534402", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023891.jpg?v=1745427291", "handle": "trapero-hilo-blanco-copa-color-amarillo-500-gr-ref-900-sin-mango", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023891.jpg?v=1745427291"]}, {"id": "9002422731010", "title": "TRAPERO HILO BLANCO COPA COLOR ROJO 500 GR. REF. 900 SIN MANGO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 11840, "compare_price": null, "sku": "023894", "invima": "INVIMA 2021731010", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023894.jpg?v=1745427335", "handle": "trapero-hilo-blanco-copa-color-amarillo-500-gr-ref-900-sin-mango-copia", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023894.jpg?v=1745427335"]}, {"id": "4894698930308", "title": "MANGO MADERA ESCOBAS-TRAPEROS CON TAPON Y ADAPTADOR 1.40 - 1A -", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3659, "compare_price": null, "sku": "022721", "invima": "INVIMA 2021030308", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022721.jpg?v=1588393975", "handle": "1a-100304-mango-madera-escobas-traperos-con-tapon-y-adaptador-1-40-1a", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022721.jpg?v=1588393975"]}, {"id": "4894702272644", "title": "AROMATICA INFUSION HERBAL FLOR JAMAICA PIEL UVA Y ARANDANO X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 11187, "compare_price": null, "sku": "031612", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031612.jpg?v=1588361075", "handle": "jb-12624-aromatica-infusion-herbal-flor-jamaica-piel-uva-y-arandano-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031612.jpg?v=1588361075"]}, {"id": "5602022490279", "title": "WYPALL X-60 REGULAR ROLL CON POWER POCKETS BLANCO X 176 PAÑOS", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 27360, "compare_price": null, "sku": "011002", "invima": "INVIMA 2021490279", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.9 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30242870_ESP-06.png?v=1773770866", "handle": "wypall-x-60-regular-roll-con-power-pockets-blanco-x-176-panos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30242870_ESP-06.png?v=1773770866"]}, {"id": "8913950245122", "title": "SOLUCION SALINA / SUERO FISIOLOGICO X 500 C.C.", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 7408, "compare_price": null, "sku": "061108", "invima": "INVIMA 2021245122", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061108.jpg?v=1739285892", "handle": "solucion-salina-suero-fisiologico-x-500-c-c", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061108.jpg?v=1739285892"]}, {"id": "4894692769924", "title": "ARMAZON METALICO P/BRILLADOR GRANDE REF. 2430 - FULLER", "category": "Aseo", "subcat": "Aseo Profesional", "price": 23299, "compare_price": null, "sku": "020186", "invima": "INVIMA 2021769924", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020186.jpg?v=1588373609", "handle": "ful-122431-armazon-metalico-p-brillador-grande-ref-2430-fuller", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020186.jpg?v=1588373609"]}, {"id": "4894692835460", "title": "BALDE ECONOMICO 10 LTS C/ AZUL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7784, "compare_price": null, "sku": "021679", "invima": "INVIMA 2021835460", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021679.jpg?v=1588363947", "handle": "1a-600123-balde-economico-10-lts-c-azul", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021679.jpg?v=1588363947"]}, {"id": "4894692868228", "title": "BALDE ECONOMICO 12 LTS  C/ AZUL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7979, "compare_price": null, "sku": "021676", "invima": "INVIMA 2021868228", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021676.jpg?v=1588363971", "handle": "1a-600126-balde-economico-12-lts-c-azul", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021676.jpg?v=1588363971"]}, {"id": "4894692933764", "title": "BALDE ECONOMICO 12 LTS  C/ROJO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7979, "compare_price": null, "sku": "021675", "invima": "INVIMA 2021033764", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021675.jpg?v=1588364006", "handle": "1a-600127-balde-economico-12-lts-c-rojo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021675.jpg?v=1588364006"]}, {"id": "4894692966532", "title": "BAYETILLA BLANCA FILETEADA 50 X 35 CM", "category": "Aseo", "subcat": "Aseo Profesional", "price": 2487, "compare_price": null, "sku": "020085", "invima": "INVIMA 2021066532", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020085.jpg?v=1588364337", "handle": "id-030-bayetilla-blanca-fileteada-50-x-35-cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020085.jpg?v=1588364337"]}, {"id": "4894692999300", "title": "BAYETILLA BLANCA FILETEADA 50 X 70 CM", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4900, "compare_price": null, "sku": "020081", "invima": "INVIMA 2021099300", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020081.jpg?v=1588364368", "handle": "id-011-bayetilla-blanca-fileteada-50-x-70-cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020081.jpg?v=1588364368"]}, {"id": "4894693032068", "title": "BAYETILLA BLANCA SIN/FILETEAR 70 X 100 CM", "category": "Aseo", "subcat": "Aseo Profesional", "price": 9032, "compare_price": null, "sku": "020079", "invima": "INVIMA 2021032068", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020079.jpg?v=1588364694", "handle": "id-073-bayetilla-blanca-sin-filetear-70-x-100-cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020079.jpg?v=1588364694"]}, {"id": "4894693064836", "title": "BAYETILLA BLANCA X 1 METRO FILETEADA (70X100CM)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 9340, "compare_price": null, "sku": "020084", "invima": "INVIMA 2021064836", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020084.jpg?v=1588364716", "handle": "id-072-bayetilla-blanca-x-1-metro-fileteada-70x100cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020084.jpg?v=1588364716"]}, {"id": "4894693097604", "title": "BAYETILLA ROJA FILETEADA 50 X 35 CM", "category": "Aseo", "subcat": "Aseo Profesional", "price": 2480, "compare_price": null, "sku": "020083", "invima": "INVIMA 2021097604", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020083.jpg?v=1588364750", "handle": "id-040-bayetilla-roja-fileteada-50-x-35-cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020083.jpg?v=1588364750"]}, {"id": "4894693163140", "title": "BAYETILLA ROJA FILETEADA 50X70 CM", "category": "Aseo", "subcat": "Aseo Profesional", "price": 5097, "compare_price": null, "sku": "021794", "invima": "INVIMA 2021163140", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (30 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021794.jpg?v=1588364771", "handle": "id-201-bayetilla-roja-fileteada-50x70-cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021794.jpg?v=1588364771"]}, {"id": "4894693228676", "title": "BAYETILLA ROJA SIN/FILETEAR 70 X 100 CM", "category": "Aseo", "subcat": "Aseo Profesional", "price": 9460, "compare_price": null, "sku": "020080", "invima": "INVIMA 2021228676", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020080.jpg?v=1588364827", "handle": "id-012-bayetilla-roja-sin-filetear-70-x-100-cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020080.jpg?v=1588364827"]}, {"id": "4894693261444", "title": "BAYETILLA ROJA X 1 METRO FILETEADA (70X100CM)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 9700, "compare_price": null, "sku": "020093", "invima": "INVIMA 2021261444", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020093.jpg?v=1588364859", "handle": "id-089-bayetilla-roja-x-1-metro-fileteada-70x100cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020093.jpg?v=1588364859"]}, {"id": "4894693523588", "title": "BOLSA BASURA BLANCA TASK PRO 80 X 110  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 10916, "compare_price": null, "sku": "023219", "invima": "INVIMA 2021523588", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017057BOLSADEBASURABLANCOTASKPRO8011010UNID.png?v=1614704716", "handle": "task-1017057-bolsa-basura-rollo-80-x-110-x-10-und-blanca-task", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017057BOLSADEBASURABLANCOTASKPRO8011010UNID.png?v=1614704716"]}, {"id": "4894693589124", "title": "BOLSA BASURA VERDE TASK PRO 80 X 110 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 11614, "compare_price": null, "sku": "023086", "invima": "INVIMA 2021589124", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017051BOLSABASURAVERDETASKPRO8011010UNID.png?v=1614705272", "handle": "task-1017051-bolsa-basura-rollo-80-x-110-x-10-und-verde-task", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017051BOLSABASURAVERDETASKPRO8011010UNID.png?v=1614705272"]}, {"id": "4894693752964", "title": "BOLSA LECHOSA 40 X 60  CL.1 PAQ. X 100", "category": "Aseo", "subcat": "Aseo Profesional", "price": 20175, "compare_price": null, "sku": "021374", "invima": "INVIMA 2021752964", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021374.jpg?v=1588368415", "handle": "bl-109-bolsa-lechosa-40-x-60-cl-1-paq-x-100", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021374.jpg?v=1588368415"]}, {"id": "4894693818500", "title": "BOLSA TRANSPARENTE 90 X 120 CM CL 2 PAQ. X 6", "category": "Aseo", "subcat": "Aseo Profesional", "price": 11701, "compare_price": null, "sku": "021430", "invima": "INVIMA 2021818500", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021430.jpg?v=1588370982", "handle": "bl-1430-bolsa-transparente-90-x-120-cm-cl-2-paq-x-6", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021430.jpg?v=1588370982"]}, {"id": "4894694080644", "title": "BOLSA ZIPLOC  30 X 40 CM PAQ. X 100", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 37121, "compare_price": null, "sku": "032000", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032000.jpg?v=1588371574", "handle": "bl-2000-bolsa-ziploc-30-x-40-cm-paq-x-100", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032000.jpg?v=1588371574"]}, {"id": "4894694703236", "title": "BOLSA TRANSP. ORIGINAL 50 X 54 CL.1 PQ X 10", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3885, "compare_price": null, "sku": "021281", "invima": "INVIMA 2021703236", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021281.jpg?v=1588370811", "handle": "tp-5054-bolsa-transp-original-50-x-54-cl-1-pq-x-10", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021281.jpg?v=1588370811"]}, {"id": "4894696734852", "title": "ESPONJA SUAVE OROPLATA UNIDAD TASK", "category": "Aseo", "subcat": "Aseo Profesional", "price": 2883, "compare_price": null, "sku": "022842", "invima": "INVIMA 2021734852", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022842.jpg?v=1588377675", "handle": "task-1635080-esponja-suave-oroplata-unidad-task", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022842.jpg?v=1588377675"]}, {"id": "4894700437636", "title": "PORTAESCOBA PLASTICO X 4 GANCHOS ORGANIZADOR BLANCO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 15900, "compare_price": null, "sku": "020628", "invima": "INVIMA 2021437636", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020628.jpg?v=1588393114", "handle": "pin-13046-portaescoba-plastico-x-4-ganchos-organizador-blanco", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020628.jpg?v=1588393114"]}, {"id": "4894701191300", "title": "TRAPERO COPA 280 GRS EN MICROFIBRA BLANCO SIN MANGO - TRAPISOL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 30851, "compare_price": null, "sku": "022761", "invima": "INVIMA 2021191300", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022761.jpg?v=1588389661", "handle": "tra-mi2761b-trapero-copa-280-grs-en-microfibra-blanco-s-mango-trapisol", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022761.jpg?v=1588389661"]}, {"id": "4894701977732", "title": "AROMATICA HINDU CIDRON CAJA X 20 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3931, "compare_price": null, "sku": "032009", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032099.jpg?v=1588360709", "handle": "hin-1000131-aromatica-hindu-cidron-caja-x-20-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032099.jpg?v=1588360709"]}, {"id": "4894702108804", "title": "AROMATICA HINDU LIMONCILLO CAJA X 20 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3931, "compare_price": null, "sku": "032008", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032008.jpg?v=1588360759", "handle": "hin-1000135-aromatica-hindu-limoncillo-caja-x-20-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032008.jpg?v=1588360759"]}, {"id": "4894702141572", "title": "AROMATICA HINDU MANZANILLA CAJA X 20 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3931, "compare_price": null, "sku": "032010", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032010.jpg?v=1588360805", "handle": "hin-1000132-aromatica-hindu-manzanilla-caja-x-20-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032010.jpg?v=1588360805"]}, {"id": "4894702174340", "title": "AROMATICA HINDU TORONJIL CAJA X 20 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3931, "compare_price": null, "sku": "032011", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (30 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032011.jpg?v=1588360890", "handle": "hin-1000136-aromatica-hindu-toronjil-caja-x-20-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032011.jpg?v=1588360890"]}, {"id": "4894702207108", "title": "AROMATICA HINDU YERBABUENA CAJA X 20 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3931, "compare_price": null, "sku": "032007", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032007.jpg?v=1588360958", "handle": "hin-1000133-aromatica-hindu-yerbabuena-caja-x-20-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032007.jpg?v=1588360958"]}, {"id": "4894702239876", "title": "AROMATICA INFUSION HERBAL CANELA-MANZANA X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 11187, "compare_price": null, "sku": "030919", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030919.png?v=1588361023", "handle": "jb-12622-aromatica-infusion-herbal-canela-manzana-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030919.png?v=1588361023"]}, {"id": "4894702370948", "title": "AROMATICA INFUSION HERBAL FRUTAL MANZANILLA-FRESA X 20 UD JAIBEL", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 11187, "compare_price": null, "sku": "030918", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030918.png?v=1588361349", "handle": "jb-12619-aromatica-infusion-herbal-frutal-manzanilla-fresa-x-20-ud-jaibel", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030918.png?v=1588361349"]}, {"id": "4894702403716", "title": "AROMATICA INFUSION HERBAL FRUTAL YERBABUENA-MORA  X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 11187, "compare_price": null, "sku": "030920", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030920.png?v=1588361442", "handle": "jb-12621-aromatica-infusion-herbal-frutal-yerbabuena-mora-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030920.png?v=1588361442"]}, {"id": "4894702436484", "title": "AROMATICA JAIBEL INSTITUCIONAL ALBAHACA X 25 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 2833, "compare_price": null, "sku": "030868", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030868.jpg?v=1588361464", "handle": "jb-12642-aromatica-jaibel-institucional-albahaca-x-25-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030868.jpg?v=1588361464"]}, {"id": "4894702469252", "title": "AROMATICA JAIBEL INSTITUCIONAL LIMONARIA X 25 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3089, "compare_price": null, "sku": "030866", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030866.jpg?v=1588361483", "handle": "jb-12643-aromatica-jaibel-institucional-limonaria-x-25-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030866.jpg?v=1588361483"]}, {"id": "4894702502020", "title": "AROMATICA JAIBEL INSTITUCIONAL MANZANILLA X 25 UD JAIBEL", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3089, "compare_price": null, "sku": "030882", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030882.jpg?v=1588361505", "handle": "jb-12644-aromatica-jaibel-institucional-manzanilla-x-25-ud-jaibel", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030882.jpg?v=1588361505"]}, {"id": "4894702534788", "title": "AROMATICA JAIBEL INSTITUCIONAL YERBABUENA X 25 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3089, "compare_price": null, "sku": "030867", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030867.jpg?v=1588361527", "handle": "jb-12645-aromatica-jaibel-institucional-yerbabuena-x-25-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030867.jpg?v=1588361527"]}, {"id": "4894702600324", "title": "AROMATICA JAIBEL TRADICIONAL COLOMBIANA ALBAHACA X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4217, "compare_price": null, "sku": "030863", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030863.png?v=1588361677", "handle": "jb-12573-aromatica-jaibel-tradicional-colombiana-albahaca-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030863.png?v=1588361677"]}, {"id": "4894702633092", "title": "AROMATICA JAIBEL TRADICIONAL COLOMBIANA CIDRON X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4217, "compare_price": null, "sku": "031362", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031362.png?v=1588361745", "handle": "jb-12576-aromatica-jaibel-tradicional-colombiana-cidron-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031362.png?v=1588361745"]}, {"id": "4894702665860", "title": "AROMATICA JAIBEL TRADICIONAL COLOMBIANA LIMONARIA X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4217, "compare_price": null, "sku": "030861", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030861.jpg?v=1588361817", "handle": "jb-12577-aromatica-jaibel-tradicional-colombiana-limonaria-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030861.jpg?v=1588361817"]}, {"id": "4894702698628", "title": "AROMATICA JAIBEL TRADICIONAL COLOMBIANA MANZANILLA X 20 UD JAIBEL", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4217, "compare_price": null, "sku": "030881", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030881.png?v=1588361889", "handle": "jb-12578-aromatica-jaibel-tradicional-colombiana-manzanilla-x-20-ud-jaibel", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030881.png?v=1588361889"]}, {"id": "4894702731396", "title": "AROMATICA JAIBEL TRADICIONAL COLOMBIANA SOBREENVOLTURA SURTIDA X 20", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4217, "compare_price": null, "sku": "030246", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030246.png?v=1588361947", "handle": "jb-12589-aromatica-jaibel-tradicional-colombiana-sobreenvoltura-surtida-x-20", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030246.png?v=1588361947"]}, {"id": "4894702796932", "title": "AROMATICA JAIBEL TRADICIONAL COLOMBIANA TORONJIL X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4217, "compare_price": null, "sku": "030864", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030864.jpg?v=1588361999", "handle": "jb-12579-aromatica-jaibel-tradicional-colombiana-toronjil-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030864.jpg?v=1588361999"]}, {"id": "4894702829700", "title": "AROMATICA JAIBEL TRADICIONAL COLOMBIANA YERBABUENA X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4217, "compare_price": null, "sku": "030862", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030862.jpg?v=1588362094", "handle": "jb-12580-aromatica-jaibel-tradicional-colombiana-yerbabuena-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030862.jpg?v=1588362094"]}, {"id": "4894702895236", "title": "AROMATICA MASAROMA DE PANELA FRUTAS EXOTICAS CAJA X 25 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5530, "compare_price": null, "sku": "031073", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031073.jpg?v=1588362367", "handle": "mas-026-aromatica-masaroma-de-panela-frutas-exoticas-caja-x-25-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031073.jpg?v=1588362367"]}, {"id": "4894702928004", "title": "AROMATICA MASAROMA DE PANELA LIMONCILLO CAJA X 25 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5530, "compare_price": null, "sku": "031074", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031074.jpg?v=1588362409", "handle": "mas-027-aromatica-masaroma-de-panela-limoncillo-caja-x-25-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031074.jpg?v=1588362409"]}, {"id": "4894702960772", "title": "AROMATICA MASAROMA DE PANELA SABORES SURTIDOS CAJA X 25 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5530, "compare_price": null, "sku": "032088", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032088.jpg?v=1588443976", "handle": "mas-030-aromatica-masaroma-de-panela-sabores-surtidos-caja-x-25-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032088.jpg?v=1588443976"]}, {"id": "4894703026308", "title": "AROMATICA MASAROMA DE PANELA YERBABUENA CAJA X 25 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5530, "compare_price": null, "sku": "031987", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031987.jpg?v=1588362480", "handle": "mas-028-aromatica-masaroma-de-panela-yerbabuena-caja-x-25-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031987.jpg?v=1588362480"]}, {"id": "4894703059076", "title": "AROMATICA ORQUIDEA SURTIDA CJ X 25 BL", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4453, "compare_price": null, "sku": "031080", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031080.jpg?v=1588444141", "handle": "to-015-aromatica-orquidea-surtida-cj-x-25-bl", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031080.jpg?v=1588444141"]}, {"id": "4894703878276", "title": "CAFE SELLO ROJO INSTITUCIONAL FUERTE X 500 GR", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 28072, "compare_price": null, "sku": "031962", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031962.jpg?v=1588372284", "handle": "nch-1009888-cafe-sello-rojo-institucional-fuerte-x-500-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031962.jpg?v=1588372284"]}, {"id": "4894704042116", "title": "SERVILLETA BLANCA PARTIDA 1 A 1 PAQ. X  150 UD FSC (F-72611)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 2663, "compare_price": null, "sku": "010956", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Paquete", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010956.jpg?v=1774887039", "handle": "f-72611-servilleta-blanca-partida-1-a-1-paq-x-150-ud-fsc-familia-72595", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010956.jpg?v=1774887039"]}, {"id": "4894704697476", "title": "TOALLA MANO Z BLANCA DOBLE HOJA 21 X 24 CM PAQ. X 150 UNIDADES (F-200246)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 10166, "compare_price": null, "sku": "011081", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Paquete", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011081.jpg?v=1774886502", "handle": "f-73577-toalla-mano-z-blanca-d-h-21-x-24-cm-paq-x-150-ud-familia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011081.jpg?v=1774886502"]}, {"id": "4894705287300", "title": "TE HINDU ORIGINAL CAJA X 25 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 8050, "compare_price": null, "sku": "030034", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030034.jpg?v=1734450293", "handle": "hin-1000127-te-hindu-original-caja-x-25-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030034.jpg?v=1734450293"]}, {"id": "4894705614980", "title": "PLATO PEQ. PONQUE PLASTICO BLANCO PAQ. X 20 UD - DOMINGO", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 2939, "compare_price": null, "sku": "030028", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030028.jpg?v=1588393259", "handle": "mult-01500301-plato-peq-ponque-plastico-blanco-paq-x-20-ud-domingo", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030028.jpg?v=1588393259"]}, {"id": "4894705680516", "title": "PLATO MEDIANO PLASTICO BLANCO PAQ. X 20 UD - DOMINGO", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4316, "compare_price": null, "sku": "030025", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030025.jpg?v=1588393296", "handle": "mult-01900301-plato-mediano-plastico-blanco-paq-x-20-ud-domingo", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030025.jpg?v=1588393296"]}, {"id": "4894709121156", "title": "ESPONJILLON DE BRILLO PAQ. X 6 TASK", "category": "Aseo", "subcat": "Aseo Profesional", "price": 2160, "compare_price": null, "sku": "022840", "invima": "INVIMA 2021121156", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022840_jpg.jpg?v=1588379232", "handle": "task-1635078-esponjillon-de-brillo-paq-x-6-task", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022840_jpg.jpg?v=1588379232"]}, {"id": "4894709612676", "title": "ALCOHOL ANTISEPTICO OSA GARRAFA X 20 LT", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 188723, "compare_price": null, "sku": "027021", "invima": "INVIMA 2021612676", "badge": "Mayorista Ahorro", "unit": "Garrafa 20L", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040693.jpg?v=1588448792", "handle": "sl-693-alcohol-antiseptico-al-70-uso-externo-garrafa-x-20-lt", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040693.jpg?v=1588448792"]}, {"id": "4894709678212", "title": "AMBIENTADOR BONAIRE BAMBU AEROSOL X 400 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 10623, "compare_price": null, "sku": "040292", "invima": "INVIMA 2021678212", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040292.jpg?v=1588358284", "handle": "bon-10304-ambientador-bonaire-bambu-aerosol-x-400-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040292.jpg?v=1588358284"]}, {"id": "4894709710980", "title": "AMBIENTADOR BONAIRE CANELA AEROSOL X 400 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 10623, "compare_price": null, "sku": "040306", "invima": "INVIMA 2021710980", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040306.jpg?v=1588358369", "handle": "bon-10305-ambientador-bonaire-canela-aerosol-x-400-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040306.jpg?v=1588358369"]}, {"id": "4894709809284", "title": "AMBIENTADOR BONAIRE FRUTOS ROJOS AEROSOL X 400 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 10623, "compare_price": null, "sku": "040434", "invima": "INVIMA 2021809284", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040434.jpg?v=1588358412", "handle": "bon-10312-ambientador-bonaire-frutos-rojos-aerosol-x-400-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040434.jpg?v=1588358412"]}, {"id": "4894709874820", "title": "AMBIENTADOR BONAIRE VAINILLA & AMBAR AEROSOL X 400 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 10623, "compare_price": null, "sku": "040294", "invima": "INVIMA 2021874820", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-2754.webp?v=1754504618", "handle": "bon-10311-ambientador-bonaire-vainilla-pomelo-aerosol-x-400-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-2754.webp?v=1754504618"]}, {"id": "4894709907588", "title": "AMBIENTADOR BONAIRE VARITAS VAINILLA X 80 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 16071, "compare_price": null, "sku": "027461", "invima": "INVIMA 2021007588", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027461.jpg?v=1588358505", "handle": "bon-7461-ambientador-bonaire-varitas-vainilla-x-80-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027461.jpg?v=1588358505"]}, {"id": "4894709940356", "title": "AMBIENTADOR GLADE AUTOMATICO RESPUESTO X 270 ML SURTIDO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 31658, "compare_price": null, "sku": "040477", "invima": "INVIMA 2021040356", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040477.jpg?v=1588358530", "handle": "sc-0477-ambientador-glade-automatico-respuesto-x-270-ml-surtido", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040477.jpg?v=1588358530"]}, {"id": "4894710038660", "title": "AMBIENTADOR GLADE MANZANA CANELA AEROSOL X 400 CC", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 14799, "compare_price": null, "sku": "040328", "invima": "INVIMA 2021038660", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040328.jpg?v=1588358581", "handle": "sc-8594-ambientador-glade-manzana-canela-aerosol-x-400-cc", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040328.jpg?v=1588358581"]}, {"id": "4894710104196", "title": "AMBIENTADOR GLADE PARAISO AZUL AEROSOL X 400 CC", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 14799, "compare_price": null, "sku": "027314", "invima": "INVIMA 2021104196", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027314.jpg?v=1588358642", "handle": "sc-8595-ambientador-glade-paraiso-azul-aerosol-x-400-cc", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027314.jpg?v=1588358642"]}, {"id": "4894710399108", "title": "BLANCOX FLORAL VITAL GALON X 3800 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 14282, "compare_price": null, "sku": "027449", "invima": "INVIMA 2021399108", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027449.jpg?v=1588364953", "handle": "bri-100340077-blancox-floral-vital-galon-x-3800-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027449.jpg?v=1588364953"]}, {"id": "4894710431876", "title": "BLANCOX LIMON FUSION GALON X 3800 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 14282, "compare_price": null, "sku": "020942", "invima": "INVIMA 2021431876", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020942.jpg?v=1588364982", "handle": "bri-100340076-blancox-limon-fusion-galon-x-3800-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020942.jpg?v=1588364982"]}, {"id": "4894710464644", "title": "BLANCOX REGULAR \"PODER NATURAL\" FRASCO X 1000 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 3853, "compare_price": null, "sku": "020941", "invima": "INVIMA 2021464644", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020941.jpg?v=1588365070", "handle": "bri-10032116-blancox-regular-poder-natural-frasco-x-1000-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020941.jpg?v=1588365070"]}, {"id": "4894710497412", "title": "BLANCOX REGULAR \"PODER NATURAL\" GALON X 2000 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 7178, "compare_price": null, "sku": "020940", "invima": "INVIMA 2021497412", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020940.jpg?v=1588365121", "handle": "bri-100340067-blancox-regular-poder-natural-galon-x-2000-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020940.jpg?v=1588365121"]}, {"id": "4894710530180", "title": "BLANCOX REGULAR \"PODER NATURAL\" GL X 3800 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 13427, "compare_price": 10580, "sku": "040356", "invima": "INVIMA 2021530180", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040356.jpg?v=1588365142", "handle": "bri-100340075-blancox-regular-poder-natural-gl-x-3800-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040356.jpg?v=1588365142"]}, {"id": "4894710628484", "title": "BLANCOX TRADICIONAL \"PODER NATURAL\" GARRAFA X 20 LTS", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 60541, "compare_price": null, "sku": "040522", "invima": "INVIMA 2021628484", "badge": "Mayorista Ahorro", "unit": "Garrafa 20L", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040522.jpg?v=1588365274", "handle": "bri-10030048-blancox-tradicional-poder-natural-garrafa-x-20-lts", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040522.jpg?v=1588365274"]}, {"id": "4894711185540", "title": "DETERGENTE EN POLVO DERSA BULTO X 20 KL A GRANEL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 213428, "compare_price": null, "sku": "020487", "invima": "INVIMA 2021185540", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (30 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020487.jpg?v=1588374624", "handle": "dt-5000-detergente-en-polvo-dersa-bulto-x-20-kl-a-granel", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020487.jpg?v=1588374624"]}, {"id": "4894712725636", "title": "LIMPIADOR DESINFECTANTE MULTIUSOS LAVANDA GL X 2000 CC POTENTE", "category": "Aseo", "subcat": "Aseo Profesional", "price": 15866, "compare_price": null, "sku": "040591", "invima": "INVIMA 2021725636", "badge": "INVIMA Aprobado", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040591.png?v=1588443005", "handle": "pot-41104l-limpiador-desinfectante-multiusos-lavanda-gl-x-2000-cc-potente", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040591.png?v=1588443005", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040591.jpg?v=1588443005"]}, {"id": "4894713118852", "title": "AMBIENTADOR PLUGIN REPUESTO/BOTELLA ACEITE  AROMAS SURTIDO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 17795, "compare_price": null, "sku": "027014", "invima": "INVIMA 2021118852", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7593.jpg?v=1721785934", "handle": "sc-8608-plugin-repuesto-botella-aceite-amb-hawaiian-breeze", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7593.jpg?v=1721785934"]}, {"id": "4894713184388", "title": "AMBIENTADOR PLUGIN UNIDAD ELECTRICA ACEITES NATURALES", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 24083, "compare_price": null, "sku": "020066", "invima": "INVIMA 2021184388", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020066.jpg?v=1588393200", "handle": "sc-8620-plugin-unidad-electrica-aceites-naturales", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020066.jpg?v=1588393200"]}, {"id": "4894713872516", "title": "STRECH TRANSPARENTE FILM 45 CM X 450 MTS CL .0.6", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 39865, "compare_price": 42500, "sku": "081630", "invima": "INVIMA 2021872516", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/080891.jpg?v=1588391417", "handle": "wa-038-strech-transparente-film-45-cm-x-450-mts-cl-0-6", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/080891.jpg?v=1588391417"]}, {"id": "4910152941700", "title": "PAÑOS DE LIMPIEZA WYPALL X80 PLUS ROJO CON POWER POCKETS X 30 PAÑOS", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 32206, "compare_price": null, "sku": "010986", "invima": "INVIMA 2021041700", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243076_ESP-06_1.png?v=1773771320", "handle": "wypall-x-80-plus-rojo-pq-x-30-panos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243076_ESP-06_1.png?v=1773771320"]}, {"id": "4934981386372", "title": "DISPENSADOR TOALLA MANOS EN \"Z\" MOD - KIMBERLY", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 84178, "compare_price": null, "sku": "010930", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010930.jpg?v=1589414393", "handle": "dispensador-toalla-manos-en-z-mod-kimberly", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010930.jpg?v=1589414393"]}, {"id": "4936464728196", "title": "CAFE BUEN DIA SOLUBLE LIOFILIZADO CLASICO FCO X 170 GR", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 45267, "compare_price": null, "sku": "030105", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030105.jpg?v=1589481489", "handle": "caft-009-cafe-buen-dia-soluble-liofilizado-clasico-fco-x-170-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030105.jpg?v=1589481489"]}, {"id": "4936465645700", "title": "SUMA EDEN DESINFECTANTE D4.5 GALON X 5 LTS -DIVERSEY", "category": "Aseo", "subcat": "Aseo Profesional", "price": 487965, "compare_price": null, "sku": "040914", "invima": "INVIMA 2021645700", "badge": "Mayorista Ahorro", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040914.png?v=1697131140", "handle": "jd-65163-suma-eden-desinfectante-d4-5-gl-x-3-lts", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040914.png?v=1697131140", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/80995-PIS-Suma_Eden-A4-es-CO-HRNC-1.jpg?v=1697131140", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/80995-PIS-Suma_Eden-A4-es-CO-HRNC-2.jpg?v=1697131140"]}, {"id": "4936465744004", "title": "BOLSA BASURA NEGRA TASK PRO 80 X 110 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 9963, "compare_price": null, "sku": "023092", "invima": "INVIMA 2021744004", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017052BOLSABASURANEGROTASKPRO8011010UNID.png?v=1614704846", "handle": "task-1017052-bolsa-basura-bio-rollo-80-x-110-x-10-und-negra-task-pro", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017052BOLSABASURANEGROTASKPRO8011010UNID.png?v=1614704846"]}, {"id": "4936465907844", "title": "BOLSA ZIPLOC  PAQ. X 100 BOLSAS 10 ANCHO X 14 ALTO CM", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 7070, "compare_price": null, "sku": "022321", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022321.jpg?v=1589481014", "handle": "bl-2321-bolsa-ziploc-paq-x-100-bolsas-10-ancho-x-14-alto-cm", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022321.jpg?v=1589481014"]}, {"id": "4936467185796", "title": "AMBIENTADOR BONAIRE VARITAS FRUTOS ROJOS X 80 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 16071, "compare_price": null, "sku": "027287", "invima": "INVIMA 2021185796", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027287.jpg?v=1589473579", "handle": "bon-7287-ambientador-bonaire-varitas-frutos-rojos-x-80-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027287.jpg?v=1589473579"]}, {"id": "4936467316868", "title": "DETERGENTE EN POLVO AS DERSA VINAGRE LIMON  BL X 1000 GR", "category": "Aseo", "subcat": "Aseo Profesional", "price": 12080, "compare_price": null, "sku": "040544", "invima": "INVIMA 2021316868", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040544.png?v=1589565000", "handle": "dt-5720-detergente-en-polvo-as-dersa-vinagre-limon-bl-x-1000-gr", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040544.png?v=1589565000"]}, {"id": "4936467480708", "title": "JARRA PLASTICA C /TAPA 2 LTS. REF.1275700 IMUSA", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 17959, "compare_price": null, "sku": "030074", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030074.jpg?v=1589572221", "handle": "imu-7570-jarra-plastica-c-tapa-2-lts-ref-1275700-imusa", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030074.jpg?v=1589572221"]}, {"id": "4936467710084", "title": "AMBIENTADOR BONAIRE VARITAS BAMBU X 80 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 16071, "compare_price": null, "sku": "027288", "invima": "INVIMA 2021710084", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027288.jpg?v=1589473492", "handle": "bon-7288-ambientador-bonaire-varitas-bambu-x-80-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027288.jpg?v=1589473492"]}, {"id": "4936467742852", "title": "AMBIENTADOR BONAIRE VARITAS GRANADILLA X 80 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 16071, "compare_price": null, "sku": "027039", "invima": "INVIMA 2021742852", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027039.jpg?v=1589473645", "handle": "bon-2719-ambientador-bonaire-varitas-granadilla-x-80-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027039.jpg?v=1589473645"]}, {"id": "4936467841156", "title": "BALDE ECONOMICO 12 LTS  C/ VERDE", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7979, "compare_price": null, "sku": "021677", "invima": "INVIMA 2021841156", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021677.jpg?v=1589476196", "handle": "1a-600125-balde-economico-12-lts-c-verde", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021677.jpg?v=1589476196"]}, {"id": "4936468332676", "title": "PAÑO BON-BRIL MALLA X 3", "category": "Aseo", "subcat": "Aseo Profesional", "price": 15286, "compare_price": null, "sku": "021319", "invima": "INVIMA 2021332676", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021319.jpg?v=1589580007", "handle": "tq-136-pano-bon-bril-malla-x-3-und", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021319.jpg?v=1589580007"]}, {"id": "4936468463748", "title": "BALDE ECONOMICO 10 LTS C/ VERDE", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7784, "compare_price": null, "sku": "020128", "invima": "INVIMA 2021463748", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020128.jpg?v=1589476167", "handle": "1a-600122-balde-economico-10-lts-c-verde", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020128.jpg?v=1589476167"]}, {"id": "4936469414020", "title": "AMBIENTADOR PLUGINS REPUESTO/ACEITES NATURALES TWINPACK X 2 - VAINILLA", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 28399, "compare_price": null, "sku": "027284", "invima": "INVIMA 2021414020", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027284.jpg?v=1589593085", "handle": "sc-7284-plugins-repuesto-aceites-naturales-twinpack-x-2-vainilla", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027284.jpg?v=1589593085"]}, {"id": "4936469610628", "title": "BOLSA ZIPLOC  PAQ. X 100 UND. 20 DE ANCHO X 24 DE ALTO CM", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 15909, "compare_price": null, "sku": "031736", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031736.jpg?v=1589481066", "handle": "bl-1736-bolsa-ziploc-paq-x-100-und-20-de-ancho-x-24-de-alto-cm", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031736.jpg?v=1589481066"]}, {"id": "4936470102148", "title": "BALDE ECONOMICO 10 LTS C/ ROJO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7784, "compare_price": null, "sku": "021678", "invima": "INVIMA 2021102148", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021678.jpg?v=1589476018", "handle": "1a-600121-balde-economico-10-lts-c-rojo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021678.jpg?v=1589476018"]}, {"id": "4936470462596", "title": "AMBIENTADOR BONAIRE VARITAS POMELO X 80 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 16071, "compare_price": null, "sku": "027017", "invima": "INVIMA 2021462596", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027017.jpg?v=1589474084", "handle": "bon-2718-ambientador-bonaire-varitas-pomelo-x-80-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027017.jpg?v=1589474084"]}, {"id": "4936470528132", "title": "AMBIENTADOR GLADE HAWAIIAN AEROSOL X 400 CC", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 14799, "compare_price": null, "sku": "027521", "invima": "INVIMA 2021528132", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027521.jpg?v=1589474391", "handle": "sc-8598-ambientador-glade-hawaiian-aerosol-x-400-cc", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027521.jpg?v=1589474391"]}, {"id": "4936470659204", "title": "BRILLADOR COMPLETO 60 X 20 CMS - 1A", "category": "Aseo", "subcat": "Aseo Profesional", "price": 58203, "compare_price": null, "sku": "021996", "invima": "INVIMA 2021659204", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021996.jpg?v=1589481350", "handle": "1a-200404-brillador-completo-60-x-20-cms-1a", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021996.jpg?v=1589481350"]}, {"id": "4936470954116", "title": "DESENGRASANTE SUMA GRILL D9  GALON X 5 LTS  - DIVERSEY", "category": "Aseo", "subcat": "Aseo Profesional", "price": 153952, "compare_price": null, "sku": "040141", "invima": "INVIMA 2021054116", "badge": "Mayorista Ahorro", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040141.jpg?v=1594313794", "handle": "jd-00771-desengrasante-suma-grill-d9-lav-galon-x-5-lts-jd-diversey", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040141.jpg?v=1594313794", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/71858PIS-SumaGrill-A4-es-CO-HRNC-1.jpg?v=1594394547", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/71858PIS-SumaGrill-A4-es-CO-HRNC-2.jpg?v=1594394547"]}, {"id": "4936471249028", "title": "AMBIENTADOR PLUGIN REPUESTO/BOTELLA ACEITE VAINILLA", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 17795, "compare_price": null, "sku": "020933", "invima": "INVIMA 2021249028", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020933.jpg?v=1589593035", "handle": "sc-8605-plugin-repuesto-botella-aceite-amb-vainilla", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020933.jpg?v=1589593035"]}, {"id": "4936471707780", "title": "AMBIENTADOR GLADE FRESH LEMON AEROSOL X 400 CC", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 14799, "compare_price": null, "sku": "040464", "invima": "INVIMA 2021707780", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040464.jpg?v=1589474361", "handle": "sc-8599-ambientador-glade-fresh-lemon-aerosol-x-400-cc", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040464.jpg?v=1589474361"]}, {"id": "4936471969924", "title": "AMBIENTADOR BONAIRE BABY FRESH AEROSOL X 400 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 10623, "compare_price": null, "sku": "040291", "invima": "INVIMA 2021069924", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040291.jpg?v=1589473253", "handle": "bon-10309-ambientador-bonaire-baby-fresh-aerosol-x-400-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040291.jpg?v=1589473253"]}, {"id": "4936472035460", "title": "AMBIENTADOR BONAIRE FRESCURA DE LAVANDA AEROSOL X 400 ML", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 10623, "compare_price": null, "sku": "021614", "invima": "INVIMA 2021035460", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021614.jpg?v=1589473294", "handle": "bon-10302-ambientador-bonaire-frescura-de-lavanda-aerosol-x-400-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021614.jpg?v=1589473294"]}, {"id": "4936472330372", "title": "AMBIENTADOR BONAIRE GEL REPUESTO -SURTIDO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 3704, "compare_price": null, "sku": "021751", "invima": "INVIMA 2021330372", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021751.jpg?v=1589473428", "handle": "bon-4851-ambientador-bonaire-gel-repuesto", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021751.jpg?v=1589473428"]}, {"id": "4936474787972", "title": "AROMATICA INFUSION HERBAL FLOR JAMAICA-FRUTOS AMARILLOS X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 11187, "compare_price": null, "sku": "031611", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031611.jpg?v=1589474501", "handle": "jb-12623-aromatica-infusion-herbal-flor-jamaica-frutos-amarillos-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031611.jpg?v=1589474501"]}, {"id": "4936475115652", "title": "CREMA LAVAPLATOS AXION X 850 GR", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 16765, "compare_price": null, "sku": "020571", "invima": "INVIMA 2021115652", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020571.jpg?v=1589563829", "handle": "cp-101234-crema-lavaplatos-axion-x-850-gr", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020571.jpg?v=1589563829"]}, {"id": "5240749064359", "title": "AMBIENTADOR GLADE AUTOMATICO APARATO + 1 RESPUESTO VAINILLA", "category": "Aseo", "subcat": "Aseo Profesional", "price": 50843, "compare_price": null, "sku": "040476", "invima": "INVIMA 2021064359", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-8096.webp?v=1726245413", "handle": "ambientador-glade-automatico-aparato-1-respuesto-hawaiian", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-8096.webp?v=1726245413"]}, {"id": "5272713494695", "title": "ESCOBA SUAVE NEGRA SIN MANGO - TRAPISOL -", "category": "Aseo", "subcat": "Aseo Profesional", "price": 8538, "compare_price": null, "sku": "022374", "invima": "INVIMA 2021494695", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022374.png?v=1591130135", "handle": "tra-es-2374-escoba-suave-negra-sin-mango-trapisol", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022374.png?v=1591130135"]}, {"id": "5276511928487", "title": "ALCOHOL GLICERINADO DESINFECTANTE PARA MANOS FCO X 1000 ML SPRAY - OSA", "category": "Aseo", "subcat": "Aseo Profesional", "price": 11913, "compare_price": null, "sku": "040654", "invima": "INVIMA 2021028487", "badge": "INVIMA Aprobado", "unit": "Unidad", "rating": "4.9 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040654.png?v=1591190998", "handle": "alcohol-glicerinado-desinf-manos-fco-x-1000-ml-spray-osa", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040654.png?v=1591190998"]}, {"id": "5282590752935", "title": "AROMATICA INFUSION HERBAL FRUTAL LIMONARIA-MORAS SILVESTRES X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 11187, "compare_price": null, "sku": "031774", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031774.png?v=1591303006", "handle": "jb-13189-aromatica-infusion-herbal-frutal-limonaria-moras-silvestres-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031774.png?v=1591303006"]}, {"id": "5282592981159", "title": "AMBIENTADOR GLADE TOQUE REPUESTO X 2 MANZANA CANELA", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 22628, "compare_price": null, "sku": "040531", "invima": "INVIMA 2021081159", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040531.jpg?v=1591391008", "handle": "sc-46420-glade-toque-repuesto-x-2-manzana-canela", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040531.jpg?v=1591391008"]}, {"id": "5282593833127", "title": "AMBIENTADOR GLADE TOQUE  UNIDAD APARATO - SURTIDO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 16399, "compare_price": null, "sku": "020035", "invima": "INVIMA 2021833127", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020035.jpg?v=1591390871", "handle": "sc-52700-glade-toque-ambientador-unidad-aparato-surtido", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020035.jpg?v=1591390871"]}, {"id": "5287856930983", "title": "BALDE CON ESCURRIDOR 33.1 LTS AMARILLO (RUBBERMAID)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 730219, "compare_price": 0, "sku": "023051", "invima": "INVIMA 2021030983", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023051_0e82539f-406e-4bd3-ae6d-d6f2f540f345.jpg?v=1591390390", "handle": "balde-con-escurridor-33-1-lts-amarillo-rubbermaid", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023051_0e82539f-406e-4bd3-ae6d-d6f2f540f345.jpg?v=1591390390"]}, {"id": "5346960212135", "title": "ATOMIZADOR PLASTICO CON PISTOLA X 1000 ML", "category": "Aseo", "subcat": "Aseo Profesional", "price": 11673, "compare_price": null, "sku": "021888", "invima": "INVIMA 2021212135", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021888.png?v=1594916999", "handle": "atomizador-plastico-con-pistola-x-1000-ml-govi", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021888.png?v=1594916999"]}, {"id": "5351715799207", "title": "P.A. SOBRE OF 1054 BLANCO 40 X 25 240 ROTULOS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 8591, "compare_price": null, "sku": "050490", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050490.jpg?v=1593113021", "handle": "p-a-sobre-of-1054-blanco-40-x-25-240-rotulos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050490.jpg?v=1593113021"]}, {"id": "5351716552871", "title": "BARRA DE SILICONA  GRUESA X UNIDAD", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 791, "compare_price": null, "sku": "059611", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/059611.jpg?v=1592502136", "handle": "barra-de-silicona-gruesa-x-unidad", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/059611.jpg?v=1592502136"]}, {"id": "5351717929127", "title": "BOLIGRAFO HIBRID GEL AZUL", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 7424, "compare_price": null, "sku": "052169", "invima": "INVIMA 2021029127", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052169.jpg?v=1592511002", "handle": "boligrafo-hibrid-gel-azul", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052169.jpg?v=1592511002"]}, {"id": "5351720714407", "title": "BOLIGRAFO HIBRID GEL ROJO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 7424, "compare_price": null, "sku": "052170", "invima": "INVIMA 2021714407", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052170.jpg?v=1592511114", "handle": "boligrafo-hibrid-gel-rojo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052170.jpg?v=1592511114"]}, {"id": "5351721435303", "title": "BORRADOR MIGA DE PAN REF. MP-20 - PELIKAN", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1690, "compare_price": null, "sku": "050245", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050245.png?v=1592512070", "handle": "borrador-miga-de-pan-ref-mp-20-pelikan", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050245.png?v=1592512070"]}, {"id": "5351722221735", "title": "BLOCK JEAN BOOK 80 CUAD. OFICIO 50 HOJAS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 4029, "compare_price": null, "sku": "050218", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050218.jpg?v=1592503267", "handle": "block-jean-book-80-cuad-oficio-50-hojas", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050218.jpg?v=1592503267"]}, {"id": "5351723270311", "title": "TINTA MARCADOR SECO X 30 ML ROJA PELIKAN", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 11844, "compare_price": null, "sku": "061888", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061888.png?v=1622241684", "handle": "tinta-marcador-seco-x-30-ml-roja-pelikan", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061888.png?v=1622241684"]}, {"id": "5385659416743", "title": "BATA DESECHABLE BLANCA CON VELCRO M/LARGA ESTANDAR", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 6187, "compare_price": null, "sku": "080160", "invima": "INVIMA 2021416743", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/081177_cf3ab791-1cd3-4f12-9bc5-a8fb1dd15ac3.jpg?v=1593185111", "handle": "bata-desechable-blanca-con-velcro-m-larga-estandar", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/081177_cf3ab791-1cd3-4f12-9bc5-a8fb1dd15ac3.jpg?v=1593185111"]}, {"id": "5773323665575", "title": "ALCOHOL ANTISEPTICO OSA GL X 3600 CC", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 35535, "compare_price": null, "sku": "020889", "invima": "INVIMA 2021665575", "badge": "INVIMA Aprobado", "unit": "Unidad", "rating": "4.9 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/alcoholosa.png?v=1599843910", "handle": "alcohol-antiseptico-osa-gl-x-3600-cc", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/alcoholosa.png?v=1599843910"]}, {"id": "5941485699239", "title": "BOLIGRAFO SEMI GEL 0.7 NEGRO OE 071F - OFFI-ESCO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 513, "compare_price": null, "sku": "061925", "invima": "INVIMA 2021699239", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061925.jpg?v=1602693792", "handle": "boligrafo-semi-gel-0-7-negro-oe-071f-offi-esco", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061925.jpg?v=1602693792"]}, {"id": "5941533081767", "title": "BORRADOR NATA REF. BR-40", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 220, "compare_price": null, "sku": "060588", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/11390.jpg?v=1635521566", "handle": "borrador-nata-ref-br-40", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/11390.jpg?v=1635521566"]}, {"id": "5988893622439", "title": "BISTURI GRANDE PLASTICO ALMA METALICA - XINFA", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 2501, "compare_price": null, "sku": "060612", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060612.jpg?v=1603894535", "handle": "bisturi-grande-plastico-alma-metalica-xinfa", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060612.jpg?v=1603894535"]}, {"id": "6277109547175", "title": "COMBO DISPENSADOR + PAPEL HIGIENICO JUMBO X 170 METROS - FAMILIA", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 152503, "compare_price": null, "sku": "021642", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021642.png?v=1774882881", "handle": "combo-dispensador-papel-higienico-jumbo-x-170-metros-familia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021642.png?v=1774882881"]}, {"id": "6550683320487", "title": "BOLSA BASURA VERDE TASK PRO 90 X 110 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 12778, "compare_price": null, "sku": "023446", "invima": "INVIMA 2021320487", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017082BOLSABASURAVERDETASKPRO9011010UNID.png?v=1614705296", "handle": "bolsa-basura-verde-task-pro-90-x-110-rollo-x-10-und", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017082BOLSABASURAVERDETASKPRO9011010UNID.png?v=1614705296"]}, {"id": "6550685941927", "title": "BOLSA BASURA VERDE TASK PRO 70 X 90  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6497, "compare_price": null, "sku": "023445", "invima": "INVIMA 2021041927", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017045BOLSABASURAVERDETASKPRO709010UNID.png?v=1614705253", "handle": "bolsa-basura-verde-task-pro-70-x-90-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017045BOLSABASURAVERDETASKPRO709010UNID.png?v=1614705253"]}, {"id": "6550687056039", "title": "BOLSA BASURA VERDE TASK PRO 60 X 70  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4664, "compare_price": null, "sku": "023444", "invima": "INVIMA 2021056039", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023444.png?v=1614689070", "handle": "bolsa-basura-verde-task-pro-60-x-70-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023444.png?v=1614689070"]}, {"id": "6550688071847", "title": "BOLSA BASURA VERDE TASK PRO 55 X 60  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 2499, "compare_price": null, "sku": "023443", "invima": "INVIMA 2021071847", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017076BOLSABASURAVERDETASKPRO556010UNID.png?v=1614705232", "handle": "olsa-basura-verde-task-pro-55-x-60-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017076BOLSABASURAVERDETASKPRO556010UNID.png?v=1614705232"]}, {"id": "6550706356391", "title": "BOLSA BASURA VERDE TASK PRO 46 X 46  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 1529, "compare_price": null, "sku": "023441", "invima": "INVIMA 2021356391", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017070BOLSABASURAVERDETASKPRO464610UNID.png?v=1614705198", "handle": "bolsa-basura-verde-task-pro-46-x-46-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017070BOLSABASURAVERDETASKPRO464610UNID.png?v=1614705198"]}, {"id": "6550736961703", "title": "BOLSA BASURA ROJA TASK PRO 90 X 110 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 12778, "compare_price": null, "sku": "023453", "invima": "INVIMA 2021061703", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017085BOLSABASURAROJOTASKPRO9011010UNI.png?v=1614705097", "handle": "bolsa-basura-roja-task-pro-90-x-110-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017085BOLSABASURAROJOTASKPRO9011010UNI.png?v=1614705097"]}, {"id": "6550769860775", "title": "BOLSA BASURA ROJA TASK PRO 80 X 110 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 11614, "compare_price": null, "sku": "023452", "invima": "INVIMA 2021860775", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017053BOLSABASURAROJOTASKPRO8011010UND.png?v=1614705069", "handle": "bolsa-basura-roja-task-pro-80-x-110-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017053BOLSABASURAROJOTASKPRO8011010UND.png?v=1614705069"]}, {"id": "6550772613287", "title": "BOLSA BASURA ROJA TASK PRO 70 X 90 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6497, "compare_price": null, "sku": "023451", "invima": "INVIMA 2021613287", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017049BOLSABASURAROJOTASKPRO607010UNID_b1e0f3e8-4193-469f-b3c5-bc588e6742d4.png?v=1614705048", "handle": "bolsa-basura-roja-task-pro-70-x-90-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017049BOLSABASURAROJOTASKPRO607010UNID_b1e0f3e8-4193-469f-b3c5-bc588e6742d4.png?v=1614705048"]}, {"id": "6550777954471", "title": "BOLSA BASURA ROJA TASK PRO 55 X 60 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 2731, "compare_price": null, "sku": "023449", "invima": "INVIMA 2021054471", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017079BOLSABASURAROJOTASKPRO556010UNID.png?v=1614704922", "handle": "bolsa-basura-roja-task-pro-55-x-60-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017079BOLSABASURAROJOTASKPRO556010UNID.png?v=1614704922"]}, {"id": "6550850928807", "title": "BOLSA BASURA ROJA TASK PRO 46 X 46 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 1618, "compare_price": null, "sku": "023447", "invima": "INVIMA 2021028807", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017074BOLSABASURAROJOTASKPRO464610UNID.png?v=1614704897", "handle": "bolsa-basura-roja-task-pro-46-x-46-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017074BOLSABASURAROJOTASKPRO464610UNID.png?v=1614704897"]}, {"id": "6551027974311", "title": "BOLSA BASURA NEGRA TASK PRO 90 X 110  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7321, "compare_price": null, "sku": "023440", "invima": "INVIMA 2021074311", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017081BOLSABASURANEGROTASKPRO9011010UNID.png?v=1614705419", "handle": "bolsa-basura-negra-task-pro-90-x-110-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017081BOLSABASURANEGROTASKPRO9011010UNID.png?v=1614705419"]}, {"id": "6551034658983", "title": "BOLSA BASURA NEGRA TASK PRO 70 X 90  ROLLO X 10 UND", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4304, "compare_price": null, "sku": "023439", "invima": "INVIMA 2021658983", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017046BOLSABASURANEGROTASKPRO709010UNID.png?v=1614705872", "handle": "bolsa-basura-negra-task-pro-70-x-90-rollo-x-10-und", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017046BOLSABASURANEGROTASKPRO709010UNID.png?v=1614705872"]}, {"id": "6551041048743", "title": "BOLSA BASURA NEGRA TASK PRO 60 X 70  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3394, "compare_price": null, "sku": "023438", "invima": "INVIMA 2021048743", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017055BOLSABASURANEGROTASKPRO607010UNID.png?v=1614706276", "handle": "bolsa-basura-negra-task-pro-60-x-70-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017055BOLSABASURANEGROTASKPRO607010UNID.png?v=1614706276"]}, {"id": "6551042457767", "title": "BOLSA BASURA NEGRA TASK PRO 55 X 60  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 1884, "compare_price": null, "sku": "023437", "invima": "INVIMA 2021457767", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/BOLSABASURANEGROTASKPRO556010UNID.png?v=1614706404", "handle": "bolsa-basura-negra-task-pro-55-x-60-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/BOLSABASURANEGROTASKPRO556010UNID.png?v=1614706404"]}, {"id": "6551045439655", "title": "BOLSA BASURA NEGRA TASK PRO 46 X 46  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 1413, "compare_price": null, "sku": "023435", "invima": "INVIMA 2021439655", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017069BOLSABASURANEGROTASKPRO464610UNID.png?v=1614706535", "handle": "bolsa-basura-negra-task-pro-46-x-46-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017069BOLSABASURANEGROTASKPRO464610UNID.png?v=1614706535"]}, {"id": "6551048093863", "title": "BOLSA BASURA BLANCA TASK PRO 90 X 110  ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 12121, "compare_price": null, "sku": "023434", "invima": "INVIMA 2021093863", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017080BOLSABASURABLANCOTASKPRO9011010UNID.png?v=1614706645", "handle": "bolsa-basura-blanca-task-pro-90-x-110-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017080BOLSABASURABLANCOTASKPRO9011010UNID.png?v=1614706645"]}, {"id": "6551051239591", "title": "BOLSA BASURA BLANCA TASK PRO 70 X 90 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6274, "compare_price": null, "sku": "023433", "invima": "INVIMA 2021239591", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017044BOLSABASURABLANCATASKPRO709010UNID.png?v=1614706873", "handle": "bolsa-basura-blanca-task-pro-70-x-90-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017044BOLSABASURABLANCATASKPRO709010UNID.png?v=1614706873"]}, {"id": "6551054188711", "title": "BOLSA BASURA BLANCA TASK PRO 60 X 70 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4649, "compare_price": null, "sku": "023432", "invima": "INVIMA 2021188711", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017050BOLSABASURABLANCATASKPRO607010UNID.png?v=1614707046", "handle": "bolsa-basura-blanca-task-pro-60-x-70-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017050BOLSABASURABLANCATASKPRO607010UNID.png?v=1614707046"]}, {"id": "6551056285863", "title": "BOLSA BASURA BLANCA TASK PRO 55 X 60 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 2594, "compare_price": null, "sku": "023431", "invima": "INVIMA 2021285863", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017073BOLSADEBASURABLANCATASKPRO556010UNID.png?v=1614707173", "handle": "bolsa-basura-blanca-task-pro-55-x-60-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017073BOLSADEBASURABLANCATASKPRO556010UNID.png?v=1614707173"]}, {"id": "6551061495975", "title": "BOLSA BASURA BLANCA TASK PRO 46 X 46 ROLLO X 10 UN", "category": "Aseo", "subcat": "Aseo Profesional", "price": 1537, "compare_price": null, "sku": "023429", "invima": "INVIMA 2021495975", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017068BOLSABASURABLANCOTASKPRO464610UNID.png?v=1614707464", "handle": "bolsa-basura-blanca-task-pro-46-x-46-rollo-x-10-un", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017068BOLSABASURABLANCOTASKPRO464610UNID.png?v=1614707464"]}, {"id": "6551067852967", "title": "BOLSA BASURA BLANCA TASK PRO 40 X 55 ROLLO X 10 UNIDADES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 1809, "compare_price": null, "sku": "023430", "invima": "INVIMA 2021852967", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017036BOLSABASURABLANCATASKPRO405510UNID.png?v=1614707741", "handle": "bolsa-basura-blanca-task-pro-40-x-55-rollo-x-10-unidades", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1017036BOLSABASURABLANCATASKPRO405510UNID.png?v=1614707741"]}, {"id": "6793648210087", "title": "BARRA DE SILICONA  DELGADA UNIDAD", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 707, "compare_price": null, "sku": "061849", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061849.jpg?v=1622146792", "handle": "cm-1849-barra-de-silicona-delgada-unidad", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061849.jpg?v=1622146792"]}, {"id": "6793651814567", "title": "BANDEJA ESCRITORIO MALLA SENCILLA DING-LI", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 19341, "compare_price": null, "sku": "060579", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060579.png?v=1622235191", "handle": "off-0579-bandeja-escritorio-malla-sencilla-ding-li", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060579.png?v=1622235191"]}, {"id": "6793652076711", "title": "BANDEJA ESCRITORIO DOBLE MALLA - DINGLI", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 31734, "compare_price": null, "sku": "060669", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/papelera-de-escritorio-doble-bandeja-7701016759205.jpg?v=1635520895", "handle": "off-0669-bandeja-escritorio-doble-malla-dingli", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/papelera-de-escritorio-doble-bandeja-7701016759205.jpg?v=1635520895"]}, {"id": "6929761960103", "title": "BOLIGRAFO SEMI GEL 0.7 MORADO OE 077F - OFFI-ESCO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 615, "compare_price": null, "sku": "061930", "invima": "INVIMA 2021060103", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061930.jpg?v=1627073062", "handle": "boligrafo-semi-gel-0-7-morado-oe-077f-offi-esco", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061930.jpg?v=1627073062"]}, {"id": "6929779064999", "title": "BLANCOX TRADICIONAL \"PODER NATURAL\" GARRAFA X 20 LTS", "category": "Aseo", "subcat": "Aseo Profesional", "price": 60541, "compare_price": null, "sku": "040522", "invima": "INVIMA 2021064999", "badge": "Mayorista Ahorro", "unit": "Garrafa 20L", "rating": "4.9 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040522_15ce9d7c-951f-409f-8d1f-ad13aaf622e7.jpg?v=1627073597", "handle": "blancox-tradicional-poder-natural-garrafa-x-20-lts", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040522_15ce9d7c-951f-409f-8d1f-ad13aaf622e7.jpg?v=1627073597"]}, {"id": "7562078060802", "title": "TAPABOCA TERMOSELLADO EMPAQUE INDIVIDUAL CAJA X 50 UND BLANCO O AZUL", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 10130, "compare_price": null, "sku": "021155", "invima": "INVIMA 2021060802", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021238_204714c6-23a2-495d-8a69-2688449ad88a.jpg?v=1642781175", "handle": "tapaboca-termosellado-empaque-individual-caja-x-50-und-blanco-o-azul", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021238_204714c6-23a2-495d-8a69-2688449ad88a.jpg?v=1642781175"]}, {"id": "7703043637506", "title": "AROMATICA LIQUIDA FRUTALIA CLASICA SURTIDA CAJA X 10 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 12626, "compare_price": null, "sku": "032388", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032388_a9947168-551e-42c4-87a8-a6d8446b607d.png?v=1654094761", "handle": "aromatica-liquida-frutalia-clasica-surtida-caja-x-10-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032388_a9947168-551e-42c4-87a8-a6d8446b607d.png?v=1654094761"]}, {"id": "7703046193410", "title": "AROMATICA LIQUIDA FRUTALIA MELOCOTON & CARAMELO CAJA X 10 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 12013, "compare_price": null, "sku": "032394", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032394.png?v=1654093956", "handle": "aromatica-liquida-frutalia-melocoton-caramelo-caja-x-10-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032394.png?v=1654093956"]}, {"id": "7703047569666", "title": "AROMATICA LIQUIDA FRUTALIA FRAMBUESA & TE MATCHA CAJA X 10 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 12626, "compare_price": null, "sku": "032393", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032393.png?v=1654094103", "handle": "aromatica-liquida-frutalia-frambuesa-te-matcha-caja-x-10-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032393.png?v=1654094103"]}, {"id": "7703049535746", "title": "AROMATICA LIQUIDA FRUTALIA HERBAL SURTIDA CAJA X 10 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 12626, "compare_price": null, "sku": "032390", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032390.png?v=1654094410", "handle": "aromatica-liquida-frutalia-herbal-surtida-caja-x-10-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032390.png?v=1654094410"]}, {"id": "7703050354946", "title": "AROMATICA LIQUIDA FRUTALIA LIMON & JENGIBRE CAJA X 10 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 12626, "compare_price": null, "sku": "032392", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032392.png?v=1654094542", "handle": "aromatica-liquida-frutalia-limon-jengibre-caja-x-10-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032392.png?v=1654094542"]}, {"id": "7703051043074", "title": "AROMATICA LIQUIDA FRUTALIA GRANADA & ARANDANO CAJA X 10 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 12626, "compare_price": null, "sku": "032391", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032391.png?v=1654094700", "handle": "aromatica-liquida-frutalia-granada-arandano-caja-x-10-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032391.png?v=1654094700"]}, {"id": "7704811340034", "title": "BOLIGRAFO BIC CRISTAL NEGRO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 743, "compare_price": null, "sku": "050229", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050229.jpg?v=1655903199", "handle": "boligrafo-bic-cristal-negro", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050229.jpg?v=1655903199"]}, {"id": "7704811503874", "title": "BOLIGRAFO KILOMETRICO 100 RETRACTIL NEGRO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 934, "compare_price": null, "sku": "060179", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060179.jpg?v=1655902982", "handle": "boligrafo-kilometrico-100-retractil-negro", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060179.jpg?v=1655902982"]}, {"id": "7704811569410", "title": "BOLIGRAFO SEMI GEL 0.7 ROJO OE 071F - OFFI-ESCO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 513, "compare_price": null, "sku": "061926", "invima": "INVIMA 2021569410", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061926.jpg?v=1655902939", "handle": "boligrafo-semi-gel-0-7-rojo-oe-071f-offi-esco", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061926.jpg?v=1655902939"]}, {"id": "7704811602178", "title": "ROLLO TERMICO PARA REGISTRADORA 80 MM X 60 MTS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 5901, "compare_price": null, "sku": "050758", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050758.jpg?v=1655902920", "handle": "rollo-termico-p-registradora-80-mm-x-60-mts", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050758.jpg?v=1655902920"]}, {"id": "7704811667714", "title": "JUEGO DE TAPAS EN CARTON OFICIO 600 GR REFUERZO PAPEL C/PESTAÑA", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 2350, "compare_price": null, "sku": "061862", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061862.png?v=1655902866", "handle": "juego-de-tapas-en-carton-oficio-600-gr-refuerzo-papel-c-pestana", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061862.png?v=1655902866"]}, {"id": "7704811831554", "title": "RESMA PAPEL BOND 1/2 CARTA X 500", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 13749, "compare_price": null, "sku": "059786", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Resma 500 hjs", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/059786.jpg?v=1655902452", "handle": "resma-papel-bond-1-2-carta-x-500", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/059786.jpg?v=1655902452"]}, {"id": "7704812028162", "title": "PILA EVEREADY ALCALINA GOLD AA BL X 2", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 4313, "compare_price": null, "sku": "060713", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060713.png?v=1655902337", "handle": "pila-eveready-alcalina-gold-aa-bl-x-2", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060713.png?v=1655902337"]}, {"id": "7704812060930", "title": "BOLIGRAFO SEMI GEL 0.7 AZUL OE 071F - OFFI-ESCO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 513, "compare_price": null, "sku": "061927", "invima": "INVIMA 2021060930", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061927.jpg?v=1655902315", "handle": "boligrafo-semi-gel-0-7-azul-oe-071f-offi-esco", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061927.jpg?v=1655902315"]}, {"id": "7704812093698", "title": "BISTURI GRANDE TOTALMENTE METALICO INDUSTRIAL - XINFA", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 5441, "compare_price": null, "sku": "060582", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060582.jpg?v=1655902290", "handle": "bisturi-grande-totalmente-metalico-industrial-xinfa", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060582.jpg?v=1655902290"]}, {"id": "7704812192002", "title": "BOLIGRAFO RETRACTIL PILOT NEGRO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1266, "compare_price": null, "sku": "060683", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060683.jpg?v=1655902227", "handle": "boligrafo-retractil-pilot-negro", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060683.jpg?v=1655902227"]}, {"id": "7704812421378", "title": "BOLIGRAFO BIC CRISTAL ROJO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 743, "compare_price": null, "sku": "050230", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050230.jpg?v=1655901888", "handle": "boligrafo-bic-cristal-rojo", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050230.jpg?v=1655901888"]}, {"id": "7704812945666", "title": "BOLIGRAFO CRISTAL ECONOMICO NEGRO - CORONA", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 294, "compare_price": null, "sku": "060591", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060591.jpg?v=1654290316", "handle": "boligrafo-cristal-economico-negro-corona", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060591.jpg?v=1654290316"]}, {"id": "7704813043970", "title": "BOLIGRAFO SEMI GEL 0.7 NEGRO RETRACTIL TRAZO FINO OE052F OFFI-ESCO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 752, "compare_price": null, "sku": "062192", "invima": "INVIMA 2021043970", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062192.jpg?v=1699973217", "handle": "boligrafo-semi-gel-0-7-negro-retractil-trazo-fino-oe052f-offi-esco", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062192.jpg?v=1699973217"]}, {"id": "7704813142274", "title": "BOLIGRAFO KILOMETRICO 100 TAPA NEGRO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 839, "compare_price": null, "sku": "059885", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/059885.png?v=1654290120", "handle": "boligrafo-kilometrico-100-tapa-negro", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/059885.png?v=1654290120"]}, {"id": "7704813175042", "title": "BOLIGRAFO BIC CRISTAL AZUL", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 743, "compare_price": null, "sku": "050228", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050228.png?v=1654290046", "handle": "boligrafo-bic-cristal-azul", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050228.png?v=1654290046"]}, {"id": "7716444569858", "title": "GUANTE DE NITRILO TALLA S AZUL CAJA X 100 UND CAL. 4 SEMPERGUARD", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 22630, "compare_price": null, "sku": "081481", "invima": "INVIMA 2021569858", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/081481.png?v=1655305125", "handle": "guante-de-nitrilo-talla-s-azul-caja-x-100-und-cal-4-semperguard", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/081481.png?v=1655305125"]}, {"id": "7716445683970", "title": "GUANTE DE NITRILO TALLA M AZUL CAJA X 100 UND CAL. 4 SEMPERGUARD", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 22630, "compare_price": null, "sku": "081482", "invima": "INVIMA 2021683970", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/081481_11e5909c-0630-4ba7-8f73-a7e7338b70bb.png?v=1655305156", "handle": "guante-de-nitrilo-talla-m-azul-caja-x-100-und-cal-4-semperguard", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/081481_11e5909c-0630-4ba7-8f73-a7e7338b70bb.png?v=1655305156"]}, {"id": "7716464034050", "title": "GUANTE DE NITRILO TALLA L AZUL CAJA X 100 UND CAL. 8 SEMPERGUARD", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 42828, "compare_price": null, "sku": "080362", "invima": "INVIMA 2021034050", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/080362.jpg?v=1655305698", "handle": "guante-de-nitrilo-talla-l-azul-caja-x-100-und-cal-8-semperguard", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/080362.jpg?v=1655305698"]}, {"id": "8153567363330", "title": "PAÑO PARA COCINA FAMITEX - BLANCO BOLSA X 10 PAÑOS (F-74302)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 19430, "compare_price": null, "sku": "010200", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010200.png?v=1694709470", "handle": "pano-para-cocina-famitex-blanco-bolsa-x-10-panos-f-74302", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010200.png?v=1694709470"]}, {"id": "8166151618818", "title": "SELLADOR DE PISOS GL X 3750 C.C. - OUI", "category": "Aseo", "subcat": "Aseo Profesional", "price": 75137, "compare_price": null, "sku": "027497", "invima": "INVIMA 2021618818", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027497.png?v=1696082302", "handle": "sellador-de-pisos-gl-x-3750-c-c-oui", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027497.png?v=1696082302"]}, {"id": "8349417898242", "title": "AZUCAR BLANCA X 1000 GRS. MANUELITA", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5558, "compare_price": null, "sku": "030228", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030228.jpg?v=1708371091", "handle": "azucar-blanca-x-1000-grs-manuelita", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030228.jpg?v=1708371091"]}, {"id": "8349420257538", "title": "AZUCAR BLANCA X 2500 GRS. MANUELITA", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 14245, "compare_price": null, "sku": "030229", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030229.png?v=1708371374", "handle": "azucar-blanca-x-2500-grs-manuelita", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030229.png?v=1708371374"]}, {"id": "8349422289154", "title": "AZUCAR BLANCA X 500 GRS. MANUELITA", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 2782, "compare_price": null, "sku": "030224", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030224.png?v=1708371609", "handle": "azucar-blanca-x-500-grs-manuelita", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030224.png?v=1708371609"]}, {"id": "8349422584066", "title": "AZUCAR MORENA X 2500 GRS. MANUELITA", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 14245, "compare_price": null, "sku": "030225", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030225.png?v=1708371766", "handle": "copia-de-azucar-blanca-x-500-grs-manuelita", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030225.png?v=1708371766"]}, {"id": "8772193026306", "title": "AMARRE NEGRO 4.8 X 20 CM PQ. X 100 UD", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 8241, "compare_price": null, "sku": "022991", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022991.jpg?v=1723753588", "handle": "amarre-negro-4-8-x-20-cm-pq-x-100-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022991.jpg?v=1723753588"]}, {"id": "8780468519170", "title": "BORRADOR ESCOBILLA STAEDTLER", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 9300, "compare_price": null, "sku": "050803", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/050803.jpg?v=1724267285", "handle": "borrador-escobilla-staedtler", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/050803.jpg?v=1724267285"]}, {"id": "8806111379714", "title": "MANGO ALUMINIO 150 CM SEMI INDUSTRIAL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 20639, "compare_price": null, "sku": "023801", "invima": "INVIMA 2021379714", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023801.jpg?v=1726779410", "handle": "mango-aluminio-150-cm-semi-industrial", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023801.jpg?v=1726779410"]}, {"id": "8913910563074", "title": "BOLSA BASURA REC. NEGRA 70 X 100 CL 2 PAQ. X 6 UND", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4560, "compare_price": null, "sku": "020730", "invima": "INVIMA 2021563074", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020730.jpg?v=1739281781", "handle": "bolsa-basura-rec-negra-70-x-100-cl-2-paq-x-6-und", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020730.jpg?v=1739281781"]}, {"id": "8913913217282", "title": "BOLSA BASURA REC. BLANCA 100 X 120 CM CL. 2 PAQ. X 6 UND", "category": "Aseo", "subcat": "Aseo Profesional", "price": 8940, "compare_price": null, "sku": "023032", "invima": "INVIMA 2021217282", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023032.png?v=1739281937", "handle": "bolsa-basura-rec-blanca-100-x-120-cm-cl-2-paq-x-6-und", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023032.png?v=1739281937"]}, {"id": "8913913970946", "title": "BOLSA BASURA REC. VERDE 100 X 120 CM. CL. 2 PAQ. X 6", "category": "Aseo", "subcat": "Aseo Profesional", "price": 8940, "compare_price": null, "sku": "022752", "invima": "INVIMA 2021070946", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022752.jpg?v=1739282007", "handle": "bolsa-basura-rec-verde-100-x-120-cm-cl-2-paq-x-6", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022752.jpg?v=1739282007"]}, {"id": "8913914757378", "title": "CEPILLO FIBRA PLASTICA - SUAVE PARA LAVAR AUTOS SIN MANGO - FULLER", "category": "Aseo", "subcat": "Aseo Profesional", "price": 19499, "compare_price": null, "sku": "022966", "invima": "INVIMA 2021757378", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022966.jpg?v=1739282149", "handle": "cepillo-fibra-plastica-suave-para-lavar-autos-sin-mango-fuller", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022966.jpg?v=1739282149"]}, {"id": "8913920622850", "title": "BEBIDA HIDRATANDE ACTIVADE", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 2113, "compare_price": null, "sku": "032430", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032430.jpg?v=1739282545", "handle": "bebida-hidratande-activade", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032430.jpg?v=1739282545"]}, {"id": "8913921999106", "title": "TENEDOR PACIFICO UNIDAD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 1617, "compare_price": null, "sku": "032500", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032500.jpg?v=1739282715", "handle": "tenedor-pacifico-unidad", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032500.jpg?v=1739282715"]}, {"id": "8913923080450", "title": "CUCHARA PACIFICO UNIDAD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 1617, "compare_price": null, "sku": "032501", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032501.jpg?v=1739282809", "handle": "cuchara-pacifico-unidad", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032501.jpg?v=1739282809"]}, {"id": "8913925439746", "title": "AROMATICA TISANA LIMONARIA BON AMI  X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 1899, "compare_price": null, "sku": "032450", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032450.png?v=1739284974", "handle": "aromatica-tisana-limonaria-bon-ami-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032450.png?v=1739284974"]}, {"id": "8913926521090", "title": "CUCHILLO PACIFICO UNIDAD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 1981, "compare_price": null, "sku": "032502", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (30 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032502.png?v=1739283210", "handle": "cuchillo-pacifico-unidad", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032502.png?v=1739283210"]}, {"id": "8913926881538", "title": "PLATO CARTON PANDO 23 CM X UND", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 638, "compare_price": null, "sku": "032337", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032337.jpg?v=1739283311", "handle": "plato-carton-pando-23-cm-x-und", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032337.jpg?v=1739283311"]}, {"id": "8913932779778", "title": "PAPEL HIG. BLANCO HOJA DOBLE  SCOTT ROLLO X 25 MTS (K-9262)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 2468, "compare_price": null, "sku": "011046", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011046.png?v=1739283916", "handle": "papel-hig-blanco-hoja-doble-scott-rollo-x-25-mts-k-9262", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011046.png?v=1739283916"]}, {"id": "8913941987586", "title": "AROMATICA TISANA MANZANILLA BON AMI  X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 1899, "compare_price": null, "sku": "032454", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032454.png?v=1739285038", "handle": "aromatica-tisana-limonaria-bon-ami-x-20-ud-copia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032454.png?v=1739285038"]}, {"id": "8913947623682", "title": "BLOQUEADOR SOLAR TANGA FACTOR 100 FCO X 130 ML", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 79535, "compare_price": null, "sku": "053010", "invima": "INVIMA 2021623682", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/053010.png?v=1739285667", "handle": "bloqueador-solar-tanga-factor-100-fco-x-130-ml", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/053010.png?v=1739285667"]}, {"id": "8914041569538", "title": "CORRECTOR LIQUIDO LAPIZ X 9 ML - POINTER", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1392, "compare_price": null, "sku": "062585", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062585.jpg?v=1739294887", "handle": "corrector-liquido-lapiz-x-9-ml-pointer", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062585.jpg?v=1739294887"]}, {"id": "8914052743426", "title": "ALCOHOL ANTISEPTICO OSA FCO X 700 ML PLASTICO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 7367, "compare_price": null, "sku": "020007", "invima": "INVIMA 2021743426", "badge": "INVIMA Aprobado", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020007.jpg?v=1739296483", "handle": "alcohol-antiseptico-osa-fco-x-700-ml-plastico", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020007.jpg?v=1739296483"]}, {"id": "8914061885698", "title": "GUANTE POLIESTER REC. POLIURETANO FLEXPOLY TALLA 9 REF. 11916709", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 7022, "compare_price": null, "sku": "080878", "invima": "INVIMA 2021885698", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/080878.png?v=1739297142", "handle": "guante-poliester-rec-poliuretano-flexpoly-talla-9-ref-11916709", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/080878.png?v=1739297142"]}, {"id": "8915866190082", "title": "(K-6237)  WYPALL L10 AUTODISPENSADO BLANCO ROLLO REG. 500 PAÑOS", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 43038, "compare_price": null, "sku": "011114", "invima": "INVIMA 2021190082", "badge": "Marca Líder", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011114.jpg?v=1739486621", "handle": "k-6237-wypall-l10-autodispensado-blanco-rollo-reg-500-panos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011114.jpg?v=1739486621"]}, {"id": "8915866353922", "title": "(K-6053)  WYPALL X60 COLORES ROLLO X 150 PAÑOS AZUL", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 53335, "compare_price": null, "sku": "011115", "invima": "INVIMA 2021353922", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011115.jpg?v=1739486681", "handle": "k-6053-wypall-x60-colores-rollo-x-150-panos-azul", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011115.jpg?v=1739486681"]}, {"id": "8915866976514", "title": "(K-6078)  WYPALL X60 COLORES ROLLO X 150 PAÑOS VERDE", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 53335, "compare_price": null, "sku": "011116", "invima": "INVIMA 2021076514", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011116.jpg?v=1739486663", "handle": "k-6078-wypall-x60-colores-rollo-x-150-panos-verde", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011116.jpg?v=1739486663"]}, {"id": "8945046978818", "title": "BALDE CON ESCURRIDOR 12 LTS AMARILLO MAT. RECUP", "category": "Aseo", "subcat": "Aseo Profesional", "price": 46616, "compare_price": null, "sku": "023780", "invima": "INVIMA 2021078818", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023780.png?v=1741038214", "handle": "balde-con-escurridor-12-lts-amarillo-mat-recup", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023780.png?v=1741038214"]}, {"id": "9002365026562", "title": "JABON MANOS ECO HUMECTANTE COSMETICO GL X 3800 C.C. - OUI", "category": "Aseo", "subcat": "Aseo Profesional", "price": 16121, "compare_price": 18750, "sku": "027133", "invima": "INVIMA 2021026562", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027133.png?v=1745422509", "handle": "jabon-manos-eco-humectante-cosmetico-gl-x-3800-c-c-oui", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027133.png?v=1745422509"]}, {"id": "9002401628418", "title": "ATOMIZADOR PLASTICO CON PISTOLA USO GENERAL 1000 ML BLANCO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 17398, "compare_price": null, "sku": "023708", "invima": "INVIMA 2021628418", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023708.jpg?v=1745425631", "handle": "atomizador-plastico-con-pistola-uso-general-1000-ml-blanco", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023708.jpg?v=1745425631"]}, {"id": "9002405986562", "title": "ESCOBA SUAVE PLANA IMPERIAL BLANCA - TRAPISOL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 8538, "compare_price": null, "sku": "023179", "invima": "INVIMA 2021086562", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023179.jpg?v=1745425930", "handle": "escoba-suave-plana-imperial-blanca-trapisol", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023179.jpg?v=1745425930"]}, {"id": "9002417881346", "title": "MANGO METALICO DE 80 CM  PARA RECOGEDOR NEGRO - TRAPISOL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7338, "compare_price": null, "sku": "023790", "invima": "INVIMA 2021881346", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023790.jpg?v=1745426888", "handle": "mango-metalico-de-80-cm-para-recogedor-negro-trapisol", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023790.jpg?v=1745426888"]}, {"id": "9002418110722", "title": "MANGO METALICO DE 80 CM  PARA RECOGEDOR ROJO - TRAPISOL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7338, "compare_price": null, "sku": "022856", "invima": "INVIMA 2021110722", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022856.jpg?v=1745426954", "handle": "mango-metalico-de-80-cm-para-recogedor-negro-trapisol-copia", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022856.jpg?v=1745426954"]}, {"id": "4936475410564", "title": "SERVILLETA BLANCA EXTRAFINA DE LUJO PQ. X 50 UD (F-72506)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 5770, "compare_price": null, "sku": "010117", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010117.jpg?v=1774885093", "handle": "f-72501-servilleta-blanca-extrafina-de-lujo-pq-x-50-ud-familia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010117.jpg?v=1774885093"]}, {"id": "8935863910658", "title": "(K-4202)  SERVILLETA KLEENEX DINNER CUADRADA BLANCA PAQ X 100 UND", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 13025, "compare_price": null, "sku": "011097", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Paquete", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/30204202.png?v=1773768739", "handle": "k-4202-servilleta-kleenex-dinner-cuadrada-blanca-paq-x-100-und", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/30204202.png?v=1773768739"]}, {"id": "4894702567556", "title": "AROMATICA JAIBEL PANELA B X 25 SOBRES SURTIDOS", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 6881, "compare_price": null, "sku": "030241", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030241.jpg?v=1588361614", "handle": "jb-12595-aromatica-jaibel-panela-b-x-25-sobres-surtidos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030241.jpg?v=1588361614"]}, {"id": "8349415473410", "title": "AZUCAR BLANCA TUBITOS PAQ. X 200 UNIDADES MANUELITA", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 8163, "compare_price": null, "sku": "031093", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/031093.png?v=1708370789", "handle": "azucar-blanca-tubitos-paq-x-200-unidades-manuelita", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/031093.png?v=1708370789"]}, {"id": "9009469718786", "title": "HARAGAN ESCURRIDOR CUCHILLA 70 CM CABO 1.50", "category": "Aseo", "subcat": "Aseo Profesional", "price": 57278, "compare_price": null, "sku": "020545", "invima": "INVIMA 2021718786", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020555.jpg?v=1588383658", "handle": "haragan-escurridor-cuchilla-50-cm-cabo-150-copia", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020555.jpg?v=1588383658"]}, {"id": "4894698700932", "title": "LIMPION DE TOALLA BLANCO 90 X 100 CM", "category": "Aseo", "subcat": "Aseo Profesional", "price": 14518, "compare_price": null, "sku": "020710", "invima": "INVIMA 2021700932", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020710.jpg?v=1588386756", "handle": "id-022-limpion-de-toalla-blanco-90-x-100-cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020710.jpg?v=1588386756"]}, {"id": "4894699683972", "title": "MECHA TRAPERO REPUESTO ROJA X 500 GRS", "category": "Aseo", "subcat": "Aseo Profesional", "price": 10790, "compare_price": null, "sku": "021723", "invima": "INVIMA 2021683972", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021723.jpg?v=1588395341", "handle": "tra-mchh003r-mecha-trapero-repuesto-roja-x-500-grs", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021723.jpg?v=1588395341"]}, {"id": "4894705746052", "title": "VASO CARTON 4 OZ DOMINGO PAQ. X 50 GEN-IMPRESO", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4998, "compare_price": null, "sku": "031153", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031153.jpg?v=1588388140", "handle": "mult-0400001-vaso-carton-4-oz-domingo-paq-x-50-gen-impreso", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031153.jpg?v=1588388140"]}, {"id": "4894705778820", "title": "VASO CARTON 4 OZ DOMINGO PAQ. X 50 SIN IMPRESION BLANCO", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4760, "compare_price": null, "sku": "031495", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031495.jpg?v=1588388081", "handle": "mult-0400002-vaso-carton-4-oz-domingo-paq-x-50-sin-impresion-blanco", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031495.jpg?v=1588388081"]}, {"id": "4894705811588", "title": "VASO CARTON 6 OZ  PAQ X 50 GENERICO - BARVAL", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5447, "compare_price": null, "sku": "032047", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032047.png?v=1752590609", "handle": "mult-0600028-vaso-carton-6-oz-domingo-paq-x-50-sin-impresion-blanco", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032047.png?v=1752590609"]}, {"id": "4894705909892", "title": "VASO CARTON 9 OZ PAQ. X 40 SIN IMPRESION BLANCO - BARVAL", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 6039, "compare_price": null, "sku": "032045", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031381.jpg?v=1588387963", "handle": "mult-0900006-vaso-carton-9-oz-paq-x-40-sin-impresion-blanco-domingo", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031381.jpg?v=1588387963"]}, {"id": "4894708105348", "title": "JABON LIQUIDO SUAVE RPTO X 1000 ML FAMILIA (F-80506)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 46655, "compare_price": null, "sku": "021641", "invima": "INVIMA 2021105348", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021641_1f56f4f8-00b9-4d09-a615-aa29d16bafbf.png?v=1694710383", "handle": "f-80500-jabon-liquido-suave-rpto-x-1000-ml-familia", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021641_1f56f4f8-00b9-4d09-a615-aa29d16bafbf.png?v=1694710383"]}, {"id": "4894708138116", "title": "LIMPION INDUSTRIAL NATURAL HD X 400 MTS (F-74167)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 91283, "compare_price": null, "sku": "010805", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010805.jpg?v=1774886193", "handle": "f-74167-limpion-industrial-natural-hd-x-400-mts-familia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010805.jpg?v=1774886193"]}, {"id": "4894708629636", "title": "PAPEL JUMBO TORK BLANCO H.D. X 250 MTS PACA X 4 ROLLOS - F-71157", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 103501, "compare_price": null, "sku": "011105", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011105.jpg?v=1735232061", "handle": "f-71157-papel-jumbo-blanco-h-d-x-250-mts-paca-x-4-rollos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011105.jpg?v=1735232061"]}, {"id": "4936468365444", "title": "SILICONA MULTIUSOS GL. X 3000 CC POTENTE", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 77461, "compare_price": null, "sku": "027022", "invima": "INVIMA 2021365444", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027022.jpg?v=1589593927", "handle": "pot-43001-silicona-multiusos-gl-x-3000-cc-potente", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027022.jpg?v=1589593927"]}, {"id": "5272709398695", "title": "SEÑAL DE PREVENCION AMARILLA PISO MOJADO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 30139, "compare_price": null, "sku": "020444", "invima": "INVIMA 2021398695", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020444.png?v=1738872645", "handle": "est-ri6110-senal-de-prevencion-peligro-vertical-puerta-x-49-cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020444.png?v=1738872645"]}, {"id": "5272712872103", "title": "PLUMERO PEQUEÑO ARCOIRIS M/PLASTICO - TRAPISO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7854, "compare_price": null, "sku": "020908", "invima": "INVIMA 2021872103", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020908.jpg?v=1591210406", "handle": "tra-tras-009-plumero-pequeno-arcoiris-m-plastico-trapiso", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020908.jpg?v=1591210406"]}, {"id": "5351725301927", "title": "PERFORADORA DE 1 HUECO TIPO ALICATE - GENMES", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 5215, "compare_price": null, "sku": "051967", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1783479.jpg?v=1593548655", "handle": "perforadora-de-1-hueco-tipo-alicate-genmes", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/1783479.jpg?v=1593548655"]}, {"id": "5445227184295", "title": "JABON DE MANOS ANTISEPTICO SOFT CARE PLUS FREE GL X 5 LITROS - DIVERSEY", "category": "Aseo", "subcat": "Aseo Profesional", "price": 110113, "compare_price": null, "sku": "040517", "invima": "INVIMA 2021184295", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040517.jpg?v=1594312241", "handle": "jabon-de-manos-antiseptico-soft-care-plus-free-gl-x-5-litros", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040517.jpg?v=1594312241", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/76195-PIS-Soft_Care_Free_Foam-A4-es-CO-HRNC-2.jpg?v=1594399220"]}, {"id": "7040751304871", "title": "GEL ANTISEPTICO SOFT CARE DES E H5  GL X 5 LTS  DIVERSEY", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 179745, "compare_price": null, "sku": "026990", "invima": "INVIMA 2021304871", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/026990.png?v=1631716426", "handle": "gel-antiseptico-soft-care-des-e-h5-gl-x-5-lts-diversey", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/026990.png?v=1631716426"]}, {"id": "7748809621762", "title": "ACEITE DE OLIVA VIRGE EXTRA GOURMET FRASCO X 500 ML", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 59120, "compare_price": null, "sku": "032304", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032305.png?v=1658516514", "handle": "aceite-de-oliva-virge-extra-hoji-bco-abril-frasco-x-500-ml", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032305.png?v=1658516514"]}, {"id": "8062099685634", "title": "ATOMIZADOR ENVASE TRANSP. X 500 CC CON PISTOLA", "category": "Aseo", "subcat": "Aseo Profesional", "price": 1958, "compare_price": null, "sku": "021770", "invima": "INVIMA 2021685634", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021770.jpg?v=1688136500", "handle": "atomizador-envase-transp-x-500-cc-con-pistola", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021770.jpg?v=1688136500"]}, {"id": "8153581879554", "title": "JABON LIQUIDO CABELLO - CUERPO BOTELLA X 475 ML (F-80560)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 29267, "compare_price": null, "sku": "010750", "invima": "INVIMA 2021879554", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010750.png?v=1712779163", "handle": "jabon-liquido-cabello-cuerpo-botella-x-475-ml-f-80560", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010750.png?v=1712779163"]}, {"id": "8779718426882", "title": "ESPONJA METALIZADA BRIO X 1 - BRIO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3760, "compare_price": null, "sku": "023692", "invima": "INVIMA 2021426882", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023692.png?v=1784653352", "handle": "esponja-metalizada-brio-x-1-brio", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023692.png?v=1784653352"]}, {"id": "8906326147330", "title": "DETERGENTE ALCALINO EASYFOAM G X 23 LTS", "category": "Aseo", "subcat": "Aseo Profesional", "price": 550102, "compare_price": null, "sku": "040136", "invima": "INVIMA 2021147330", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040136.jpg?v=1738334998", "handle": "detergente-alcalino-easyfoam-g-x-23-lts", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040136.jpg?v=1738334998"]}, {"id": "8913929830658", "title": "DIVOSAN TC 86 DETERGENTE ALCALINO TAMBOR X 20 LTS 24KG - DIVERSEY", "category": "Aseo", "subcat": "Aseo Profesional", "price": 653279, "compare_price": null, "sku": "040556", "invima": "INVIMA 2021830658", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040556.jpg?v=1739283629", "handle": "divosan-tc-86-detergente-alcalino-tambor-x-20-lts-24kg", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040556.jpg?v=1739283629"]}, {"id": "8914056347906", "title": "PROTECTOR AUDITIVO TIPO SOMBRILLA REF. A-2058", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 2435, "compare_price": null, "sku": "080449", "invima": "INVIMA 2021347906", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/080449.png?v=1739296726", "handle": "protector-auditivo-tipo-sombrilla-ref-a-2058", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/080449.png?v=1739296726"]}, {"id": "9002409492738", "title": "JABON LAVALOZA LIQUIDO GALON X 3800 C.C", "category": "Aseo", "subcat": "Aseo Profesional", "price": 22276, "compare_price": null, "sku": "027356", "invima": "INVIMA 2021492738", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027356.jpg?v=1745426212", "handle": "jabon-lavaloza-liquido-galon-x-3800-c-c", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027356.jpg?v=1745426212"]}, {"id": "9002411131138", "title": "LIMPIADOR DESINFECTANTE LAVANDA GALON X 3800 C.C", "category": "Aseo", "subcat": "Aseo Profesional", "price": 17213, "compare_price": null, "sku": "027541", "invima": "INVIMA 2021131138", "badge": "INVIMA Aprobado", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027541.png?v=1745426340", "handle": "limpiador-desinfectante-lavanda-galon-x-3800-c-c", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027541.png?v=1745426340"]}, {"id": "9002416177410", "title": "MANGO METALICO 1.40 CAL 34 GRIS TASK", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6807, "compare_price": null, "sku": "023091", "invima": "INVIMA 2021177410", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023091.jpg?v=1745426758", "handle": "mango-metalico-1-40-blanco-task-copia", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023091.jpg?v=1745426758"]}, {"id": "9002419585282", "title": "PAD 3M 20\" BLANCO 175-300 RPM", "category": "Aseo", "subcat": "Aseo Profesional", "price": 46762, "compare_price": null, "sku": "020147", "invima": "INVIMA 2021585282", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020147.jpg?v=1745427033", "handle": "pad-3m-20-blanco-175-300-rpm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020147.jpg?v=1745427033"]}, {"id": "9002420142338", "title": "REMOVEDOR DE CERAS GALON X  3800 C.C. - PROASEO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 16765, "compare_price": null, "sku": "026902", "invima": "INVIMA 2021142338", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026902_c6e7081b-8d6b-4b0a-a126-8de51491c801.jpg?v=1745427097", "handle": "removedor-de-ceras-galon-x-3800-c-c-proaseo-1", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026902_c6e7081b-8d6b-4b0a-a126-8de51491c801.jpg?v=1745427097"]}, {"id": "9002421813506", "title": "SHAMPOO PARA ALFOMBRAS GALON X  3800 C.C. - PROASEO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 14796, "compare_price": null, "sku": "026906", "invima": "INVIMA 2021813506", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026906.jpg?v=1745427231", "handle": "shampoo-para-alfombras-galon-x-3800-c-c-proaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026906.jpg?v=1745427231"]}, {"id": "9007128576258", "title": "DETERGENTE LIQUIDO TIPO JABON REY MULTIUSOS MASTER-YA GALON X 3750 ML", "category": "Aseo", "subcat": "Aseo Profesional", "price": 35652, "compare_price": null, "sku": "040926", "invima": "INVIMA 2021576258", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040926.jpg?v=1746033306", "handle": "detergente-liquido-tipo-jabon-rey-multiusos-master-ya-galon-x-3750-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040926.jpg?v=1746033306"]}, {"id": "4894695555204", "title": "CEPILLO PISO CON BANDA CON MANGO - TRAPISOL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 9125, "compare_price": null, "sku": "020504", "invima": "INVIMA 2021555204", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020504.jpg?v=1588372674", "handle": "tra-cep-04-cepillo-piso-con-banda-con-mango-trapisol", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020504.jpg?v=1588372674"]}, {"id": "4894696013956", "title": "ESCOBA SUAVE TASK PRO DALIA ROJA SIN MANGO 38 CM - REF. 218", "category": "Aseo", "subcat": "Aseo Profesional", "price": 5557, "compare_price": null, "sku": "022816", "invima": "INVIMA 2021013956", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022816.jpg?v=1588375969", "handle": "task-1006244-escoba-suave-task-pro-dalia-roja-s-mango-38-cm-ref-218", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022816.jpg?v=1588375969"]}, {"id": "4894700077188", "title": "PAÑO ABSORBENTE 18 X 18", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3594, "compare_price": null, "sku": "022844", "invima": "INVIMA 2021077188", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022844.jpg?v=1588396682", "handle": "task-c300508-pano-absorbente-18-x-18-unidad-tas", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022844.jpg?v=1588396682"]}, {"id": "4894700798084", "title": "RECOGEDOR PLASTICO AZUL CON BANDA Y MANGO PLASTIFICADO - 1A -", "category": "Aseo", "subcat": "Aseo Profesional", "price": 5398, "compare_price": null, "sku": "022904", "invima": "INVIMA 2021798084", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022904.jpg?v=1588392676", "handle": "1a-500120-recogedor-plastico-azul-con-banda-y-mango-plastificado-1a", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022904.jpg?v=1588392676"]}, {"id": "4894703550596", "title": "CAFE AGUILA ROJA INSTANTANEO CAJITA X 24 UNIDADES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4990, "compare_price": null, "sku": "032104", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032104.jpg?v=1588371989", "handle": "tc-12545-cafe-aguila-roja-instantaneo-cajita-x-24-unidades", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032104.jpg?v=1588371989"]}, {"id": "4894705352836", "title": "TE JAIBEL VERDE VIVE CON FLOR DE JAMAICA SOBREENV  X 20 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 13684, "compare_price": null, "sku": "030242", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030242.jpg?v=1588390878", "handle": "jb-12601-te-jaibel-verde-vive-con-flor-de-jamaica-sobreenv-x-20-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030242.jpg?v=1588390878"]}, {"id": "4894710694020", "title": "CERA AUTOBRILLANTE ANTIDESLIZANTE TRAF.PESADO X 3000 CC POTENTE", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 87093, "compare_price": null, "sku": "027069", "invima": "INVIMA 2021694020", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027069.jpg?v=1750191489", "handle": "pot-41201-cera-autobrillante-antideslizante-traf-pesado-x-3000-cc-potente", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027069.jpg?v=1750191489"]}, {"id": "4910123155588", "title": "PAÑOS DE LIMPIEZA WYPALL X80 PLUS AZUL CON POWER POCKETS X 30 PAÑOS", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 32206, "compare_price": null, "sku": "010985", "invima": "INVIMA 2021155588", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243107_ESP-06.png?v=1773771375", "handle": "wypall-x-80-plus-azul-pq-x-30-panos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243107_ESP-06.png?v=1773771375"]}, {"id": "4936466858116", "title": "GUANTE LATEXPORT INDUSTRIAL AMARILLO CAL. 35 TALLA 9", "category": "Aseo", "subcat": "Aseo Profesional", "price": 8381, "compare_price": null, "sku": "023015", "invima": "INVIMA 2021858116", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023015.jpg?v=1589570154", "handle": "ltx-inda09-guante-latexport-industrial-amarillo-cal-35-talla-9", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023015.jpg?v=1589570154"]}, {"id": "4936474493060", "title": "ESPONJA DE BRONCE X 20 GR X UNIDAD", "category": "Aseo", "subcat": "Aseo Profesional", "price": 5193, "compare_price": null, "sku": "023084", "invima": "INVIMA 2021493060", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023084.jpg?v=1589566143", "handle": "et-10507-esponja-de-bronce-x-20-gr-x-unidad", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023084.jpg?v=1589566143"]}, {"id": "4936475050116", "title": "SERVILLETA BLANCA PLUS ACABADO MADERA CJ X 100 UD FSC FAMILIA- (F-72146)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 4570, "compare_price": null, "sku": "011057", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011057.jpg?v=1774885201", "handle": "f-72683-servilleta-blanca-plus-acabado-madera-cj-x-100-ud-fsc-familia-72662", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011057.jpg?v=1774885201"]}, {"id": "4936475738244", "title": "AZUCAR BLANCA PAQ. X 200 SOBRES MANUELITA", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 7767, "compare_price": null, "sku": "030230", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030230.jpg?v=1589475912", "handle": "man-0124-azucar-blanca-paq-x-200-sobres-manuelita", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030230.jpg?v=1589475912"]}, {"id": "5272708677799", "title": "GUANTE LATEXPORT NEGRO MOSQUETERO CL-35 TALLA 9", "category": "Aseo", "subcat": "Aseo Profesional", "price": 27570, "compare_price": null, "sku": "022407", "invima": "INVIMA 2021677799", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022047.jpg?v=1591206195", "handle": "ltx-3502-guante-latexport-negro-mosquetero-cl-35-talla-9", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022047.jpg?v=1591206195"]}, {"id": "5272711332007", "title": "PAD MONSTER DE 16 \"", "category": "Aseo", "subcat": "Aseo Profesional", "price": 14225, "compare_price": null, "sku": "020382", "invima": "INVIMA 2021332007", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020382.jpg?v=1591209916", "handle": "est-90716-pad-monster-de-16", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020382.jpg?v=1591209916"]}, {"id": "5272712577191", "title": "TRAPERO DE HILO ESPECIAL CABO VERDE S/MANGO - TRAPISOL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 13724, "compare_price": null, "sku": "022528", "invima": "INVIMA 2021577191", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022528.jpg?v=1591283079", "handle": "tra-co370sv-trapero-de-hilo-especial-cabo-verde-s-mango-trapisol", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022528.jpg?v=1591283079"]}, {"id": "5272713101479", "title": "TRAPERO DE HILO ESPECIAL CABO AZUL S/MANGO - TRAPISOL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 13724, "compare_price": null, "sku": "022529", "invima": "INVIMA 2021101479", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022529.jpg?v=1591283134", "handle": "tra-co370saz-trapero-de-hilo-especial-cabo-azul-s-mango-trapisol", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022529.jpg?v=1591283134"]}, {"id": "5351724974247", "title": "MINAS 0.7 HB - PELIKAN", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1420, "compare_price": null, "sku": "050486", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/050486.jpg?v=1688675002", "handle": "minas-0-7-hb-pelikan", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/050486.jpg?v=1688675002"]}, {"id": "5355932745895", "title": "SOBRE MANILA OFICIO 25 X 35 GENERICO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 165, "compare_price": null, "sku": "061458", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061458.jpg?v=1592585700", "handle": "sobre-manila-oficio-25-x-35-generico", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061458.jpg?v=1592585700"]}, {"id": "6793822077095", "title": "MOUSE OPTICO GENIUS USB DX-120 NEGRO REF. 10815-GN", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 22803, "compare_price": null, "sku": "060743", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060743.jpg?v=1621972744", "handle": "mouse-optico-genius-usb-dx-120-negro-ref-10815-gn", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060743.jpg?v=1621972744"]}, {"id": "6929747345575", "title": "PERFORADORA RANK 20 HJS 2 HUECOS REF 1038", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 18365, "compare_price": null, "sku": "051530", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/051530.jpg?v=1627072032", "handle": "perforadora-rank-20-hjs-2-huecos-ref-1038", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/051530.jpg?v=1627072032"]}, {"id": "6929751179431", "title": "SEPARADOR CLASIFICADOR X 5 UND CARTULINA COLOR SURTIDO - BRISTOL", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1470, "compare_price": null, "sku": "060641", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060641.jpg?v=1627072514", "handle": "separador-clasificador-x-5-und-cartulina-color-surtido-bristol-1", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060641.jpg?v=1627072514"]}, {"id": "6953509879975", "title": "GUANTE LATEXPORT IND. NEGRO-VERDE CL 35 T 7-7 1/2", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7827, "compare_price": null, "sku": "021532", "invima": "INVIMA 2021879975", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021971_720e1b6a-8c5f-4f4b-a17f-34ac3e2d7e7e.jpg?v=1628171951", "handle": "copia-de-guante-latexport-ind-negro-verde-cl-35-t-7-7-1-2", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021971_720e1b6a-8c5f-4f4b-a17f-34ac3e2d7e7e.jpg?v=1628171951"]}, {"id": "7704814190850", "title": "CORRECTOR LAPIZ X 8 ML - EAGLE", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1428, "compare_price": null, "sku": "060620", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060620.jpg?v=1654288743", "handle": "corrector-lapiz-x-8-ml-eagle", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060620.jpg?v=1654288743"]}, {"id": "7748824760578", "title": "LECHE DE ALMENDRA ALQUERIA TETRAPACK 1 LT", "category": "Aseo", "subcat": "Aseo Profesional", "price": 15869, "compare_price": null, "sku": "032330", "invima": "INVIMA 2021760578", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032330.png?v=1658516792", "handle": "leche-de-almendra-alqueria-tetrapack-1-lt", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032330.png?v=1658516792"]}, {"id": "8003420979458", "title": "CAFE TOSTAO SELECTO BOLSA X 454 GR", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 32384, "compare_price": 18000, "sku": "032419", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032419.jpg?v=1681923158", "handle": "cafe-tostao-selecto-bolsa-x-454-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032419.jpg?v=1681923158"]}, {"id": "8166148374786", "title": "SELLADOR DE PISOS GARRAFA X 20 LTS - OUI", "category": "Aseo", "subcat": "Aseo Profesional", "price": 393441, "compare_price": null, "sku": "027135", "invima": "INVIMA 2021374786", "badge": "Mayorista Ahorro", "unit": "Garrafa 20L", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027135.png?v=1696081678", "handle": "sellador-de-pisos-garrafa-x-20-lts-oui", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027135.png?v=1696081678"]}, {"id": "8259355443458", "title": "PAÑO MICROFIBRA AMARILLO UNIDAD - TASK PRO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4647, "compare_price": null, "sku": "023533", "invima": "INVIMA 2021443458", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023533.jpg?v=1701448132", "handle": "pano-microfibra-amarillo-unidad-task-pro", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023533.jpg?v=1701448132"]}, {"id": "8772167762178", "title": "COLCAFE COFFEE CREAM X 1000 GR", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 32305, "compare_price": null, "sku": "032254", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032254.jpg?v=1723750569", "handle": "colcafe-coffee-cream-x-1000-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032254.jpg?v=1723750569"]}, {"id": "8772172284162", "title": "PLATO ICOPOR HONDO # 16 CM PAQ X 20 UD - DARNEL", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 4509, "compare_price": null, "sku": "031617", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/031617.jpg?v=1723751273", "handle": "plato-icopor-hondo-16-cm-paq-x-20-ud-darnel", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/031617.jpg?v=1723751273"]}, {"id": "8772176249090", "title": "CHURRUSCO PARA VASOS MANGO BLANCO VANYPLAST", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 7963, "compare_price": null, "sku": "032090", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (30 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032090.jpg?v=1723751611", "handle": "churrusco-para-vasos-mango-blanco-vanyplast", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032090.jpg?v=1723751611"]}, {"id": "8780463800578", "title": "CINTA AISLANTE AMARILLA 19 MM X 10 MTS - TESA", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 4440, "compare_price": null, "sku": "062183", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062183.png?v=1724266808", "handle": "cinta-aislante-amarilla-19-mm-x-10-mts-tesa", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062183.png?v=1724266808"]}, {"id": "8781658685698", "title": "WYPALL L10 AUTODISPENSABLE NATURAL/KRAFT 21.7X23.8 BOLSA X 25 UND.", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 10169, "compare_price": null, "sku": "011084", "invima": "INVIMA 2021685698", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011084.png?v=1724356327", "handle": "wypall-l10-autodispensable-natural-kraft-21-7x23-8-bolsa-x-25-und", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011084.png?v=1724356327", "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30241575_ESP-03.png?v=1773770423"]}, {"id": "8821164769538", "title": "AZUCAR BLANCA PAQ. X 200 SOBRES MANUELITA", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 7767, "compare_price": 7200, "sku": "030230", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030230.png?v=1728568352", "handle": "azucar-blanca-paq-x-200-sobres-manuelita", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/030230.png?v=1728568352"]}, {"id": "8945028661506", "title": "BALDE ESCURRIDOR X 20 LTS. AMARILLO - FENIXCOL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 253921, "compare_price": null, "sku": "022658", "invima": "INVIMA 2021661506", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022658.jpg?v=1741037091", "handle": "balde-escurridor-x-20-lts-amarillo-fenixcol", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022658.jpg?v=1741037091"]}, {"id": "9002403725570", "title": "BOLSA BASURA REC. BLANCA 80 X 110 CM CL. 2 PAQ. X 6 UND", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6501, "compare_price": null, "sku": "022435", "invima": "INVIMA 2021725570", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022435.jpg?v=1745425752", "handle": "bolsa-basura-rec-blanca-80-x-110-cm-cl-2-paq-x-6-und", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022435.jpg?v=1745425752"]}, {"id": "9002405200130", "title": "CREMA DESMANCHADORA MULTIGRASS X 1000 C.C.", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 15708, "compare_price": null, "sku": "020021", "invima": "INVIMA 2021200130", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020021.jpg?v=1745425833", "handle": "crema-desmanchadora-multigrass-x-1000-c-c", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/020021.jpg?v=1745425833"]}, {"id": "9002414768386", "title": "LUSTRAMUEBLES CREMA FRASCO X 240 C.C. - PROASEO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 4388, "compare_price": null, "sku": "026888", "invima": "INVIMA 2021768386", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026888.jpg?v=1745426628", "handle": "lustramuebles-crema-frasco-x-240-c-c-proaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026888.jpg?v=1745426628"]}, {"id": "9002415915266", "title": "MANGO METALICO 1.40 BLANCO - TASK", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6807, "compare_price": null, "sku": "023020", "invima": "INVIMA 2021015266", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023020.jpg?v=1745426705", "handle": "mango-metalico-1-40-blanco-task", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023020.jpg?v=1745426705"]}, {"id": "9002413195522", "title": "LIMPIAVIDRIOS GALON X 3800 C.C. - PROASEO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 9470, "compare_price": null, "sku": "026896", "invima": "INVIMA 2021195522", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026896.jpg?v=1745426539", "handle": "limpiavidrios-frasco-c-pistola-x-1000-c-c-proaseo-copia", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026896.jpg?v=1745426539"]}, {"id": "9002412802306", "title": "LIMPIAVIDRIOS FRASCO C/PISTOLA X 1000 C.C. - PROASEO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 4587, "compare_price": null, "sku": "026992", "invima": "INVIMA 2021802306", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026992.jpg?v=1745426484", "handle": "limpiavidrios-frasco-c-pistola-x-1000-c-c-proaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026992.jpg?v=1745426484"]}, {"id": "9002412015874", "title": "LIMPIAVIDRIOS ATOMIZADOR FCO X 500 C.C. - PROASEO", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 4689, "compare_price": null, "sku": "026894", "invima": "INVIMA 2021015874", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026894.jpg?v=1745426428", "handle": "limpiavidrios-atomizador-fco-x-500-c-c-proaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/026894.jpg?v=1745426428"]}, {"id": "9002410115330", "title": "LIMPIADOR AMONIACAL DESMANCHADOR (KLIN) GALON X 3800 C.C", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 15881, "compare_price": null, "sku": "027128", "invima": "INVIMA 2021115330", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027128.jpg?v=1745426266", "handle": "limpiador-amoniacal-desmanchador-klin-galon-x-3800-c-c", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027128.jpg?v=1745426266"]}, {"id": "9002408083714", "title": "HIPOCLORITO DE SODIO  AL 5.25  GL X 3800 C.C", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 9647, "compare_price": null, "sku": "027077", "invima": "INVIMA 2021083714", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027077.jpg?v=1745426110", "handle": "hipoclorito-de-sodio-al-5-25-gl-x-3800-c-c", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/027077.jpg?v=1745426110"]}, {"id": "9002406969602", "title": "ESPONJA DOBLE USO 2.5 CMS UND ETERNA", "category": "Aseo", "subcat": "Aseo Profesional", "price": 1060, "compare_price": null, "sku": "023756", "invima": "INVIMA 2021069602", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023756.jpg?v=1745426006", "handle": "esponja-doble-uso-2-5-cms-und-eterna", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023756.jpg?v=1745426006"]}, {"id": "4894695293060", "title": "BRILLADOR REPUESTO 80 X 20 CMS - 1A", "category": "Aseo", "subcat": "Aseo Profesional", "price": 26517, "compare_price": null, "sku": "021994", "invima": "INVIMA 2021293060", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021994.jpg?v=1588371867", "handle": "1a-200402-brillador-repuesto-80-x-20-cms-1a", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021994.jpg?v=1588371867"]}, {"id": "4894696505476", "title": "ESCOBA ZULIA SUAVE VERDE SIN MANGO - 1A -", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6333, "compare_price": null, "sku": "022010", "invima": "INVIMA 2021505476", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-2775.png?v=1707913335", "handle": "1a-400184-escoba-zulia-suave-verde-sin-mango-1a", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-2775.png?v=1707913335"]}, {"id": "4894696833156", "title": "ESPONJILLA INS. LA MAQUINA GRIS 11X7 CMS. - 3M -", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4108, "compare_price": null, "sku": "020153", "invima": "INVIMA 2021833156", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020153.jpg?v=1588377848", "handle": "3m-6763-esponjilla-ins-la-maquina-gris-11x7-cms-3m", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020153.jpg?v=1588377848"]}, {"id": "4894697881732", "title": "GUANTE LATEXPORT CORRUGADO AMARILLO TALLA 8 - 8 1/2", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7422, "compare_price": null, "sku": "021991", "invima": "INVIMA 2021881732", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021991_89e0e5f3-1905-4889-be95-181139377e46.jpg?v=1692910176", "handle": "ltx-co39-guante-latexport-corrugado-amarillo-talla-8-8-1-2", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021991_89e0e5f3-1905-4889-be95-181139377e46.jpg?v=1692910176"]}, {"id": "4894697914500", "title": "GUANTE LATEXPORT DOMESTICO AMARILLO TALLA 8 - 8 1/2 (M)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4828, "compare_price": null, "sku": "021540", "invima": "INVIMA 2021014500", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021540.jpg?v=1588383201", "handle": "ltx-do08-guante-latexport-domestico-amarillo-talla-8-8-1-2-m", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021540.jpg?v=1588383201"]}, {"id": "4894698045572", "title": "GUANTE LATEXPORT IND. NEGRO CL-25 TALLA 8 - 8 1/2 (M)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 5256, "compare_price": null, "sku": "021536", "invima": "INVIMA 2021045572", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021536.jpg?v=1588383285", "handle": "ltx-2508-guante-latexport-ind-negro-cl-25-talla-8-8-1-2-m", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021536.jpg?v=1588383285"]}, {"id": "4894698111108", "title": "GUANTE LATEXPORT IND. NEGRO CL-35 TALLA 8 - 8 1/2 (M)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7827, "compare_price": null, "sku": "021533", "invima": "INVIMA 2021111108", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021533.jpg?v=1588383321", "handle": "ltx-3508-guante-latexport-ind-negro-cl-35-talla-8-8-1-2-m", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021533.jpg?v=1588383321"]}, {"id": "4894698143876", "title": "GUANTE LATEXPORT IND. NEGRO CL-35 TALLA 9 - 9 1/2 (L)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7827, "compare_price": null, "sku": "021534", "invima": "INVIMA 2021143876", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021534.jpg?v=1588383362", "handle": "ltx-3509-guante-latexport-ind-negro-cl-35-talla-9-9-1-2-l", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021534.jpg?v=1588383362"]}, {"id": "4894698176644", "title": "GUANTE LATEXPORT IND. NEGRO-VERDE CL 35 T 8", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7827, "compare_price": null, "sku": "021971", "invima": "INVIMA 2021176644", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021971.jpg?v=1588383395", "handle": "ltx-2516-guante-latexport-ind-negro-verde-cl-35-t-8", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021971.jpg?v=1588383395"]}, {"id": "4894699323524", "title": "MANGO METALICO 1.40 ROJO - TASK", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6807, "compare_price": null, "sku": "023023", "invima": "INVIMA 2021323524", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023023.png?v=1588394435", "handle": "task-s206088-mango-metalico-1-40-rojo-task", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023023.png?v=1588394435"]}, {"id": "4894699389060", "title": "MANGO METALICO 1.40 VERDE - TASK", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6807, "compare_price": null, "sku": "023021", "invima": "INVIMA 2021389060", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023021.jpg?v=1588394469", "handle": "task-s206087-mango-metalico-1-40-verde-task", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023021.jpg?v=1588394469"]}, {"id": "4894699618436", "title": "MECHA TRAPERO REPUESTO AZUL X 500 GRS", "category": "Aseo", "subcat": "Aseo Profesional", "price": 11599, "compare_price": null, "sku": "021816", "invima": "INVIMA 2021618436", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021816.jpg?v=1588395298", "handle": "tra-mchh-002a5-mecha-trapero-repuesto-azul-x-500-grs", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021816.jpg?v=1588395298"]}, {"id": "4894700601476", "title": "RECOGEDOR C/BANDA SIN MANGO  ROJO - ARCOASEO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3998, "compare_price": null, "sku": "023026", "invima": "INVIMA 2021601476", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023026.jpg?v=1588392815", "handle": "task-1019080-recogedor-c-banda-sin-mango-rojo-arcoaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023026.jpg?v=1588392815"]}, {"id": "4894701748356", "title": "TRAPERO COPA TASK REF. 1000 X 360 GR S/MANGO N. 26", "category": "Aseo", "subcat": "Aseo Profesional", "price": 10491, "compare_price": null, "sku": "023067", "invima": "INVIMA 2021748356", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023067.png?v=1588389276", "handle": "task-1003210-trapero-copa-task-ref-1000-x-360-gr-s-mango-n-26", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023067.png?v=1588389276"]}, {"id": "4894702305412", "title": "AROMATICA INFUSION HERBAL FRUTAL CIDRON-FRUTOS ROJOS X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 10264, "compare_price": null, "sku": "031775", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031775.png?v=1588361162", "handle": "jb-13190-aromatica-infusion-herbal-frutal-cidron-frutos-rojos-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031775.png?v=1588361162"]}, {"id": "4894702338180", "title": "AROMATICA INFUSION HERBAL FRUTAL LIMONARIA-LIMON X 20 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 11187, "compare_price": null, "sku": "030372", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030372.jpg?v=1588361245", "handle": "jb-12620-aromatica-infusion-herbal-frutal-limonaria-limon-x-20-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030372.jpg?v=1588361245"]}, {"id": "4894704828548", "title": "PANELA EN PASTILLA ORQUIDEA X 950 GRS.", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 12377, "compare_price": null, "sku": "031078", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031078.jpg?v=1588396227", "handle": "to-1170-panela-en-pastilla-orquidea-x-950-grs", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031078.jpg?v=1588396227"]}, {"id": "4894706630788", "title": "LIMPIADOR MULTIUSOS ULC GALON X 5L - DIVERSEY", "category": "Aseo", "subcat": "Aseo Profesional", "price": 69075, "compare_price": null, "sku": "027047", "invima": "INVIMA 2021630788", "badge": "Mayorista Ahorro", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027047.png?v=1594323047", "handle": "jd-08524-limpiador-multiusos-ulc-galon-x-5-lts-jd", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027047.png?v=1594323047", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/55843PIS-ULC-A4-es-CO-HRNC-1.jpg?v=1594409150", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/55843PIS-ULC-A4-es-CO-HRNC-2.jpg?v=1594409150"]}, {"id": "4894706991236", "title": "JABÓN SCOTT HANDLOTION EN SPRAY X 400ML", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 36823, "compare_price": null, "sku": "010999", "invima": "INVIMA 2021091236", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010999.jpg?v=1614877038", "handle": "k-7007-jabon-manos-spray-scott-hand-lotion-x-400-cc-kimberly", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010999.jpg?v=1614877038"]}, {"id": "4894707220612", "title": "PAPEL HIGIENICO JUMBO SCOTT ESSENTIAL BLANCO HOJA SENCILLA X 400 MTS - PACA X 4", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 89025, "compare_price": null, "sku": "010968", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/30226519.jpg?v=1598375973", "handle": "k-6519-papel-jumbo-scott-essential-blanco-h-s-rll-x-400-mts-paca-x-4", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/30226519.jpg?v=1598375973"]}, {"id": "4894707449988", "title": "TOALLA DE MANOS KLEENEX EN ROLLO BLANCA  HOJA DOBLE X 80 MTS - PACA X 6", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 179439, "compare_price": null, "sku": "011038", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/HERO_IMAGE_30240348-01.jpg?v=1619024768", "handle": "k-0415-toalla-mano-kleenex-blanca-en-rollo-x-80-mts-paca-x-6", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/HERO_IMAGE_30240348-01.jpg?v=1619024768"]}, {"id": "4894707482756", "title": "TOALLA DE MANOS KLEENEX ® SUPREME DOBLADA EN Z BLANCA HOJA DOBLE X 150 TOALLAS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 15505, "compare_price": null, "sku": "010982", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/30228378_ToallasdeManoKleenexSupremeBlancocaja18rollosx150hojas-03.jpg?v=1773770008", "handle": "k-8378-toalla-mano-kleenex-supreme-multi-fold-blanca-pq-x-150-ud-k-0934", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/30228378_ToallasdeManoKleenexSupremeBlancocaja18rollosx150hojas-03.jpg?v=1773770008"]}, {"id": "4894707581060", "title": "TOALLA DE MANOS SCOTT ® ESSENTIAL DOBLADA EN Z NATURAL HOJA DOBLE X 150 TOALLAS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 10818, "compare_price": null, "sku": "010983", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/30228419_Toallas_de_Mano_Scott_Essential_Natural_caja_28_paquetes_x_150_hojas-03.jpg?v=1773770164", "handle": "k-8419-toalla-mano-scott-essential-natural-pq-x150-ud-24-1x22-3-cm-k-5991", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/30228419_Toallas_de_Mano_Scott_Essential_Natural_caja_28_paquetes_x_150_hojas-03.jpg?v=1773770164"]}, {"id": "4894708007044", "title": "JABON ESPUMA SUAVE RPTO TORK X 1000 ML (F-80536)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 83430, "compare_price": null, "sku": "011082", "invima": "INVIMA 2021007044", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011082.png?v=1712778817", "handle": "f-80530-jabon-espuma-suave-rpto-x-1000-ml-familia", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011082.png?v=1712778817"]}, {"id": "4894708072580", "title": "JABON LIQUIDO SUAVE MINI BOTELLA X 475 ML (F-80550)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 24390, "compare_price": null, "sku": "010747", "invima": "INVIMA 2021072580", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010747.png?v=1712779076", "handle": "f-80550-jabon-liquido-suave-mini-botella-x-475-ml-familia", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010747.png?v=1712779076"]}, {"id": "4894708203652", "title": "MEZCLADOR DE MADERA 11 CMS. PAQ. X 500 UND", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3213, "compare_price": null, "sku": "032552", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032092.jpg?v=1588395718", "handle": "sdn-2092-mezclador-de-madera-11-cms-paq-x-500-und", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032092.jpg?v=1588395718"]}, {"id": "4894711513220", "title": "DETERGENTE LIQUIDO MULTIUSOS GL X 3000 CC POTENTE", "category": "Aseo", "subcat": "Aseo Profesional", "price": 20072, "compare_price": null, "sku": "040336", "invima": "INVIMA 2021513220", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040336.jpg?v=1588375072", "handle": "pot-40309-detergente-liquido-multiusos-gl-x-3000-cc-potente", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040336.jpg?v=1588375072"]}, {"id": "4894713282692", "title": "RAID MATAZANCUDOS FCO X 360 CC", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 22930, "compare_price": null, "sku": "020047", "invima": "INVIMA 2021282692", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020047.jpg?v=1588392942", "handle": "sc-8637-raid-matazancudos-fco-x-360-cc", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020047.jpg?v=1588392942"]}, {"id": "4936465416324", "title": "CERA MADERA BEISBOL NATURAL NEUTRA GL X 3000 C.C.", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 72620, "compare_price": null, "sku": "020619", "invima": "INVIMA 2021416324", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/image_2d87006f-59ee-4095-800a-f7b135db96b4.jpg?v=1673575982", "handle": "h-005-cera-madera-beisbol-natural-neutra-gl-x-3000-c-c", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/image_2d87006f-59ee-4095-800a-f7b135db96b4.jpg?v=1673575982"]}, {"id": "4936465678468", "title": "LAVALOZA  LIQUIDO LIMON BLANCOX GALON X 3800 ML", "category": "Aseo", "subcat": "Aseo Profesional", "price": 40174, "compare_price": null, "sku": "040624", "invima": "INVIMA 2021678468", "badge": "Certificado B2B", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040624.png?v=1589564503", "handle": "bri-100340175-blancox-lavaloza-liquido-limon-galon-x-3800-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040624.png?v=1589564503"]}, {"id": "4936469545092", "title": "RECOGEDOR C/BANDA SIN MANGO VERDE - ARCOASEO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3998, "compare_price": null, "sku": "023029", "invima": "INVIMA 2021545092", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023029.jpg?v=1589593427", "handle": "task-1019083-recogedor-c-banda-sin-mango-verde-arcoaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023029.jpg?v=1589593427"]}, {"id": "4936470429828", "title": "RECOGEDOR C/BANDA SIN MANGO AMARILLO - ARCOASEO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3998, "compare_price": null, "sku": "023028", "invima": "INVIMA 2021429828", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023028.jpg?v=1589593360", "handle": "task-1019082-recogedor-c-banda-sin-mango-amarillo-arcoaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023028.jpg?v=1589593360"]}, {"id": "4936471085188", "title": "GUANTE LATEXPORT IND. NEGRO-VERDE CL 25 T 8 - 8 1/2 (M)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6113, "compare_price": null, "sku": "021633", "invima": "INVIMA 2021085188", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021633.jpg?v=1589569980", "handle": "ltx-2514-guante-latexport-ind-negro-verde-cl-25-t-8-8-1-2-m", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021633.jpg?v=1589569980"]}, {"id": "4936474558596", "title": "ESCOBA ZULIA SUAVE EKO COLORES SURTIDOS S/MANGO 35 CM MARAVILLA", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4184, "compare_price": null, "sku": "022823", "invima": "INVIMA 2021558596", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-2773.png?v=1707912916", "handle": "task-1005787-escoba-zulia-suave-eko-colores-surtidos-s-mango-35-cm-maravilla", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-2773.png?v=1707912916"]}, {"id": "4936474624132", "title": "CEPILLO DE MANO PLANCHA RD - 1A -", "category": "Aseo", "subcat": "Aseo Profesional", "price": 2863, "compare_price": null, "sku": "021986", "invima": "INVIMA 2021624132", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021986.jpg?v=1589481854", "handle": "1a-300101-cepillo-de-mano-plancha-rd-1a", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021986.jpg?v=1589481854"]}, {"id": "4936474755204", "title": "GUANTE LATEXPORT DOMESTICO AMARILLO TALLA 7 - 7 1/2 (S)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4828, "compare_price": null, "sku": "021539", "invima": "INVIMA 2021755204", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021539.jpg?v=1589569853", "handle": "ltx-do07-guante-latexport-domestico-amarillo-talla-7-7-1-2-s", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021539.jpg?v=1589569853"]}, {"id": "5254915686567", "title": "TAPABOCA CIRUGIA BLANCO CAJA X 50 UNDS - INVIMA - TERMOSELLADOS TRES CAPAS", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 9280, "compare_price": 25000, "sku": "021238", "invima": "INVIMA 2021686567", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.9 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021238.jpg?v=1590783226", "handle": "tapaboca-cirugia-blanco-azul-caja-x-50-unds-invima", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021238.jpg?v=1590783226", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/tapabocas.jpg?v=1590783488"]}, {"id": "5272713265319", "title": "CHURRUSCO PARA SANITARIO REDONDO CON BASE TRIANGULAR REF. 197", "category": "Aseo", "subcat": "Aseo Profesional", "price": 12299, "compare_price": null, "sku": "020795", "invima": "INVIMA 2021265319", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020795.jpg?v=1591120036", "handle": "ful-104197-churrusco-para-sanitario-redondo-con-base-triangular-ref-197", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/020795.jpg?v=1591120036"]}, {"id": "5282590064807", "title": "INFUSION FRUTAL HINDU SURTIDA CAJA X 50 SOBRES", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 27709, "compare_price": null, "sku": "032116", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.9 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032116.png?v=1591306717", "handle": "hin-6091139-infusion-frutal-hindu-surtida-caja-x-50-sobres", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/032116.png?v=1591306717"]}, {"id": "5317647007911", "title": "SEÑAL SEGURIDAD BILATERAL MULTILINGUE AMARILLA - RUBBERMAID", "category": "Aseo", "subcat": "Aseo Profesional", "price": 89699, "compare_price": null, "sku": "022216", "invima": "INVIMA 2021007911", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022216.jpg?v=1591906493", "handle": "senal-seguridad-bilateral-multilingue-amarilla-rubbermaid", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022216.jpg?v=1591906493"]}, {"id": "5351060701351", "title": "DESENGRASANTE  SUMA GRILL ALTA TEMPERATURA PARA PARRILLAS Y HORNOS CLEANER D9.8 GALON X 5 LTS", "category": "Aseo", "subcat": "Aseo Profesional", "price": 258022, "compare_price": null, "sku": "040579", "invima": "INVIMA 2021701351", "badge": "Mayorista Ahorro", "unit": "Galón 3.8L", "rating": "4.9 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040579.jpg?v=1594314010", "handle": "desengrasante-suma-hi-temp-grill-cleaner-d9-8-galon-x-5-lts", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040579.jpg?v=1594314010", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/71858PIS-SumaHiTempGrillcleaner-A4-es-CO-HRNC-1.jpg?v=1594394636", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/71858PIS-SumaHiTempGrillcleaner-A4-es-CO-HRNC-2.jpg?v=1594394636"]}, {"id": "5351715504295", "title": "ROTULOS REF. 1313 AZUL", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 2523, "compare_price": null, "sku": "061489", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/WhatsApp_Image_2021-10-29_at_10.51.58_AM-removebg-preview.png?v=1635522785", "handle": "rotulos-ref-1313-azul", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/WhatsApp_Image_2021-10-29_at_10.51.58_AM-removebg-preview.png?v=1635522785"]}, {"id": "5351717109927", "title": "LEGAJADOR AZ CARTA AZUL NORMA", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 7191, "compare_price": null, "sku": "050186", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050186.jpg?v=1592933944", "handle": "legajador-az-carta-azul-norma", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050186.jpg?v=1592933944"]}, {"id": "5351717961895", "title": "REVISTERO METALICO DINGLI", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 25070, "compare_price": null, "sku": "060700", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/WhatsApp_Image_2021-10-29_at_10.13.13_AM__2_-removebg-preview.png?v=1635521126", "handle": "revistero-metalico-dingli", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/WhatsApp_Image_2021-10-29_at_10.13.13_AM__2_-removebg-preview.png?v=1635521126"]}, {"id": "5351721894055", "title": "PILAS ENERGIZER MAX D BLISTER X 2", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 22007, "compare_price": null, "sku": "051118", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-0879.webp?v=1742387350", "handle": "pilas-energizer-max-d-blister-x-2", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-0879.webp?v=1742387350"]}, {"id": "5351722254503", "title": "CARTULINA PIEL DE ANGEL CARTA PAQ X 25 UND", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 13219, "compare_price": null, "sku": "060528", "invima": "INVIMA 2021254503", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.9 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060528.png?v=1740789553", "handle": "cartulina-piel-de-angel-carta-paq-x-50-und", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060528.png?v=1740789553"]}, {"id": "5876933951655", "title": "GEL ANTIBACTERIAL-ALCOHOL GLICERINA SANITIZER PURELL NXT X 1000", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 42899, "compare_price": null, "sku": "040054", "invima": "INVIMA 2021051655", "badge": "INVIMA Aprobado", "unit": "Unidad", "rating": "4.9 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040054.png?v=1601558596", "handle": "gel-antibacterial-alcohol-glicerina-sanitizer-purell-nxt-x-1000", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040054.png?v=1601558596"]}, {"id": "5941621194919", "title": "MARCADOR PERMANENTE 420 NEGRO - PELIKAN", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1936, "compare_price": null, "sku": "050464", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050464.jpg?v=1602695019", "handle": "marcador-permanente-420-negro-pelikan", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050464.jpg?v=1602695019"]}, {"id": "6678582755495", "title": "PAPEL HIGIÉNICO JUMBO XTRA 1 NATURAL DOBLE HOJA ROLLO X 200  MTS - PACA X 4 (F-71613)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 94068, "compare_price": null, "sku": "011047", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011047.jpg?v=1774882692", "handle": "papel-hig-jumbo-xtra-1-natural-doble-hoja-rollo-x-200-mts-paca-x-4", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011047.jpg?v=1774882692"]}, {"id": "6750809620647", "title": "DETERGENTE EN POLVO DESENGRASANTE SIN AROMA X 1000 GR PQP", "category": "Aseo", "subcat": "Aseo Profesional", "price": 7998, "compare_price": null, "sku": "040773", "invima": "INVIMA 2021620647", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040773.png?v=1621445046", "handle": "detergente-en-polvo-desengrasante-sin-aroma-x-1000-gr-pqp", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040773.png?v=1621445046"]}, {"id": "6793652371623", "title": "GUIA FOLDER CELUGUIA PQ. X 160 AZUL", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 3535, "compare_price": null, "sku": "062150", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/062150.png?v=1622237686", "handle": "off-2150-guia-folder-celuguia-pq-x-160-azul", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/062150.png?v=1622237686"]}, {"id": "6953605365927", "title": "MANGO ALUMINIO EXTENSIBLE 200 CM REF. 827", "category": "Aseo", "subcat": "Aseo Profesional", "price": 52999, "compare_price": null, "sku": "023487", "invima": "INVIMA 2021365927", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023487.png?v=1628174415", "handle": "mango-aluminio-extensible-200-cm-ref-827", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023487.png?v=1628174415"]}, {"id": "7704811798786", "title": "FOLDER CELUGUIA CARTON OFICIO VERTICAL SUPERIOR CORRIENTE", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 699, "compare_price": null, "sku": "051080", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/051080.jpg?v=1655902471", "handle": "folder-celuguia-carton-oficio-vertical-superior-corriente", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/051080.jpg?v=1655902471"]}, {"id": "7704811929858", "title": "MARCADOR PERMANENTE 420 AZUL - PELIKAN", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1936, "compare_price": null, "sku": "050463", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050463.jpg?v=1655902415", "handle": "marcador-permanente-420-azul-pelikan", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050463.jpg?v=1655902415"]}, {"id": "7704812683522", "title": "SOBRE CATALOGO BLANCO CARTA 22.5 X 29 SELLA STRIP", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 326, "compare_price": null, "sku": "050621", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050621.jpg?v=1655901664", "handle": "sobre-catalogo-blanco-carta-22-5-x-29-sella-strip", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050621.jpg?v=1655901664"]}, {"id": "7704813469954", "title": "PLANILLERA OFICIO PLASTICA COLORES (BLANCO/AZUL/VERDE/AMARILLO/ROJA)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 6699, "compare_price": null, "sku": "052009", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7800.jpg?v=1723304324", "handle": "planillera-oficio-plastica-colores-blanco-azul-verde-amarillo-roja", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7800.jpg?v=1723304324"]}, {"id": "7704813863170", "title": "CINTA EMPAQUE TRANSPARENTE 48 X 40 REF. 301 - 3M", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 8401, "compare_price": null, "sku": "050279", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/050279.png?v=1740789720", "handle": "cinta-empaque-transparente-48-x-40-ref-301-3m", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/050279.png?v=1740789720"]}, {"id": "8049123918082", "title": "PLASTICO BURBUJA BOLA PEQUEÑA 1.50 X 50 MT", "category": "Aseo", "subcat": "Aseo Profesional", "price": 111292, "compare_price": 105000, "sku": "022455", "invima": "INVIMA 2021018082", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022455.jpg?v=1686665865", "handle": "plastico-burbuja-bola-pequena-1-50-x-50-mt", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022455.jpg?v=1686665865"]}, {"id": "8153560023298", "title": "LIMPION INDUSTRIAL NATURAL PACA X 2 ROLLOS X 305 MTS (F-74079)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 122537, "compare_price": null, "sku": "010998", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010988.jpg?v=1774882281", "handle": "limpion-industrial-natural-paca-x-2-rollos-x-305-mts-f-74079", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010988.jpg?v=1774882281"]}, {"id": "8259354394882", "title": "PAÑO MICROFIBRA AZUL UNIDAD - TASK PRO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4647, "compare_price": null, "sku": "023356", "invima": "INVIMA 2021394882", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023356.jpg?v=1701447934", "handle": "pano-microfibra-azul-unidad-task-pro", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023356.jpg?v=1701447934"]}, {"id": "8259354853634", "title": "PAÑO MICROFIBRA ROJO UNIDAD - TASK PRO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4647, "compare_price": null, "sku": "023357", "invima": "INVIMA 2021853634", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023357.jpg?v=1701448012", "handle": "pano-microfibra-rojo-unidad-task-pro", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023357.jpg?v=1701448012"]}, {"id": "8259355312386", "title": "PAÑO MICROFIBRA VERDE UNIDAD - TASK PRO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4647, "compare_price": null, "sku": "023358", "invima": "INVIMA 2021312386", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023358.jpg?v=1701448077", "handle": "pano-microfibra-verde-unidad-task-pro", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/023358.jpg?v=1701448077"]}, {"id": "8318417338626", "title": "ESPONJILLA INST. PARRILLA NEGRA ROLLO X 10 CMS X 5 MTS - 3M -", "category": "Aseo", "subcat": "Aseo Profesional", "price": 217326, "compare_price": null, "sku": "022108", "invima": "INVIMA 2021338626", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022108.jpg?v=1706115120", "handle": "esponjilla-inst-parrilla-negra-rollo-x-10-cms-x-5-mts-3m", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/022108.jpg?v=1706115120"]}, {"id": "8772177330434", "title": "ROLLO QUIMICO 76 MM X 30 MTS REACCION NEGRA COPIA AMARILLA", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 5694, "compare_price": null, "sku": "061705", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061705.jpg?v=1723751693", "handle": "rollo-quimico-76-mm-x-30-mts-reaccion-negra-copia-amarilla", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061705.jpg?v=1723751693"]}, {"id": "8772198105346", "title": "AUDIFONO ESENSES MH7030 DIADEMA CON MICROFONO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 85665, "compare_price": null, "sku": "060411", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060411.jpg?v=1723754059", "handle": "audifono-esenses-mh7030-diadema-con-microfono", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060411.jpg?v=1723754059"]}, {"id": "8772201382146", "title": "ESCALA TRIANGULAR - FABER", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 46161, "compare_price": null, "sku": "051477", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/051477.jpg?v=1723754299", "handle": "escala-triangular-faber", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/051477.jpg?v=1723754299"]}, {"id": "8772202168578", "title": "CALCULADORA MAX 16 DIGITOS MXD-406 ESCRITORIO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 82704, "compare_price": null, "sku": "061604", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061604.jpg?v=1723754386", "handle": "calculadora-max-16-digitos-mxd-406-escritorio", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061604.jpg?v=1723754386"]}, {"id": "8821985509634", "title": "FOSFOROS DE MADERA CAJA X 200 UND APROX UNIDAD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 2826, "compare_price": null, "sku": "020659", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (24 clientes B2B)", "image": "https://detalshop.com/cdn/shop/files/logo_detal_shop_color.png", "handle": "fosforos-de-madera-caja-x-200-und-aprox-unidad", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": []}, {"id": "8913916985602", "title": "LECHE DESLACTOSADA ALQUERIA TETRAPACK 1 LT", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 6727, "compare_price": null, "sku": "032329", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032329.png?v=1739282241", "handle": "leche-deslactosada-alqueria-tetrapack-1-lt", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032329.png?v=1739282241"]}, {"id": "8913919639810", "title": "VASO CARTON 6 OZ PAQ. X 50 BLANCO - BARVAL", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5265, "compare_price": null, "sku": "032044", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032044_03b0c10d-56ec-429c-883e-2ff59a814252.jpg?v=1739282429", "handle": "vaso-carton-6-oz-paq-x-50-blanco-barval", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032044_03b0c10d-56ec-429c-883e-2ff59a814252.jpg?v=1739282429"]}, {"id": "8913934024962", "title": "FACIAL KLEENEX CAJA CORTA T.H. BLANCO X 50 PAÑUELOS (K-0876)", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 6803, "compare_price": null, "sku": "011051", "invima": "INVIMA 2021024962", "badge": "Marca Líder", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/30229189.png?v=1773768836", "handle": "facial-kleenex-caja-corta-t-h-blanco-x-50-panuelos-k-0876", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/30229189.png?v=1773768836"]}, {"id": "8913939169538", "title": "CREMA LUBRIDERM FRASCO X 400 ML", "category": "Aseo", "subcat": "Aseo Profesional", "price": 57334, "compare_price": null, "sku": "060051", "invima": "INVIMA 2021169538", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060051.png?v=1739284595", "handle": "crema-lubriderm-frasco-x-400-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060051.png?v=1739284595"]}, {"id": "8913945854210", "title": "GASA ESTERIL DE 7.5 X 7.5 CM SOBRE X 5 UND", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 799, "compare_price": null, "sku": "061020", "invima": "INVIMA 2021854210", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061020.jpg?v=1739285423", "handle": "gasa-esteril-de-7-5-x-7-5-cm-sobre-x-5-und", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061020.jpg?v=1739285423"]}, {"id": "8913950998786", "title": "MICROPORE DE 1\" X 5 YARDAS", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 6768, "compare_price": null, "sku": "053033", "invima": "INVIMA 2021098786", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/053033.png?v=1739286009", "handle": "micropore-de-1-x-5-yardas", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/053033.png?v=1739286009"]}, {"id": "4894703747204", "title": "CAFE OMA INSTITUCIONAL MOLIDO 500 GR", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 35097, "compare_price": null, "sku": "030255", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-1163.webp?v=1743626133", "handle": "oma-0001-2-cafe-oma-institucional-molido-500-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-1163.webp?v=1743626133"]}, {"id": "8982465839362", "title": "CINTA CORRECTORA 5MM X 10 MTS - POINTER", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 5345, "compare_price": null, "sku": "062599", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062599.png?v=1743635867", "handle": "cinta-correctora-5mm-x-10-mts-pointer", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062599.png?v=1743635867"]}, {"id": "8977899421954", "title": "CAFE BISTRO X 500 GR", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 27016, "compare_price": null, "sku": "032547", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (19 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032547.png?v=1743101716", "handle": "cafe-bistro-x-500-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032547.png?v=1743101716"]}, {"id": "4894695325828", "title": "CEPILLO DE MANO PLANCHA FIBRA MEDIA ARCOASEO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3859, "compare_price": null, "sku": "022834", "invima": "INVIMA 2021325828", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022834.jpg?v=1588372382", "handle": "task-1004201-cepillo-de-mano-plancha-fibra-media-arcoaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022834.jpg?v=1588372382"]}, {"id": "4894695981188", "title": "ESCOBA SUAVE TASK PRO DALIA AZUL SIN MANGO 38 CM - REF. 218", "category": "Aseo", "subcat": "Aseo Profesional", "price": 5557, "compare_price": null, "sku": "022815", "invima": "INVIMA 2021081188", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022815.jpg?v=1588375932", "handle": "task-1005418-escoba-suave-task-pro-dalia-azul-s-mango-38-cm-ref-218", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022815.jpg?v=1588375932"]}, {"id": "4894697980036", "title": "GUANTE LATEXPORT IND. NEGRO CL-25 TALLA 7 - 7 1/2 (S)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 5256, "compare_price": null, "sku": "021535", "invima": "INVIMA 2021080036", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021535.jpg?v=1588383270", "handle": "ltx-2507-guante-latexport-ind-negro-cl-25-talla-7-7-1-2-s", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021535.jpg?v=1588383270"]}, {"id": "4894698766468", "title": "LIMPION TOALLA BLANCO 30 X 50", "category": "Aseo", "subcat": "Aseo Profesional", "price": 2785, "compare_price": null, "sku": "021951", "invima": "INVIMA 2021766468", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021951.jpg?v=1588387006", "handle": "id-1951-limpion-toalla-blanco-30-x-50", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/021951.jpg?v=1588387006"]}, {"id": "4894699094148", "title": "MANGO METALICO 1.40 AZUL - TASK", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6807, "compare_price": null, "sku": "023022", "invima": "INVIMA 2021094148", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023022.jpg?v=1588394187", "handle": "task-s206088-mango-metalico-1-40-azul-task", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023022.jpg?v=1588394187"]}, {"id": "4894699749508", "title": "MECHA TRAPERO TASK REF. 800 X 360 GR", "category": "Aseo", "subcat": "Aseo Profesional", "price": 10770, "compare_price": null, "sku": "022833", "invima": "INVIMA 2021749508", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022833.jpg?v=1588395432", "handle": "task-1003159-mecha-trapero-task-ref-800-x-360-gr", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022833.jpg?v=1588395432"]}, {"id": "4894700699780", "title": "RECOGEDOR C/BANDA SIN MANGO AZUL - ARCOASEO", "category": "Aseo", "subcat": "Aseo Profesional", "price": 3998, "compare_price": null, "sku": "023027", "invima": "INVIMA 2021699780", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023027.jpg?v=1588392777", "handle": "task-1019081-recogedor-c-banda-sin-mango-azul-arcoaseo", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023027.jpg?v=1588392777"]}, {"id": "4894703714436", "title": "CAFE NESCAFE TRADICIONAL FCO X 170 GR", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 43636, "compare_price": null, "sku": "030132", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030132.jpg?v=1588372139", "handle": "nest-4297-cafe-nescafe-tradicional-fco-x-170-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030132.jpg?v=1588372139"]}, {"id": "4894704140420", "title": "FILTRO GRECA 2 LIBRAS", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 5144, "compare_price": null, "sku": "030030", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030030.jpg?v=1588379487", "handle": "id-232-filtro-greca-2-libras", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030030.jpg?v=1588379487"]}, {"id": "4894705254532", "title": "SAL REFISAL X 1000 GR", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 2790, "compare_price": null, "sku": "030270", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030270.jpg?v=1588392256", "handle": "dcx-10011206-sal-refisal-x-1000-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/030270.jpg?v=1588392256"]}, {"id": "4894705942660", "title": "VASO 9 OZ PLASTICO TRASLUCIDO TUC PAQ. X 50 UD", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 3826, "compare_price": null, "sku": "031415", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031415.jpg?v=1588388222", "handle": "mult-0901004-vaso-9-oz-plastico-traslucido-tuc-paq-x-50-ud", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031415.jpg?v=1588388222"]}, {"id": "4894706303108", "title": "REMOVEDOR DE PISOS FREEDOM GL X 5 LITROS - DIVERSEY", "category": "Aseo", "subcat": "Aseo Profesional", "price": 78705, "compare_price": null, "sku": "040130", "invima": "INVIMA 2021303108", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040130.jpg?v=1594323370", "handle": "jd-65092-freedom-removedor-gl-x-5-000-cc-jd", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040130.jpg?v=1594323370", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/71858PIS-Freedom-A4-es-CO-HRNC-1.jpg?v=1594409483", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/71858PIS-Freedom-A4-es-CO-HRNC-2.jpg?v=1594409483"]}, {"id": "4894706565252", "title": "LIMPIADOR DESINFECTANTE DE UN SOLO PASO KLINOL  2 EN 1 GL X 5L - DIVERSEY", "category": "Aseo", "subcat": "Aseo Profesional", "price": 80957, "compare_price": null, "sku": "040549", "invima": "INVIMA 2021565252", "badge": "Mayorista Ahorro", "unit": "Garrafa 5L", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040143.png?v=1594322854", "handle": "jd-100881733-limpiador-desinfectante-klinol-2-en-1-gl-x-5-000-cc-jd", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040143.png?v=1594322854", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/56343-PSS_Klinol_2_en_1-A4-es-CO-HRNC-1_f4a38636-5063-44c4-872b-480442ed3d91.jpg?v=1594408240", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/56343-PSS_Klinol_2_en_1-A4-es-CO-HRNC-2_b4533d2d-2717-45b7-b07f-ffc57f73a60c.jpg?v=1594408240"]}, {"id": "4894707875972", "title": "FACIAL BLANCO CUBO TRIPLE HOJA CAJITA X 60 UND (F-75091)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 9412, "compare_price": null, "sku": "010637", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010637.png?v=1588379393", "handle": "f-75091-facial-blanco-cubo-triple-hoja-cajita-x-60-und", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010637.png?v=1588379393"]}, {"id": "4894708957316", "title": "TOALLA DE MANO BLANCA TRIPLE H. EN ROLLO X 100 MTS - CAJA X 6 (F-73575)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 202988, "compare_price": null, "sku": "010808", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010808.jpg?v=1774885745", "handle": "f-73575-toalla-de-mano-blanca-triple-h-en-rollo-x-100-mts-caja-x-6-73717", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010808.jpg?v=1774885745"]}, {"id": "4894709219460", "title": "TOALLA MANO Z NATURAL T.H. 22 X 24 PQ. X 150 UD (F-73554)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 10101, "compare_price": null, "sku": "011060", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011060_121095b4-6dea-4838-b813-224ec6eb659d.jpg?v=1774885300", "handle": "f-73547-toalla-mano-z-natural-t-h-22-x-24-pq-x-150-ud-f-73261", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011060_121095b4-6dea-4838-b813-224ec6eb659d.jpg?v=1774885300"]}, {"id": "4894709448836", "title": "LIMPIADOR MULTIUSOS AJAX BICARBONATO NARANJA-LIMON GL X 2000 CC", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 29214, "compare_price": null, "sku": "040329", "invima": "INVIMA 2021448836", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040329.jpg?v=1588357133", "handle": "cp-10148201-ajax-bicarb-mult-naranja-limon-gl-x-2000-cc", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040329.jpg?v=1588357133"]}, {"id": "4894711414916", "title": "DETERGENTE EN POLVO ULTREX  FLORAL BL X 1000 GR", "category": "Aseo", "subcat": "Aseo Profesional", "price": 8434, "compare_price": null, "sku": "027291", "invima": "INVIMA 2021414916", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027291.png?v=1588374903", "handle": "pqp-464-detergente-en-polvo-ultrex-floral-bl-x-1000-gr", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027291.png?v=1588374903"]}, {"id": "4894711480452", "title": "DETERGENTE EN POLVO ULTREX  FLORAL BL X 500 GR", "category": "Aseo", "subcat": "Aseo Profesional", "price": 4211, "compare_price": null, "sku": "027293", "invima": "INVIMA 2021480452", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027293.jpg?v=1588374984", "handle": "pqp-467-detergente-en-polvo-ultrex-floral-bl-x-500-gr", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/027293.jpg?v=1588374984"]}, {"id": "4894714134660", "title": "LIMPION INDUSTRIAL WYPALL L20  DESCARTABLE X 300 MTS", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 70056, "compare_price": null, "sku": "010798", "invima": "INVIMA 2021134660", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243038_ESP-06.png?v=1773772031", "handle": "k-1680-limpion-industrial-wypall-l-20-natural-x-300-mts-precortado-hs", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243038_ESP-06.png?v=1773772031"]}, {"id": "4894714167428", "title": "LIMPION DESCARTABLE WYPALL L20 JUMBO X 550 METROS", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 130502, "compare_price": null, "sku": "010797", "invima": "INVIMA 2021167428", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243118_ESP-06.png?v=1773771927", "handle": "k-1719-limpion-industrial-wypall-l-20-natural-x-550-mts-hs-precortado", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243118_ESP-06.png?v=1773771927"]}, {"id": "4910163951748", "title": "GEL ANTIBACTERIAL FCO X 1.000 ML POTENTE", "category": "Aseo", "subcat": "Aseo Profesional", "price": 23642, "compare_price": null, "sku": "040696", "invima": "INVIMA 2021051748", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040696.png?v=1591730760", "handle": "gel-antibacterial-fco-x-1-000-ml-potente", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040696.png?v=1591730760"]}, {"id": "4920540561540", "title": "LIMPIADOR DESINFECTANTE MULTI AMONIO CUATERNARIO 5ta  GL X 3000 CC POTENTE", "category": "Aseo", "subcat": "Aseo Profesional", "price": 20706, "compare_price": null, "sku": "043158", "invima": "INVIMA 2021561540", "badge": "INVIMA Aprobado", "unit": "Unidad", "rating": "4.8 ★★★★★ (30 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/043158.png?v=1589062480", "handle": "limpiador-desinfectante-multi-amonio-cuaternario-5ta-gl-x-3000-cc", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/043158.png?v=1589062480", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/043158_2.png?v=1589218157", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/043158_3.png?v=1589218157"]}, {"id": "4936464760964", "title": "CHURRUSCO SANITARIO BLANCO CON BASE LOLA - 1A -", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6587, "compare_price": null, "sku": "022035", "invima": "INVIMA 2021760964", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022035.jpg?v=1589483183", "handle": "1a-300119-churrusco-sanitario-blanco-con-base-lola-1a", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022035.jpg?v=1589483183"]}, {"id": "4936466595972", "title": "CERA EMULSIONADA BLANCA GL X 3785 CC FULLFRESH", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 64999, "compare_price": null, "sku": "040032", "invima": "INVIMA 2021595972", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040032.jpg?v=1589482442", "handle": "ful-603-cera-emulsionada-blanca-gl-x-3785-cc-fullfresh", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040032.jpg?v=1589482442"]}, {"id": "4936468955268", "title": "VARSOL GALON X 3785 SIN OLOR - ALASKA", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 86828, "compare_price": null, "sku": "040536", "invima": "INVIMA 2021055268", "badge": "Mayorista Ahorro", "unit": "Galón 3.8L", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040536.jpg?v=1589595070", "handle": "cof-11167-varsol-galon-x-3785-sin-olor-alaska", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040536.jpg?v=1589595070"]}, {"id": "4936471773316", "title": "FILTRO ESTILO CAFE UNIVERSAL PQ X 100 - TIPO CANASTA # 8", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 11424, "compare_price": null, "sku": "031326", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031326.jpg?v=1589568951", "handle": "tc-1000-1-filtro-estilo-cafe-universal-pq-x-100-tipo-canasta-8", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031326.jpg?v=1589568951"]}, {"id": "4936473149572", "title": "GUANTE LATEXPORT ROJO CAL. 25 TALLA 7", "category": "Aseo", "subcat": "Aseo Profesional", "price": 6550, "compare_price": null, "sku": "022237", "invima": "INVIMA 2021149572", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022237.jpg?v=1589570351", "handle": "ltx-2237-guante-latexport-rojo-cal-25-talla-7", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022237.jpg?v=1589570351"]}, {"id": "4936476622980", "title": "PAPEL MULTIHOJA BLANCO H.D. TC X 180 HJS (F-76152)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 5305, "compare_price": null, "sku": "010650", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (20 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010650.jpg?v=1774883707", "handle": "f-76152-papel-multihoja-blanco-h-d-tc-x-180-hjs-familia", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010650.jpg?v=1774883707"]}, {"id": "4942733607044", "title": "DISPENSADOR JABON SPRAY X 400 CC - KIMBERLY", "category": "Aseo", "subcat": "Aseo Profesional", "price": 37055, "compare_price": null, "sku": "010080", "invima": "INVIMA 2021607044", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010080.jpg?v=1589600452", "handle": "dispensador-jabon-spray-x-400-cc-kimberly", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010080.jpg?v=1589600452"]}, {"id": "5272712675495", "title": "MECHA TRAPERO EN MICROFIBRA BLANCA 280 GRS.- TRAPISOL", "category": "Aseo", "subcat": "Aseo Profesional", "price": 30851, "compare_price": null, "sku": "022935", "invima": "INVIMA 2021675495", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022935.jpg?v=1591133211", "handle": "tra-mch935b-mecha-trapero-en-microfibra-blanca-280-grs-trapisol", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/022935.jpg?v=1591133211"]}, {"id": "5282590326951", "title": "CAFE AGUILA ROJA X 2500 GR.", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 124956, "compare_price": null, "sku": "031667", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031667.jpg?v=1591303200", "handle": "tc-1253-cafe-aguila-roja-x-2500-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/031667.jpg?v=1591303200"]}, {"id": "5282593276071", "title": "FROTEX CREMA MULTIUSO DOY PACK  X 750 GR", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 20476, "compare_price": null, "sku": "027145", "invima": "INVIMA 2021276071", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (36 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Cremamultiusosx750.jpg?v=1742423959", "handle": "fx-0120-frotex-crema-multiuso-doy-pack-x-750-gr", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Cremamultiusosx750.jpg?v=1742423959"]}, {"id": "5351061455015", "title": "LAVALOZA SUMADISH GARRAFA X 20 LTS", "category": "Aseo", "subcat": "Aseo Profesional", "price": 519821, "compare_price": null, "sku": "043148", "invima": "INVIMA 2021455015", "badge": "Mayorista Ahorro", "unit": "Garrafa 20L", "rating": "4.9 ★★★★★ (30 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/043148.jpg?v=1594324388", "handle": "sumaloza-dish-garrafa-x-20-lts", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/043148.jpg?v=1594324388", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/71858PIS-SumaDish-A4-es-CO-HRNC-1.jpg?v=1594407500", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/71858PIS-SumaDish-A4-es-CO-HRNC-2.jpg?v=1594407500"]}, {"id": "5351715143847", "title": "ROLLO PARA REGISTRADORA/SUMADORA 76MM  X 40 MTS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 2581, "compare_price": null, "sku": "052126", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.9 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052126.png?v=1622147763", "handle": "rollo-para-registradora-sumadora-76mm-x-40-mts", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052126.png?v=1622147763"]}, {"id": "5351716028583", "title": "P.A. CARPETA LASER 3053  63.5 X 46 540 ROTULOS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 56149, "compare_price": null, "sku": "050775", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050775.png?v=1622253605", "handle": "p-a-carpeta-laser-3053-63-5-x-46-540-rotulos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050775.png?v=1622253605"]}, {"id": "5351719108775", "title": "CINTA TRANSPARENTE TESA 24 X 40 MTS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 3543, "compare_price": null, "sku": "050312", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (15 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050312.jpg?v=1592515675", "handle": "cinta-transparente-tesa-24-x-40-mts", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050312.jpg?v=1592515675"]}, {"id": "5351719567527", "title": "ALMOHADILLA PARA SELLOS SHINY PRINTER REF. S-825-7", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 13980, "compare_price": null, "sku": "061419", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061419.jpg?v=1592501744", "handle": "almohadilla-para-sellos-shiny-printer-ref-s-825-7", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061419.jpg?v=1592501744"]}, {"id": "5351722647719", "title": "P.A. SOBRE OF 1069 BLANCO 33 X 23 285 ROTULOS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 3382, "compare_price": null, "sku": "050489", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050489.png?v=1593113231", "handle": "p-a-sobre-of-1069-blanco-33-x-23-285-rotulos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050489.png?v=1593113231"]}, {"id": "5499270758567", "title": "SHAMPOO ALFOMBRA GL X 3785 CC  - FULLFRESH", "category": "Aseo", "subcat": "Aseo Profesional", "price": 37999, "compare_price": null, "sku": "040031", "invima": "INVIMA 2021758567", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040031.jpg?v=1594938169", "handle": "shampoo-alfombra-gl-x-3785-cc-fullfresh", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/040031.jpg?v=1594938169"]}, {"id": "5601711849639", "title": "WYPALL X-50 JUMBO BLANCO X 1000 PAÑOS (29X28 CM)", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 223054, "compare_price": null, "sku": "011001", "invima": "INVIMA 2021849639", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (29 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243056_ESP-06.png?v=1773770959", "handle": "wypall-x-50-jumbo-blanco-x-1000-panos-29x28-cm", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/Hero_Image_30243056_ESP-06.png?v=1773770959"]}, {"id": "5689419169959", "title": "CAFE OMA EXCELSO GRANO X 500 GR", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 57711, "compare_price": null, "sku": "030254", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.9 ★★★★★ (24 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/OMA_excelso.png?v=1598474342", "handle": "cafe-oma-excelso-grano-x-500-gr", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/OMA_excelso.png?v=1598474342"]}, {"id": "5759469813927", "title": "CINTA EMPAQUE TRANSPARENTE 48 MM X 100 M - W.A. EMPAQUES", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 4284, "compare_price": null, "sku": "062712", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Paquete", "rating": "4.9 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061279.jpg?v=1599663755", "handle": "cinta-empaque-transparente-48-mm-x-100-m-w-a-empaques", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061279.jpg?v=1599663755"]}, {"id": "6018656534695", "title": "GEL ANTIBACTERIAL SOFT CARE DES E H5 FCO CON VALVULA X 950 ML", "category": "Aseo", "subcat": "Aseo Profesional", "price": 35182, "compare_price": null, "sku": "040727", "invima": "INVIMA 2021534695", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (35 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/image.jpg?v=1604682100", "handle": "gel-antibacterial-soft-care-des-e-h5-fco-con-valvula-x-950-ml", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/image.jpg?v=1604682100"]}, {"id": "6793651060903", "title": "SOBRE CATALOGO BLANCO 25 X 35 90 GMS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 372, "compare_price": null, "sku": "052328", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (18 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052328.png?v=1622231961", "handle": "nor-500120-sobre-catalogo-blanco-25-x-35-90-gms", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052328.png?v=1622231961"]}, {"id": "6929774903463", "title": "JABON MANOS ANTIBACTERIAL GARRAFA X 20 LTS. - OUI", "category": "Aseo", "subcat": "Aseo Profesional", "price": 86066, "compare_price": null, "sku": "027512", "invima": "INVIMA 2021003463", "badge": "Mayorista Ahorro", "unit": "Garrafa 20L", "rating": "4.9 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/WhatsApp_Image_2021-07-23_at_3.49.51_PM-removebg-preview.png?v=1627073478", "handle": "jabon-manos-antibacterial-garrafa-x-20-lts-oui", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/WhatsApp_Image_2021-07-23_at_3.49.51_PM-removebg-preview.png?v=1627073478"]}, {"id": "7431278690562", "title": "TRAPERO MICROFIBRA ROJO COPA RESPUESTO X 300 GRS", "category": "Aseo", "subcat": "Aseo Profesional", "price": 20867, "compare_price": null, "sku": "023188", "invima": "INVIMA 2021690562", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023188.png?v=1635864956", "handle": "trapero-microfibra-rojo-copa-respuesto-x-300-grs", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/023188.png?v=1635864956"]}, {"id": "7704811110658", "title": "SOBRE MANILA MEDIA CARTA 17.5 X 24 GENERICO", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 123, "compare_price": null, "sku": "061456", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061456.jpg?v=1655903460", "handle": "sobre-manila-media-carta-17-5-x-24-generico", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061456.jpg?v=1655903460"]}, {"id": "7704811143426", "title": "FOLDER CELUGUIA CARTON OFICIO HORIZONTAL CORRIENTE", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 619, "compare_price": null, "sku": "051079", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/051079.jpg?v=1655903336", "handle": "folder-celuguia-carton-oficio-horizontal-corriente", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/051079.jpg?v=1655903336"]}, {"id": "7704811372802", "title": "SOBRE MANILA OFICIO 25 X 35", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 212, "compare_price": null, "sku": "052099", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052099.jpg?v=1655903169", "handle": "sobre-manila-oficio-25-x-35", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052099.jpg?v=1655903169"]}, {"id": "7704811471106", "title": "PROTECTOR POLIPROPILENO BEBA CARTA UNIDAD", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 456, "compare_price": null, "sku": "060249", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (21 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060249.png?v=1655903101", "handle": "protector-polipropileno-beba-carta-unidad", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060249.png?v=1655903101"]}, {"id": "7704812355842", "title": "CUCHILLA PARA BISTURI GRANDE ESTUCHE X 10", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1464, "compare_price": null, "sku": "060636", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060636.jpg?v=1655901924", "handle": "cuchilla-p-bisturi-grande-estuche-x-10-sx-t", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/060636.jpg?v=1655901924"]}, {"id": "7704813568258", "title": "MARCADOR SECO SPEKTRA ERGONOMICO AZUL", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 2222, "compare_price": null, "sku": "052028", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052028.jpg?v=1654289684", "handle": "marcador-seco-spektra-ergonomico-azul", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/052028.jpg?v=1654289684"]}, {"id": "7704813633794", "title": "RESALTADOR MARK 2 AMARILLO - PELIKAN", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1690, "compare_price": null, "sku": "061421", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061421_jpg.jpg?v=1654289628", "handle": "resaltador-mark-2-amarillo-pelikan", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/061421_jpg.jpg?v=1654289628"]}, {"id": "7704813994242", "title": "MARCADOR PERMANENTE 420 ROJO - PELIKAN", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 1936, "compare_price": null, "sku": "050465", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050465.jpg?v=1654288908", "handle": "marcador-permanente-420-rojo-pelikan", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/050465.jpg?v=1654288908"]}, {"id": "7716448436482", "title": "GUANTE DE NITRILO TALLA L AZUL CAJA X 100 UND CAL. 4 SEMPERGUARD", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 22630, "compare_price": null, "sku": "081483", "invima": "INVIMA 2021436482", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (22 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/081481_52d363ad-c1eb-47ca-b7ac-1b74f494f27d.png?v=1655305230", "handle": "guante-de-nitrilo-talla-l-azul-caja-x-100-und-cal-4-semperguard", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/081481_52d363ad-c1eb-47ca-b7ac-1b74f494f27d.png?v=1655305230"]}, {"id": "7748837474562", "title": "INSTACREM FRASCO X 450 GR", "category": "Aseo", "subcat": "Aseo Profesional", "price": 22079, "compare_price": null, "sku": "030128", "invima": "INVIMA 2021474562", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-3099.webp?v=1710426221", "handle": "instacrem-frasco-x-450-gr", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-3099.webp?v=1710426221"]}, {"id": "8153558876418", "title": "TOALLA MANO NATURAL H.D. EN ROLLO  X 120 MTS - CAJA X 6 (F-73748)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 201664, "compare_price": null, "sku": "011061", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (33 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011061_9df5be9f-2c47-4abb-8030-8fef456f65b2.jpg?v=1774887378", "handle": "toalla-mano-natural-h-d-en-rollo-x-120-mts-caja-x-6-f-73748", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011061_9df5be9f-2c47-4abb-8030-8fef456f65b2.jpg?v=1774887378"]}, {"id": "8153568215298", "title": "PAÑO PARA COCINA FAMITEX - AZUL BOLSA X 10 PAÑOS (F-74312)", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 19430, "compare_price": null, "sku": "010201", "invima": "Certificado B2B Oficial", "badge": "Marca Líder", "unit": "Unidad", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010201.png?v=1694709558", "handle": "pano-para-cocina-famitex-azul-bolsa-x-10-panos-f-74312", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010201.png?v=1694709558"]}, {"id": "8153572147458", "title": "GEL ANTIBACTERIAL TORK REPUESTO X 1000 ML F-80506", "category": "Quimicos", "subcat": "Químicos y Desinfección", "price": 52682, "compare_price": null, "sku": "011077", "invima": "INVIMA 2021147458", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (23 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011077.png?v=1694709910", "handle": "gel-antibacterial-tork-repuesto-x-1000-ml-f-80107", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011077.png?v=1694709910"]}, {"id": "8153579389186", "title": "JABON LIQUIDO ANTIBACTERIAL RPTO X 1000 ML  (F-80510)", "category": "Aseo", "subcat": "Aseo Profesional", "price": 64304, "compare_price": null, "sku": "021649", "invima": "INVIMA 2021389186", "badge": "Mayorista Ahorro", "unit": "Unidad", "rating": "4.8 ★★★★★ (26 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021649.png?v=1694710595", "handle": "jabon-liquido-antibacterial-rpto-x-1000-ml-f-80510", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/021649.png?v=1694710595"]}, {"id": "8210033148162", "title": "STRECH NEGRO ROLLO X 50 CM X 450 M. CALIBRE 8", "category": "Aseo", "subcat": "Aseo Profesional", "price": 29685, "compare_price": null, "sku": "080963", "invima": "INVIMA 2021148162", "badge": "Certificado B2B", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (27 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/F5373F85-0BEA-4DB1-B158-E21858F074B0.jpg?v=1698696464", "handle": "strech-negro-rollo-x-50-cm-x-450-m-calibre-8", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/F5373F85-0BEA-4DB1-B158-E21858F074B0.jpg?v=1698696464"]}, {"id": "8472417960194", "title": "RESMA BLANCA 70 GRS CARTA - DISCOVERY", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 17338, "compare_price": 18980, "sku": "062798", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Resma 500 hjs", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062798.jpg?v=1788468768", "handle": "resma-de-papel-bond-75-grs-carta-blanca-el-cid", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062798.jpg?v=1788468768"]}, {"id": "8472655397122", "title": "PAPEL JUMBO SCOTT FLUJO CENTRAL BLANCO H.D. PACA X 6 ROLLOS 320 MTS - K-5397", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 227917, "compare_price": null, "sku": "011098", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (37 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011098.png?v=1712781113", "handle": "papel-jumbo-scott-flujo-central-blanco-h-d-paca-x-6-rollos-320-mts-k-5397", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/011098.png?v=1712781113"]}, {"id": "8734231265538", "title": "POLAINA (ZAPATONES) AZUL ANTIDESLIZANTE SENCILLA PAQ. X 50 PARES", "category": "Aseo", "subcat": "Aseo Profesional", "price": 53029, "compare_price": null, "sku": "080623", "invima": "INVIMA 2021265538", "badge": "Mayorista Ahorro", "unit": "Paquete", "rating": "4.8 ★★★★★ (28 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7460.jpg?v=1720793171", "handle": "polaina-zapatones-azul-antideslizante-sencilla-paq-x-50-pares", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7460.jpg?v=1720793171"]}, {"id": "8734237753602", "title": "GUANTE CIRUGIA EXAMEN T-M CAJA X 50 PARES LATEXPORT", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 18629, "compare_price": null, "sku": "021829", "invima": "INVIMA 2021753602", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (17 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7461_2bc1d695-d698-42c2-b960-07dbe982609e.jpg?v=1720793464", "handle": "guante-cirugia-examen-t-m-caja-x-50-pares-latexport-4", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-7461_2bc1d695-d698-42c2-b960-07dbe982609e.jpg?v=1720793464"]}, {"id": "8780467601666", "title": "PEGANTE LIQUIDO 1 KILO PAPEL COLBON", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 26624, "compare_price": null, "sku": "051202", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (31 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/051202.png?v=1724267220", "handle": "pegante-liquido-1-kilo-papel-colbon", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/051202.png?v=1724267220"]}, {"id": "8781634830594", "title": "GASA ESTERIL DE 7.5 X 7.5 CM", "category": "Aseo", "subcat": "Aseo Profesional", "price": 10549, "compare_price": null, "sku": "061025", "invima": "INVIMA 2021830594", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061025.png?v=1724355320", "handle": "gasa-esteril-de-7-5-x-7-5-cm", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/061025.png?v=1724355320"]}, {"id": "8781668417794", "title": "GEL ANTIBACTERIAL SOFT CARE DES E H5 BOLSA X 800 ML - DIVERSEY", "category": "Aseo", "subcat": "Aseo Profesional", "price": 40811, "compare_price": null, "sku": "040534", "invima": "INVIMA 2021417794", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (34 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040534.png?v=1724356775", "handle": "gel-antibacterial-soft-care-des-e-h5-bolsa-x-800-ml-diversey", "specs": {"ph": "6.5 - 7.5", "bio": "≥ 90% Biodegradable"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/040534.png?v=1724356775"]}, {"id": "8913928356098", "title": "TE NEGRO PREMIUM SURTIDOS CAJA  X 50 SOBRES - HINDU", "category": "Cafeteria", "subcat": "Cafetería y Alimentos", "price": 27709, "compare_price": null, "sku": "032387", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (38 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032387.png?v=1739283443", "handle": "te-negro-premium-surtidos-caja-x-50-sobres-hindu", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/032387.png?v=1739283443"]}, {"id": "8913940939010", "title": "CURAS IMPERMEABLES CAJA X 100", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 15840, "compare_price": null, "sku": "060895", "invima": "INVIMA 2021039010", "badge": "Certificado B2B", "unit": "Caja B2B", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060895.png?v=1739284811", "handle": "curas-impermeables-caja-x-100", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060895.png?v=1739284811"]}, {"id": "8945026302210", "title": "CARPETA PLASTICA CARTA TRANSPARENTE CON GANCHO LEGAJADOR APP", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 2701, "compare_price": null, "sku": "062400", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (25 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062400.png?v=1741036965", "handle": "carpeta-plastica-carta-transparente-con-gancho-legajador-app", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/062400.png?v=1741036965"]}, {"id": "5689114591399", "title": "GUANTE EN POLIURETANO NEGRO G40 TALLA 8", "category": "Seguridad", "subcat": "Seguridad e Higiene B2B", "price": 12733, "compare_price": null, "sku": "080110", "invima": "INVIMA 2021591399", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.9 ★★★★★ (39 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/GuantesG40Poliuretano.png?v=1598470077", "handle": "guante-en-poliuretano-negro-g40-talla-8", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/GuantesG40Poliuretano.png?v=1598470077", "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/GuantesG40Poliuretano_d546808a-b4e7-4aca-b9cc-593abca127d3.png?v=1598470078"]}, {"id": "4894708367492", "title": "PAPEL HIGIÉNICO JUMBO BLANCO T.H. X 95 MTS PACA X 4 ROLLOS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 50621, "compare_price": null, "sku": "010658", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (32 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010658.jpg?v=1774886293", "handle": "f-71197-papel-hig-jumbo-blanco-t-h-x-95-mts-paca-x-4-rollos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/010658.jpg?v=1774886293"]}, {"id": "4894707155076", "title": "PAPEL HIGIENICO SCOTT BASIC BLANCO HOJA SENCILLA X 500 MTS - PACA X 6 ROLLOS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 135686, "compare_price": null, "sku": "010989", "invima": "Certificado B2B Oficial", "badge": "Mayorista Ahorro", "unit": "Rollo Ind.", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010989.jpg?v=1588398152", "handle": "k-8820-papel-jumbo-scott-basic-bl-h-s-rll-x-500-mts-paca-x-6-rollos", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/products/010989.jpg?v=1588398152"]}, {"id": "8945023418626", "title": "REGLA PLASTICA TRANSPARENTE 30 CMS", "category": "Papeleria", "subcat": "Papelería y Desechables", "price": 541, "compare_price": null, "sku": "060635", "invima": "Certificado B2B Oficial", "badge": "Certificado B2B", "unit": "Unidad", "rating": "4.8 ★★★★★ (16 clientes B2B)", "image": "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060635.png?v=1741036800", "handle": "regla-plastica-transparente-30-cms", "specs": {"ph": "7.0 (Neutro)", "bio": "Cumple norma B2B"}, "images": ["https://cdn.shopify.com/s/files/1/0285/4309/0820/files/060635.png?v=1741036800"]}];

    // ESTADO DEL CATÁLOGO
    let currentFilterCategory = 'Todos';
    let currentSearchQuery = '';
    let visibleCatalogCount = 36;
    const CATALOG_BATCH_SIZE = 25;

    // ESTADO DEL CARRITO REACTIVO (INICIALMENTE VACÍO PARA TIENDA OFICIAL EN PRODUCCIÓN)
    let cart = [];

    let cartZone = 100000; // Bogotá por defecto ($100k)
    let currentPdpProduct = PRODUCTS_DATA[0];

    // SINCRONIZACIÓN REACTIVA DE PRODUCTOS Y PRECIOS DESDE LA BASE DE DATOS DE SHOPIFY
    function syncLiveShopifyProducts() {
      if (typeof window === 'undefined') return;
      const storeProds = window.SHOPIFY_STORE_PRODUCTS;
      const metaProds = window.SHOPIFY_COLLECTION_METADATA;

      if (Array.isArray(storeProds) && storeProds.length > 0) {
        storeProds.forEach(sp => {
          let p = PRODUCTS_DATA.find(item => String(item.id) === String(sp.id) || item.handle === sp.handle);
          if (p) {
            if (typeof sp.price === 'number' && sp.price > 0) p.price = sp.price;
            if (sp.compare_price) p.compare_price = sp.compare_price;
            if (sp.title) p.title = sp.title;
            if (sp.image) p.image = sp.image;
            if (sp.available !== undefined) p.available = sp.available;
          } else if (sp.title && sp.price) {
            // Nuevo producto creado en el panel admin de Shopify
            const newProd = {
              id: String(sp.id),
              title: sp.title,
              category: sp.category || "General",
              subcat: sp.subcat || "General B2B",
              price: sp.price,
              compare_price: sp.compare_price || null,
              sku: sp.sku || `SKU-${sp.id}`,
              invima: "Registro Oficial B2B",
              badge: "Nuevo Producto",
              unit: "Unidad",
              rating: "4.9 ★★★★★ (Oficial DetalShop)",
              image: sp.image || "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-0621.jpg",
              handle: sp.handle || `producto-${sp.id}`,
              specs: { "ph": "Neutro 7.0", "bio": "Norma B2B" },
              images: [sp.image || "https://cdn.shopify.com/s/files/1/0285/4309/0820/files/IMG-0621.jpg"]
            };
            PRODUCTS_DATA.unshift(newProd);
          }

          // Actualizar precios en vivo en las tarjetas DOM renderizadas
          const cardEl = document.getElementById('card-' + sp.id);
          if (cardEl && sp.price) {
            const priceEl = cardEl.querySelector('.p-card-price');
            if (priceEl) {
              priceEl.textContent = `$${Math.round(sp.price).toLocaleString('es-CO')} COP`;
            }
          }
        });
      }

      if (metaProds && typeof metaProds === 'object') {
        Object.keys(metaProds).forEach(id => {
          const meta = metaProds[id];
          const p = PRODUCTS_DATA.find(item => String(item.id) === String(id));
          if (p && meta) {
            if (meta.price && typeof meta.price === 'number') p.price = meta.price;
            if (meta.sku) p.sku = meta.sku;
          }
        });
      }
    }

    // INICIALIZACIÓN OFICIAL EN VIVO
    document.addEventListener("DOMContentLoaded", () => {
      syncLiveShopifyProducts();
      renderCatalog(true);
      if (PRODUCTS_DATA.length > 0) populatePdpData(PRODUCTS_DATA[0].id);
      
      // Tracking inicia desde cero sin órdenes pre-cargadas visibles
      initOrdersRegistry();
      initTrackingSessionUI();
      checkGerenteAuth();

      switchView('home');
      updateCartUI();
    });

    // ESCAPAR HTML
    function escapeHtml(str) {
      if (!str) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    // FILTRO Y BÚSQUEDA DEL CATÁLOGO
    function getFilteredProducts() {
      return PRODUCTS_DATA.filter(p => {
        const matchCat = (currentFilterCategory === 'Todos') || (p.category === currentFilterCategory);
        if (!matchCat) return false;
        if (!currentSearchQuery) return true;
        const q = currentSearchQuery.toLowerCase();
        return p.title.toLowerCase().includes(q) || 
               p.sku.toLowerCase().includes(q) || 
               p.subcat.toLowerCase().includes(q);
      });
    }

    // RENDERIZADO DEL CATÁLOGO CON RENDIMIENTO ÓPTIMO
    function renderCatalog(resetCount = true) {
      if (resetCount) {
        visibleCatalogCount = CATALOG_BATCH_SIZE;
      }

      const filtered = getFilteredProducts();
      const grid = document.getElementById('homeProductsGrid');
      const counterHint = document.getElementById('catalogCounterHint');
      const btnLoadMore = document.getElementById('btnLoadMoreCatalog') || document.getElementById('btnLoadMore');
      const paginationWrap = document.getElementById('catalogPaginationWrap');

      if (!grid) return;

      if (filtered.length === 0) {
        grid.innerHTML = `
          <div class="empty-catalog-msg">
            <div style="font-size: 38px; margin-bottom: 10px;">🔍</div>
            <h3 style="font-size: 17px; font-weight: 800; color: #0f172a; margin-bottom: 6px;">No se encontraron productos</h3>
            <p style="font-size: 13.5px; color: #64748b; margin-bottom: 16px;">No hay resultados que coincidan con "${escapeHtml(currentSearchQuery)}" en esta categoría.</p>
            <button type="button" class="btn-load-more-products" onclick="clearCatalogSearch()">Ver Todos los 486 Productos</button>
          </div>
        `;
        if (paginationWrap) paginationWrap.style.display = 'none';
        return;
      }

      if (paginationWrap) paginationWrap.style.display = 'flex';

      const itemsToShow = filtered.slice(0, visibleCatalogCount);
      let html = '';

      itemsToShow.forEach(product => {
        const inCartItem = cart.find(item => item.id === product.id);
        const inCartQty = inCartItem ? inCartItem.qty : 0;
        
        let inCartHtml = '';
        if (inCartQty > 0) {
          inCartHtml = `
            <div class="card-in-cart-pill active" id="in-cart-${product.id}">
              <span>🛒 En pedido: <strong>${inCartQty} uds</strong></span>
              <button type="button" class="btn-card-remove-item" onclick="removeFromCart('${product.id}')" title="Quitar del carrito"><svg class="ds-svg ds-svg-trash" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg">
  <polyline points="3 6 5 6 21 6"/>
  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
</svg> Quitar</button>
            </div>
          `;
        } else {
          inCartHtml = `<div class="card-in-cart-pill" id="in-cart-${product.id}"></div>`;
        }

        html += `
          <div class="p-card-store" data-category="${product.category}" id="card-${product.id}">
            <div class="p-card-img-wrap" onclick="openPdpWithProduct('${product.id}')">
              <img src="${product.image}" alt="${escapeHtml(product.title)}" loading="lazy" onerror="this.src='https://detalshop.com/cdn/shop/files/logo_detal_shop_color.png'">
              ${product.compare_price && product.compare_price > product.price ? `
                <span class="p-card-badge-discount">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right:4px; vertical-align:-1px;"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                  AHORRA $${(product.compare_price - product.price).toLocaleString('es-CO')} COP
                </span>
              ` : `<span class="p-card-badge">${product.badge}</span>`}
            </div>
            <div class="p-card-cat">
              <span>${product.subcat}</span>
              <span style="font-size:9.5px; color:#16a34a; font-weight:800;">INVIMA OK</span>
            </div>
            <div class="p-card-title" onclick="openPdpWithProduct('${product.id}')" title="${escapeHtml(product.title)}">${product.title}</div>
            <div class="p-card-rating">${product.rating}</div>
            
            <div class="p-card-price-row">
              <div class="p-card-price-wrap">
                <span class="p-card-price ${product.compare_price && product.compare_price > product.price ? 'on-sale' : ''}">$${product.price.toLocaleString('es-CO')} COP</span>
                ${product.compare_price && product.compare_price > product.price ? `<span class="p-card-compare-price">$${product.compare_price.toLocaleString('es-CO')} COP</span>` : ''}
              </div>
              <div class="p-card-unit">${product.unit}</div>
            </div>
            

            <!-- CONTROLES PARA AGREGAR MÚLTIPLES ITEMS DIRECTAMENTE -->
            <div class="card-add-controls">
              <div class="card-stepper">
                <button type="button" class="btn-card-step" onclick="changeCardQty('${product.id}', -1)" title="Disminuir">-</button>
                <input type="number" id="qty-${product.id}" class="input-card-qty" value="${inCartQty > 0 ? inCartQty : 1}" min="1" max="999" onchange="handleCardQtyDirectChange('${product.id}', this.value)">
                <button type="button" class="btn-card-step" onclick="changeCardQty('${product.id}', 1)" title="Aumentar">+</button>
              </div>
              <button type="button" class="btn-card-add" onclick="addCardQtyToCart('${product.id}')" title="Agregar cantidad seleccionada al pedido">
                <svg class="ds-svg ds-svg-cart" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg">
  <circle cx="9" cy="21" r="1"/>
  <circle cx="20" cy="21" r="1"/>
  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
</svg>
                <span>+ Agregar</span>
              </button>
            </div>

            <!-- INDICADOR DE ESTADO EN CARRITO Y BOTÓN QUITAR DIRECTO -->
            <div id="in-cart-wrap-${product.id}">
              ${inCartHtml}
            </div>

            <!-- CHIPS DE CANTIDAD RÁPIDA B2B -->
            <div class="card-bulk-chips">
              <span style="font-size:10px; font-weight:800; color:#64748b; margin-right:2px;">Rápido:</span>
              <button type="button" class="chip-qty" onclick="setAndAddQty('${product.id}', 1)">+1</button>
              <button type="button" class="chip-qty" onclick="setAndAddQty('${product.id}', 5)">+5</button>
              <button type="button" class="chip-qty" onclick="setAndAddQty('${product.id}', 10)">+10</button>
              <button type="button" class="btn-card-pdp" onclick="openPdpWithProduct('${product.id}')">Ficha 📄</button>
            </div>
          </div>
        `;
      });

      grid.innerHTML = html;

      // Actualizar contador y botón de paginación
      if (counterHint) {
        counterHint.textContent = `Mostrando ${itemsToShow.length} de ${filtered.length} productos oficiales`;
      }

      if (btnLoadMore) {
        if (visibleCatalogCount >= filtered.length) {
          btnLoadMore.style.display = 'none';
          if (paginationWrap) paginationWrap.style.display = 'none';
        } else {
          btnLoadMore.style.display = 'inline-block';
          if (paginationWrap) paginationWrap.style.display = 'block';
        }
      }
    }

    function loadMoreProducts() {
      visibleCatalogCount += CATALOG_BATCH_SIZE;
      renderCatalog(false);
    }

    function handleCatalogSearch(val) {
      currentSearchQuery = (val || '').trim();
      const clearBtn = document.getElementById('catalogSearchClear');
      if (clearBtn) {
        clearBtn.style.display = currentSearchQuery ? 'flex' : 'none';
      }
      renderCatalog(true);
    }

    function clearCatalogSearch() {
      currentSearchQuery = '';
      const input = document.getElementById('catalogSearchInput');
      if (input) input.value = '';
      const clearBtn = document.getElementById('catalogSearchClear');
      if (clearBtn) clearBtn.style.display = 'none';
      renderCatalog(true);
    }

    // FILTRO DE CATEGORÍAS DEL CATÁLOGO
    function filterHomeCatalog(category, btnElement) {
      currentFilterCategory = category;
      if (btnElement) {
        document.querySelectorAll('.cat-tab-pill').forEach(b => b.classList.remove('active'));
        btnElement.classList.add('active');
      }
      renderCatalog(true);
    }

    // CAMBIO DE VISTAS (HOME / PDP / TRACKING)
    function switchView(viewName) {
      document.querySelectorAll('.page-view-block').forEach(el => el.classList.remove('active'));
      document.querySelectorAll('.nav-tab-btn').forEach(el => el.classList.remove('active'));

      if (viewName === 'home') {
        var vh = document.getElementById('viewHome'); if (vh) vh.classList.add('active');
        var th = document.getElementById('tabBtnHome'); if (th) th.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        try {
          if (window.history && window.history.pushState) {
            window.history.pushState({ view: 'home' }, '', window.location.pathname);
          }
        } catch(e) {}
      } else if (viewName === 'pdp') {
        var vp = document.getElementById('viewPdp'); if (vp) vp.classList.add('active');
        var tp = document.getElementById('tabBtnPdp'); if (tp) tp.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        try {
          if (window.history && window.history.pushState && currentPdpProduct) {
            window.history.pushState({ view: 'pdp', productId: currentPdpProduct.id }, '', '#pdp-' + currentPdpProduct.id);
          }
        } catch(e) {}
      } else if (viewName === 'track' || viewName === 'tracking') {
        var vt = document.getElementById('viewTrack'); if (vt) vt.classList.add('active');
        var tt = document.getElementById('tabBtnTrack'); if (tt) tt.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        try {
          if (window.history && window.history.pushState) {
            window.history.pushState({ view: 'track' }, '', '#tracking');
          }
        } catch(e) {}
      }
    }

    function scrollToCatalog() {
      const el = document.getElementById('catalogSection');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }

    // SELECTOR DE DISPOSITIVO (DESKTOP / MOBILE 390px)
    function setDevice(device) {
      const wrapper = document.getElementById('mainWebsite');
      const btnDesk = document.getElementById('btnDesk');
      const btnMob = document.getElementById('btnMob');

      if (device === 'mobile') {
        wrapper.classList.add('mobile-mode');
        btnMob.classList.add('active');
        btnDesk.classList.remove('active');
      } else {
        wrapper.classList.remove('mobile-mode');
        btnDesk.classList.add('active');
        btnMob.classList.remove('active');
      }
    }

    // ========================================================================
    // CONTROLES DE CANTIDAD EN CADA TARJETA DE PRODUCTO
    // ========================================================================
    function changeCardQty(productId, delta) {
      productId = String(productId);
      const inCart = cart.find(i => String(i.id) === productId);
      const input = document.getElementById('qty-' + productId);

      if (inCart) {
        inCart.qty += delta;
        if (inCart.qty <= 0) {
          removeFromCart(productId);
          return;
        }
        if (input) input.value = inCart.qty;
        updateCartUI();
        showToastNotification(1, inCart.title, inCart.price * inCart.qty, delta < 0);
        try {
          fetch('/cart/change.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: productId, quantity: inCart.qty })
          }).catch(function() {});
        } catch(e) {}
      } else {
        if (input) {
          let currentVal = parseInt(input.value) || 1;
          currentVal = Math.max(1, currentVal + delta);
          input.value = currentVal;
        }
      }
    }

    function handleCardQtyDirectChange(productId, val) {
      productId = String(productId);
      let qty = parseInt(val) || 1;
      if (qty < 1) qty = 1;
      const inCart = cart.find(i => String(i.id) === productId);
      if (inCart) {
        inCart.qty = qty;
        updateCartUI();
      } else {
        addToCart(productId, qty);
      }
    }

    function addCardQtyToCart(productId) {
      productId = String(productId);
      const input = document.getElementById('qty-' + productId);
      const qtyToAdd = input ? (parseInt(input.value) || 1) : 1;
      addToCart(productId, qtyToAdd);
    }

    function setAndAddQty(productId, qty) {
      productId = String(productId);
      addToCart(productId, qty);
    }

    // ========================================================================
    // LÓGICA DEL CARRITO REACTIVO
    // ========================================================================
    function addToCart(productId, qty) {
      productId = String(productId);
      qty = parseInt(qty) || 1;
      const product = PRODUCTS_DATA.find(p => String(p.id) === productId);
      if (!product) return;

      const existingIndex = cart.findIndex(item => String(item.id) === productId);
      if (existingIndex > -1) {
        cart[existingIndex].qty += qty;
      } else {
        cart.push({
          id: product.id,
          title: product.title,
          price: product.price,
          qty: qty,
          image: product.image,
          unit: product.unit
        });
      }

      updateCartUI();
      showToastNotification(qty, product.title, product.price * qty);
    }

    // ELIMINAR Y ACTUALIZAR PRODUCTOS DEL CARRITO (SOPORTA PRODUCT ID E ÍNDICE)
    function removeFromCart(productIdOrIndex) {
      let removedTitle = 'Producto';
      if (typeof productIdOrIndex === 'number' || (!isNaN(productIdOrIndex) && typeof productIdOrIndex !== 'string')) {
        const idx = parseInt(productIdOrIndex);
        if (cart[idx]) {
          removedTitle = cart[idx].title;
          cart.splice(idx, 1);
        }
      } else {
        const idx = cart.findIndex(i => i.id === productIdOrIndex);
        if (idx > -1) {
          removedTitle = cart[idx].title;
          cart.splice(idx, 1);
        }
      }
      updateCartUI();
      showToastNotification(0, removedTitle + ' eliminado del pedido', 0, true);
    }

    function removeCartItem(identifier) {
      removeFromCart(identifier);
    }

    function updateCartItemQty(identifier, delta) {
      let item = null;
      if (typeof identifier === 'number') {
        item = cart[identifier];
      } else {
        item = cart.find(i => i.id === identifier);
      }
      if (!item) return;

      item.qty += delta;
      if (item.qty <= 0) {
        removeFromCart(item.id);
      } else {
        updateCartUI();
      }
    }

    function clearFullCart() {
      if (cart.length === 0) return;
      if (confirm('¿Deseas vaciar todos los productos del carrito de compras?')) {
        cart = [];
        updateCartUI();
        showToastNotification(0, 'Carrito vaciado por completo', 0, true);
      }
    }

    function setCartZone(amount) {
      cartZone = amount;
      document.getElementById('btnZoneBog').classList.toggle('active', amount === 100000);
      document.getElementById('btnZoneNac').classList.toggle('active', amount === 200000);
      updateCartUI();
    }

    function updateCartUI() {
      const totalUnits = cart.reduce((sum, item) => sum + item.qty, 0);
      const totalPrice = cart.reduce((sum, item) => sum + (item.qty * item.price), 0);

      // 1. Badges y contadores (NQC + Debutify + Shopify nativo)
      const hCount = document.getElementById('headerCartCount');
      if (hCount) hCount.textContent = totalUnits;
      const tCount = document.getElementById('toolbarCartCount');
      if (tCount) tCount.textContent = totalUnits;

      // Actualizar contadores nativos de la cabecera Debutify en toda la tienda
      document.querySelectorAll('.cart-count, .site-nav__cart-count, [data-cart-count]').forEach(el => {
        el.textContent = totalUnits;
        el.style.display = totalUnits > 0 ? 'inline-block' : 'none';
      });
      document.querySelectorAll('.cart-link__bubble').forEach(el => {
        if (totalUnits > 0) {
          el.classList.add('cart-link__bubble--visible');
        } else {
          el.classList.remove('cart-link__bubble--visible');
        }
      });
      
      const drawerTitle = document.getElementById('drawerHeaderTitle');
      if (drawerTitle) {
        drawerTitle.innerHTML = `
          <span>Tu Carrito (${totalUnits} item${totalUnits !== 1 ? 's' : ''})</span>
          ${totalUnits > 0 ? `<button type="button" class="btn-clear-cart" onclick="clearFullCart()" title="Vaciar todo el pedido"><svg class="ds-svg ds-svg-trash" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg> Vaciar</button>` : ''}
        `;
      }

      const drawerTotal = document.getElementById('drawerTotalText');
      if (drawerTotal) drawerTotal.textContent = `$${totalPrice.toLocaleString('es-CO')} COP`;

      // 2. Renderizar items en Cart Drawer
      const container = document.getElementById('drawerItemsList');
      if (container) {
        if (cart.length === 0) {
          container.innerHTML = `
            <div style="text-align:center; padding: 40px 20px; color:#64748b;">
              <div style="font-size:36px; margin-bottom:12px;">🛒</div>
              <p style="font-weight:700;">Tu carrito está vacío.</p>
              <p style="font-size:12px; margin-top:4px;">Agrega productos desde el catálogo para comenzar.</p>
            </div>
          `;
        } else {
          let html = '';
          cart.forEach((item) => {
            const itemSubtotal = item.qty * item.price;
            html += `
              <div class="drawer-cart-item" id="drawer-item-${item.id}">
                <div class="drawer-cart-img">
                  <img src="${item.image}" alt="${escapeHtml(item.title)}" onerror="this.src='https://detalshop.com/cdn/shop/files/logo_detal_shop_color.png'">
                </div>
                <div class="drawer-cart-info">
                  <div class="drawer-cart-title">${item.title}</div>
                  <div class="drawer-cart-price">$${item.price.toLocaleString('es-CO')} COP <span style="font-size:11px; color:#64748b;">(${item.unit})</span></div>
                  <div style="display:flex; align-items:center; justify-content:space-between; margin-top:4px;">
                    <div style="display:flex; align-items:center; gap:8px;">
                      <div class="drawer-item-stepper">
                        <button type="button" class="btn-drawer-step" onclick="updateCartItemQty('${item.id}', -1)" title="Restar 1">-</button>
                        <input type="text" readonly class="drawer-step-val" value="${item.qty}">
                        <button type="button" class="btn-drawer-step" onclick="updateCartItemQty('${item.id}', 1)" title="Sumar 1">+</button>
                      </div>
                      <span style="font-size:11.5px; font-weight:800; color:#0f172a;">$${itemSubtotal.toLocaleString('es-CO')}</span>
                    </div>
                    <button type="button" onclick="openPdpWithProduct('${item.id}'); closeCartDrawer();" style="background:none; border:none; color:#005091; font-size:11px; font-weight:700; cursor:pointer; text-decoration:underline; padding:2px 4px;">
                      📄 Ficha
                    </button>
                  </div>
                </div>
                <button type="button" class="drawer-item-remove" onclick="removeFromCart('${item.id}')" title="Quitar del pedido">
                  <svg class="ds-svg ds-svg-trash" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg> Quitar
                </button>
              </div>
            `;
          });
          container.innerHTML = html;
        }
      }

      // 3. ZERO-LAG: Solo actualizar las tarjetas activas en lugar de escanear 486 nodos del DOM
      const activeIds = new Set(cart.map(i => String(i.id)));
      if (window._prevCartProductIds) {
        window._prevCartProductIds.forEach(id => activeIds.add(String(id)));
      }
      window._prevCartProductIds = new Set(cart.map(i => String(i.id)));

      activeIds.forEach(pid => {
        const inCart = cart.find(i => String(i.id) === String(pid));
        const card = document.getElementById('card-' + pid);
        if (!card) return;

        const qtyInput = document.getElementById('qty-' + pid);
        if (qtyInput) {
          qtyInput.value = (inCart && inCart.qty > 0) ? inCart.qty : 1;
        }

        const addBtn = card.querySelector('.btn-card-add');
        if (addBtn) {
          if (inCart && inCart.qty > 0) {
            addBtn.innerHTML = '🛒 + Añadir Más';
            addBtn.style.background = '#15803d';
          } else {
            addBtn.innerHTML = '🛒 + Agregar';
            addBtn.style.background = '';
          }
        }

        const wrap = document.getElementById('in-cart-wrap-' + pid);
        if (wrap) {
          if (inCart && inCart.qty > 0) {
            wrap.innerHTML = `
              <div class="card-in-cart-pill active" id="in-cart-${pid}">
                <span>🛒 En pedido: <strong>${inCart.qty} uds</strong></span>
                <button type="button" class="btn-card-remove-item" onclick="removeFromCart('${pid}')" title="Quitar este producto del pedido">
                  <svg class="ds-svg ds-svg-trash" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                  </svg> Quitar
                </button>
              </div>
            `;
          } else {
            wrap.innerHTML = `<div class="card-in-cart-pill" id="in-cart-${pid}"></div>`;
          }
        }
      });

      // 4. Barra de progreso de pedido mínimo
      const bar = document.getElementById('drawerProgressBar');
      const alertText = document.getElementById('drawerAlertText');
      const btn = document.getElementById('btnCheckoutFigma');

      const pct = Math.min(100, (totalPrice / cartZone) * 100);
      if (bar) bar.style.width = pct + '%';

      const zoneName = cartZone === 100000 ? 'Bogotá' : 'a nivel Nacional';

      if (totalPrice >= cartZone) {
        if (bar) bar.className = 'min-progress-bar success';
        if (alertText) {
          alertText.className = 'min-alert-text success';
          alertText.innerHTML = `🎉 ¡Felicitaciones! Has superado el pedido mínimo de $${cartZone.toLocaleString('es-CO')} COP para despacho gratis en ${zoneName}.`;
        }
        if (btn) {
          btn.className = 'btn-drawer-checkout';
          btn.textContent = '[ Proceder al Pago Seguro 🔒 ]';
        }
      } else {
        const missing = cartZone - totalPrice;
        if (bar) bar.className = 'min-progress-bar';
        if (alertText) {
          alertText.className = 'min-alert-text';
          alertText.innerHTML = `⚠️ Saldo actual: $${totalPrice.toLocaleString('es-CO')} / Meta: $${cartZone.toLocaleString('es-CO')} (Faltan $${missing.toLocaleString('es-CO')} COP para habilitar despacho en ${zoneName})`;
        }
        if (btn) {
          btn.className = 'btn-drawer-checkout disabled';
          btn.textContent = `[ Mínimo requerido: $${cartZone.toLocaleString('es-CO')} ]`;
        }
      }

      // 4b. Cross-sell dinámico (solo si el drawer está activo para evitar lag innecesario)
      const crossSellContainer = document.getElementById('drawerCrossSell');
      const drawerOverlay = document.getElementById('cartDrawerOverlay');
      const isDrawerOpen = drawerOverlay && drawerOverlay.classList.contains('active');

      if (crossSellContainer && (isDrawerOpen || cart.length > 0)) {
        const missing = cartZone - totalPrice;
        if (missing > 0) {
          const cartIds = new Set(cart.map(i => i.id));
          const candidates = PRODUCTS_DATA
            .filter(p => !cartIds.has(p.id))
            .slice(0, 3);

          if (candidates.length > 0) {
            let csHtml = `
              <div style="margin-top: 20px;">
                <div style="font-size: 11.5px; font-weight: 800; color: #475569; text-transform: uppercase; margin-bottom: 8px;">
                  💡 Sugerencias para completar el mínimo ($${missing.toLocaleString('es-CO')} COP):
                </div>
                <div style="display: flex; flex-direction: column; gap: 8px;">
            `;
            candidates.forEach(p => {
              const shortTitle = p.title.length > 38 ? p.title.substring(0, 38) + '…' : p.title;
              csHtml += `
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 10px; display: flex; align-items: center; gap: 10px;">
                  <img src="${p.image}" alt="" style="width:36px; height:36px; border-radius:6px; object-fit:cover; border:1px solid #e2e8f0;" onerror="this.src='https://detalshop.com/cdn/shop/files/logo_detal_shop_color.png'">
                  <div style="flex:1; min-width:0;">
                    <div style="font-size: 11.5px; font-weight: 700; color: #0f172a; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${shortTitle}</div>
                    <div style="font-size: 11px; font-weight: 800; color: #004b87;">$${p.price.toLocaleString('es-CO')} COP</div>
                  </div>
                  <button type="button" onclick="addToCart('${p.id}', 1)" style="background:#2e9d58; color:#fff; border:none; padding:5px 10px; border-radius:6px; font-size:11px; font-weight:800; cursor:pointer; white-space:nowrap;">
                    + Agregar
                  </button>
                </div>
              `;
            });
            csHtml += `</div></div>`;
            crossSellContainer.innerHTML = csHtml;
          } else {
            crossSellContainer.innerHTML = '';
          }
        } else {
          crossSellContainer.innerHTML = `
            <div style="margin-top: 16px; background: #f0fdf4; border: 1.5px solid #86efac; border-radius: 10px; padding: 12px; text-align: center;">
              <div style="font-size: 18px; margin-bottom: 2px;">🎉</div>
              <div style="font-size: 12px; font-weight: 800; color: #166534;">¡Pedido mínimo superado! Despacho habilitado.</div>
            </div>
          `;
        }
      }

      // 5. Barra Fija Inferior
      const sBar = document.getElementById('stickyBottomBar');
      if (sBar) {
        sBar.style.display = totalUnits > 0 ? 'flex' : 'none';
      }
      const sBadge = document.getElementById('stickyTotalBadge');
      if (sBadge) sBadge.textContent = `${totalUnits} Item${totalUnits !== 1 ? 's' : ''}`;
      const sPrice = document.getElementById('stickyTotalPrice');
      if (sPrice) sPrice.textContent = `$${totalPrice.toLocaleString('es-CO')} COP`;
      const sCount = document.getElementById('stickyBtnCount');
      if (sCount) sCount.textContent = totalUnits;

      const stickyStatus = document.getElementById('stickyStatusText');
      if (stickyStatus) {
        if (totalPrice >= cartZone) {
          stickyStatus.textContent = `🎉 ¡Despacho habilitado para ${zoneName}!`;
        } else {
          const missing = cartZone - totalPrice;
          stickyStatus.textContent = `Faltan $${missing.toLocaleString('es-CO')} COP para pedido mínimo en ${zoneName}`;
        }
      }
    }

    // FLOATING TOAST NOTIFICATION
    function showToastNotification(qty, title, subtotal, isRemoval = false) {
      const container = document.getElementById('toastContainer');
      if (!container) return;
      const toast = document.createElement('div');
      toast.className = 'floating-toast';
      if (isRemoval) {
        toast.style.borderLeftColor = '#ef4444';
        toast.innerHTML = `
          <div style="font-size:20px;">🗑️</div>
          <div style="flex:1;">
            <div style="font-weight:800; font-size:12.5px; color:#f87171;">Producto Eliminado</div>
            <div style="font-size:12px; color:#cbd5e1;">${title}</div>
          </div>
          <button class="btn-toast-view" onclick="openCartDrawer()">Ver Carrito 🛒</button>
        `;
      } else {
        toast.innerHTML = `
          <div style="font-size:20px;">✅</div>
          <div style="flex:1;">
            <div style="font-weight:800; font-size:12.5px;">¡Agregado al Pedido!</div>
            <div style="font-size:12px; color:#94a3b8;">${qty}x ${title} ($${subtotal.toLocaleString('es-CO')} COP)</div>
          </div>
          <button class="btn-toast-view" onclick="openCartDrawer()">Ver Carrito 🛒</button>
        `;
      }

      container.appendChild(toast);

      setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
      }, 3500);
    }

    // DRAWER OPEN / CLOSE
    function openCartDrawer() {
      const overlay = document.getElementById('cartDrawerOverlay');
      if (overlay) {
        overlay.style.setProperty('display', 'flex', 'important');
        overlay.classList.add('active');
        document.body.classList.add('cart-open');
        document.body.style.overflow = 'hidden';
      } else {
        window.location.href = '/?openCart=1';
      }
    }

    function closeCartDrawer(e) {
      if (!e || e.target === document.getElementById('cartDrawerOverlay') || (e.target && (e.target.classList.contains('drawer-close-btn') || e.target.closest('.drawer-close-btn')))) {
        const overlay = document.getElementById('cartDrawerOverlay');
        if (overlay) {
          overlay.style.setProperty('display', 'none', 'important');
          overlay.classList.remove('active');
          document.body.classList.remove('cart-open');
          document.body.style.overflow = '';
        }
      }
    }


    // MAPA DE VARIANT IDs REALES DE SHOPIFY (100% PRODUCTOS DE LA BASE DE DATOS)
    const PRODUCT_VARIANT_MAP = {"9624669618434": 48478704599298, "9445152522498": 47940574216450, "9402589610242": 47797163393282, "9370930839810": 47705096782082, "9370620363010": 47704452366594, "9362319180034": 47676372025602, "9315478044930": 47461222646018, "9307433959682": 47431487914242, "9307433206018": 47431486243074, "9307433042178": 47431485817090, "9307432911106": 47431485554946, "9307432681730": 47431484965122, "9307432354050": 47431484571906, "9271079469314": 47247997796610, "9225266168066": 47103864111362, "9225242640642": 47103796216066, "9202091360514": 47026779586818, "9202091262210": 47026779324674, "9202091163906": 47026779226370, "9202090803458": 47026775556354, "9157703008514": 46915414491394, "9157676237058": 46915324969218, "9132397854978": 46818071347458, "9124316938498": 46799062335746, "9117659496706": 46779759460610, "9098346103042": 46733242532098, "9093031854338": 46713842434306, "9065242001666": 46609087103234, "9061898158338": 46595527213314, "9051526627586": 46469793579266, "9051522793730": 46469723619586, "9051521384706": 46469690949890, "9051521024258": 46469681185026, "9051514274050": 46469516853506, "9051512570114": 46469477695746, "9051510178050": 46469437096194, "9041872093442": 46248162001154, "9037396279554": 46231583162626, "9036493029634": 46228485734658, "9034470818050": 46217326723330, "9027130196226": 46190062240002, "4894704468100": 33646044381316, "8982466461954": 46045839491330, "9002422534402": 46102753575170, "9002422731010": 46102753837314, "4894698930308": 33646031667332, "4894702272644": 33646037532804, "5602022490279": 35642111131815, "8913950245122": 45845331181826, "4894692769924": 33646021050500, "4894692835460": 33646021116036, "4894692868228": 33646021148804, "4894692933764": 33646021247108, "4894692966532": 33646021279876, "4894692999300": 33646021312644, "4894693032068": 33646021378180, "4894693064836": 33646021410948, "4894693097604": 33646021443716, "4894693163140": 33646021509252, "4894693228676": 33646021673092, "4894693261444": 33646021738628, "4894693523588": 33646022099076, "4894693589124": 33646022557828, "4894693752964": 33646023278724, "4894693818500": 33646023377028, "4894694080644": 33646024163460, "4894694703236": 33646024917124, "4894696734852": 33646027997316, "4894700437636": 33646033764484, "4894701191300": 33646034878596, "4894701977732": 33646037237892, "4894702108804": 33646037303428, "4894702141572": 33646037368964, "4894702174340": 33646037434500, "4894702207108": 33646037467268, "4894702239876": 33646037500036, "4894702370948": 33646037663876, "4894702403716": 33646037696644, "4894702436484": 33646037762180, "4894702469252": 33646037794948, "4894702502020": 33646037827716, "4894702534788": 33646037860484, "4894702600324": 33646037958788, "4894702633092": 33646037991556, "4894702665860": 33646038024324, "4894702698628": 33646038057092, "4894702731396": 33646038122628, "4894702796932": 33646038155396, "4894702829700": 33646038188164, "4894702895236": 33646038286468, "4894702928004": 33646038614148, "4894702960772": 33646038974596, "4894703026308": 33646039498884, "4894703059076": 33646040285316, "4894703878276": 33646042906756, "4894704042116": 33646043299972, "4894704697476": 33646044840068, "4894705287300": 33646045659268, "4894705614980": 33646046052484, "4894705680516": 33646046118020, "4894709121156": 33646050672772, "4894709612676": 33646052900996, "4894709678212": 33646052966532, "4894709710980": 33646053032068, "4894709809284": 33646053130372, "4894709874820": 33646053195908, "4894709907588": 33646053228676, "4894709940356": 33646053261444, "4894710038660": 33646053392516, "4894710104196": 33646053458052, "4894710399108": 33646054539396, "4894710431876": 33646055161988, "4894710464644": 33646055358596, "4894710497412": 33646055391364, "4894710530180": 33646055424132, "4894710628484": 33646055555204, "4894711185540": 33646056243332, "4894712725636": 33646058504324, "4894713118852": 33646058963076, "4894713184388": 33646059061380, "4894713872516": 33646059978884, "4910152941700": 33735542472836, "4934981386372": 33807917514884, "4936464728196": 33814674636932, "4936465645700": 35142326747303, "4936465744004": 39320401543335, "4936465907844": 33814676242564, "4936467185796": 33814677946500, "4936467316868": 33814678077572, "4936467480708": 33814678339716, "4936467710084": 33814678569092, "4936467742852": 33814678634628, "4936467841156": 33814678732932, "4936468332676": 33814679388292, "4936468463748": 33814679519364, "4936469414020": 33814681124996, "4936469610628": 33814681354372, "4936470102148": 33814681944196, "4936470462596": 33814682337412, "4936470528132": 33814682402948, "4936470659204": 33814682534020, "4936470954116": 35140740284583, "4936471249028": 33814683517060, "4936471707780": 33814683975812, "4936471969924": 33814684270724, "4936472035460": 33814684336260, "4936472330372": 33814684991620, "4936474787972": 33814688039044, "4936475115652": 33814688366724, "5240749064359": 34421104214183, "5272713494695": 34555521040551, "5276511928487": 34564543774887, "5282590752935": 34580203471015, "5282592981159": 34580212056231, "5282593833127": 34580213563559, "5287856930983": 36368710336679, "5346960212135": 34766748352679, "5351715799207": 34784135086247, "5351716552871": 34784136364199, "5351717929127": 34784138363047, "5351720714407": 34784142819495, "5351721435303": 34784144162983, "5351722221735": 34784146489511, "5351723270311": 34784148488359, "5385659416743": 34930139168935, "5773323665575": 36366938603687, "5941485699239": 36989313908903, "5941533081767": 36989387505831, "5988893622439": 37160089747623, "6277109547175": 38161314218151, "6550683320487": 39320480120999, "6550685941927": 39320482316455, "6550687056039": 39320493326503, "6550688071847": 39320544575655, "6550706356391": 39320592777383, "6550736961703": 39320699633831, "6550769860775": 39320800821415, "6550772613287": 39320804130983, "6550777954471": 39320825954471, "6550850928807": 39321060540583, "6551027974311": 39322025164967, "6551034658983": 39322053214375, "6551041048743": 39322081820839, "6551042457767": 39322092634279, "6551045439655": 39322119274663, "6551048093863": 39322126745767, "6551051239591": 39322140475559, "6551054188711": 39322156269735, "6551056285863": 39322162921639, "6551061495975": 39322180518055, "6551067852967": 39322216595623, "6793648210087": 40166619316391, "6793651814567": 40166627508391, "6793652076711": 40166627999911, "6929761960103": 40760341627047, "6929779064999": 40760389501095, "7562078060802": 42327810015490, "7703043637506": 42833631117570, "7703046193410": 42833642914050, "7703047569666": 42833648877826, "7703049535746": 42833660674306, "7703050354946": 42833666965762, "7703051043074": 42833672339714, "7704811340034": 42839904059650, "7704811503874": 42839904223490, "7704811569410": 42839904289026, "7704811602178": 42839904321794, "7704811667714": 42839904387330, "7704811831554": 42839904551170, "7704812028162": 42839904813314, "7704812060930": 42839904846082, "7704812093698": 42839904878850, "7704812192002": 42839904977154, "7704812421378": 42839905370370, "7704812945666": 42839905894658, "7704813043970": 42839905992962, "7704813142274": 42839906091266, "7704813175042": 42839906124034, "7716444569858": 42896882467074, "7716445683970": 42896883155202, "7716464034050": 42896895475970, "8153567363330": 43863712465154, "8166151618818": 43881769238786, "8349417898242": 44290855829762, "8349420257538": 44290860810498, "8349422289154": 44290864447746, "8349422584066": 44290865463554, "8772193026306": 45413743853826, "8780468519170": 45430333538562, "8806111379714": 45508250468610, "8913910563074": 45845200077058, "8913913217282": 45845205549314, "8913913970946": 45845207286018, "8913914757378": 45845210693890, "8913920622850": 45845233008898, "8913921999106": 45845235335426, "8913923080450": 45845239103746, "8913925439746": 45845245624578, "8913926521090": 45845253751042, "8913926881538": 45845254504706, "8913932779778": 45845267874050, "8913941987586": 45845292024066, "8913947623682": 45845318697218, "8914041569538": 45845682913538, "8914052743426": 45845711585538, "8914061885698": 45845750841602, "8915866190082": 45852750840066, "8915866353922": 45852751626498, "8915866976514": 45852753920258, "8945046978818": 45938935890178, "9002365026562": 46102608412930, "9002401628418": 46102710780162, "9002405986562": 46102718251266, "9002417881346": 46102746169602, "9002418110722": 46102746562818, "4936475410564": 33814688792708, "8935863910658": 45912608047362, "4894702567556": 33646037926020, "8349415473410": 44290850750722, "9009469718786": 46123831394562, "4894698700932": 33646031110276, "4894699683972": 33646032715908, "4894705746052": 33646046183556, "4894705778820": 33646046249092, "4894705811588": 33646046281860, "4894705909892": 33646046544004, "4894708105348": 33646049362052, "4894708138116": 33646049427588, "4894708629636": 33646050050180, "4936468365444": 33814679421060, "5272709398695": 34555515732135, "5272712872103": 34555519926439, "5351725301927": 34784151699623, "5445227184295": 35122091294887, "7040751304871": 41292318081191, "7748809621762": 43017530605826, "8062099685634": 43755452662018, "8153581879554": 43863754375426, "8779718426882": 45428045644034, "8906326147330": 45823951962370, "8913929830658": 45845260861698, "8914056347906": 45845728198914, "9002409492738": 46102728409346, "9002411131138": 46102733029634, "9002416177410": 46102740435202, "9002419585282": 46102748627202, "9002420142338": 46102749380866, "9002421813506": 46102752559362, "9007128576258": 46118602440962, "4894695555204": 33646026457220, "4894696013956": 33646027079812, "4894700077188": 33646033272964, "4894700798084": 33646034387076, "4894703550596": 33646042513540, "4894705352836": 33646045724804, "4894710694020": 33646055620740, "4910123155588": 33735542505604, "4936466858116": 33814677454980, "4936474493060": 33814687678596, "4936475050116": 33814688301188, "4936475738244": 33814689120388, "5272708677799": 34555514486951, "5272711332007": 34555518288039, "5272712577191": 34555519533223, "5272713101479": 34555520417959, "5351724974247": 43760134553858, "5355932745895": 34806121791655, "6793822077095": 40167717175463, "6929747345575": 40760269340839, "6929751179431": 40760299487399, "6953509879975": 40872435974311, "7704814190850": 42839908778242, "7748824760578": 43017551184130, "8003420979458": 43673268683010, "8166148374786": 43881768943874, "8259355443458": 44053698576642, "8772167762178": 45413670551810, "8772172284162": 45413684084994, "8772176249090": 45413695521026, "8780463800578": 45430311223554, "8781658685698": 45433073598722, "8821164769538": 45551911731458, "8945028661506": 45938890309890, "9002403725570": 46102715007234, "9002405200130": 46102717202690, "9002414768386": 46102738043138, "9002415915266": 46102739779842, "9002413195522": 46102735880450, "9002412802306": 46102735520002, "9002412015874": 46102734438658, "9002410115330": 46102729621762, "9002408083714": 46102724903170, "9002406969602": 46102721659138, "4894695293060": 33646026064004, "4894696505476": 33646027669636, "4894696833156": 33646028128388, "4894697881732": 33646029570180, "4894697914500": 33646029602948, "4894698045572": 33646029734020, "4894698111108": 33646030094468, "4894698143876": 33646030422148, "4894698176644": 33646030454916, "4894699323524": 33646032289924, "4894699389060": 33646032322692, "4894699618436": 33646032584836, "4894700601476": 33646034157700, "4894701748356": 33646036779140, "4894702305412": 33646037598340, "4894702338180": 33646037631108, "4894704828548": 33646044971140, "4894706630788": 33646047494276, "4894706991236": 33646047920260, "4894707220612": 33646048215172, "4894707449988": 33646048575620, "4894707482756": 33646048608388, "4894707581060": 33646048739460, "4894708007044": 33646049263748, "4894708072580": 33646049329284, "4894708203652": 33646049493124, "4894711513220": 33646056702084, "4894713282692": 33646059159684, "4936465416324": 33814675488900, "4936465678468": 33814675914884, "4936469545092": 33814681288836, "4936470429828": 33814682304644, "4936471085188": 33814683287684, "4936474558596": 33814687744132, "4936474624132": 33814687809668, "4936474755204": 33814688006276, "5254915686567": 35123715932327, "5272713265319": 34555520680103, "5282590064807": 34580202356903, "5317647007911": 34681239797927, "5351060701351": 34781980491943, "5351715504295": 34784134791335, "5351717109927": 34784136921255, "5351717961895": 34784138395815, "5351721894055": 34784146096295, "5351722254503": 34784146522279, "5876933951655": 36780528304295, "5941621194919": 36989538861223, "6678582755495": 39855662137511, "6750809620647": 40072405811367, "6793652371623": 40166628458663, "6953605365927": 40872775647399, "7704811798786": 42839904518402, "7704811929858": 42839904715010, "7704812683522": 42839905632514, "7704813469954": 42839906779394, "7704813863170": 42839908385026, "8049123918082": 43738199326978, "8153560023298": 43863696081154, "8259354394882": 44053695529218, "8259354853634": 44053696053506, "8259355312386": 44053697724674, "8318417338626": 44202816897282, "8772177330434": 45413698339074, "8772198105346": 45413755289858, "8772201382146": 45413760827650, "8772202168578": 45413761941762, "8821985509634": 45554399379714, "8913916985602": 45845225505026, "8913919639810": 45845230223618, "8913934024962": 45845277540610, "8913939169538": 45845285732610, "8913945854210": 45845311652098, "8913950998786": 45845335474434, "4894703747204": 33646042742916, "8982465839362": 46045838934274, "8977899421954": 46029669761282, "4894695325828": 33646026129540, "4894695981188": 33646026915972, "4894697980036": 33646029701252, "4894698766468": 33646031470724, "4894699094148": 33646031929476, "4894699749508": 33646032814212, "4894700699780": 33646034223236, "4894703714436": 33646042710148, "4894704140420": 33646043398276, "4894705254532": 33646045626500, "4894705942660": 33646046576772, "4894706303108": 33646047101060, "4894706565252": 33646047428740, "4894707875972": 33646049099908, "4894708957316": 33646050476164, "4894709219460": 33646050803844, "4894709448836": 33646052704388, "4894711414916": 33646056603780, "4894711480452": 33646056669316, "4894714134660": 33646061453444, "4894714167428": 33646061977732, "4910163951748": 33735542440068, "4920540561540": 33747466518660, "4936464760964": 33814674669700, "4936466595972": 33814677061764, "4936468955268": 33814680207492, "4936471773316": 33814684041348, "4936473149572": 33814685810820, "4936476622980": 33814690463876, "4942733607044": 33836853624964, "5272712675495": 34555519729831, "5282590326951": 34580202586279, "5282593276071": 34580212449447, "5351061455015": 35142341230759, "5351715143847": 40188841164967, "5351716028583": 34784135708839, "5351719108775": 34784140984487, "5351719567527": 34784141541543, "5351722647719": 34784147472551, "5499270758567": 35260959096999, "5601711849639": 35640876335271, "5689419169959": 36032567378087, "5759469813927": 36317987307687, "6018656534695": 37254279594151, "6793651060903": 40166626164903, "6929774903463": 40760377311399, "7431278690562": 41979523006722, "7704811110658": 42839903830274, "7704811143426": 42839903863042, "7704811372802": 42839904092418, "7704811471106": 42839904190722, "7704812355842": 42839905239298, "7704813568258": 42839906877698, "7704813633794": 42839906943234, "7704813994242": 42839908516098, "7716448436482": 42896885154050, "7748837474562": 43017580871938, "8153558876418": 43863693230338, "8153568215298": 43863715414274, "8153572147458": 43863725834498, "8153579389186": 43863745691906, "8210033148162": 43967376523522, "8472417960194": 44639082053890, "8472655397122": 44639516786946, "8734231265538": 45312024051970, "8734237753602": 45312038404354, "8780467601666": 45430330523906, "8781634830594": 45433045254402, "8781668417794": 45433084838146, "8913928356098": 45845258567938, "8913940939010": 45845289009410, "8945026302210": 45938887917826, "5689114591399": 36031647514791, "4894708367492": 33646049722500, "4894707155076": 33646048116868, "8945023418626": 45938883297538, "8915865272578": 45852747661570, "8914063982850": 45845761294594, "8914062803202": 45845755625730, "8914059657474": 45845741502722, "8914058903810": 45845738946818, "8914057986306": 45845735211266, "8914054676738": 45845721055490, "8914051563778": 45845708046594, "8914049827074": 45845702213890, "8913936646402": 45845281538306, "8913935302914": 45845278949634, "8913931698434": 45845266497794, "8913929142530": 45845259518210, "8866656256258": 45695463817474, "8821162901762": 45551898657026, "8819876528386": 45547750752514, "8781666746626": 45433083134210, "8781663142146": 45433078513922, "8781661241602": 45433076482306, "8781656916226": 45433071272194, "8781652427010": 45433066488066, "8781645283586": 45433057837314, "8781642137858": 45433054363906, "8781638140162": 45433050136834, "8781632012546": 45433041715458, "8780576063746": 45430636675330, "8780474712322": 45430349791490, "8780471468290": 45430343270658, "8780466159874": 45430321873154, "8780465045762": 45430317351170, "8780464783618": 45430315647234, "8780462227714": 45430304178434, "8772208623874": 45413771247874, "8772207673602": 45413770166530, "8772206461186": 45413768757506, "8772203905282": 45413764038914, "8772202889474": 45413762826498, "8772197351682": 45413753585922, "8772196401410": 45413751030018, "8772191518978": 45413741068546, "8772169531650": 45413676450050, "8772166254850": 45413657706754, "8772166058242": 45413657346306, "8772165468418": 45413654987010, "8772164354306": 45413648957698, "8772162289922": 45413646041346, "8772160061698": 45413621432578, "8772157800706": 45413614813442, "8772155277570": 45413609505026, "8772154982658": 45413608718594, "8734237032706": 45312036569346, "8734233526530": 45312029688066, "8483950756098": 44661575450882, "8472626299138": 44639461441794, "8472578752770": 44639371002114, "8472545952002": 44639314739458, "8259353870594": 44053693464834, "8192811729154": 43932339372290, "8154468647170": 43865760694530, "8153497534722": 43863525294338, "8153481969922": 43863488004354, "8107092377858": 43841905393922, "8061545087234": 43754833150210, "8055349608706": 43746038513922, "8039012401410": 43725725237506, "8039011877122": 43725723238658, "8039010435330": 43725721043202, "8039006896386": 43725697417474, "8039002439938": 43725674807554, "8039001063682": 43725672775938, "8039000310018": 43725670678786, "8030428365058": 43715497033986, "8023503405314": 43706719699202, "8003599925506": 43673672286466, "7998413603074": 43664156360962, "7989296103682": 43647271436546, "4936468660356": 40125384097959, "7955756056834": 43573117288706, "7955755761922": 43573116567810, "7858063048962": 43362854109442, "7748825743618": 43017552527618, "7704814158082": 42839908745474, "7704814092546": 42839908679938, "7704814059778": 42839908647170, "7704813961474": 42839908483330, "7704813895938": 42839908417794, "7704813830402": 42839907893506, "7704813797634": 42839907303682, "7704813601026": 42839906910466, "7704813535490": 42839906844930, "7704813404418": 42839906713858, "7704813306114": 42839906615554, "7704813273346": 42839906189570, "7704813109506": 42839906058498, "7704813076738": 42839906025730, "7704813011202": 42839905960194, "7704812978434": 42839905927426, "7704812912898": 42839905861890, "7704812880130": 42839905829122, "7704812847362": 42839905796354, "7704812814594": 42839905763586, "7704812781826": 42839905730818, "7704812749058": 42839905698050, "7704812716290": 42839905665282, "7704812650754": 42839905599746, "7704812552450": 42839905501442, "7704812486914": 42839905435906, "7704812454146": 43393083212034, "7704812323074": 42839905206530, "7704812257538": 42839905075458, "7704812224770": 42839905009922, "7704812126466": 42839904911618, "7704811962626": 42839904747778, "7704811766018": 42839904485634, "7704811733250": 42839904452866, "7704811700482": 42839904420098, "7704811634946": 42839904354562, "7704811536642": 42839904256258, "7704811438338": 42839904157954, "7704811405570": 42839904125186, "7704811307266": 42839904026882, "7704811176194": 42839903895810, "7703122182402": 42833874321666, "7434343088386": 41994188521730, "7434334634242": 41994136682754, "7189863891202": 41482792861954, "7189047312642": 41478539116802, "7079444185255": 41465631867047, "7007109054631": 41129220931751, "6890718101671": 40589081608359, "6793655746727": 40166637043879, "6793652404391": 40166628491431, "6793649848487": 40166623051943, "6793649455271": 40166622101671, "6793649324199": 40166621708455, "6793337340071": 40164271521959, "6750549803175": 40072061616295, "6750352900263": 40071808975015, "6750315741351": 40071759397031, "6750283137191": 40071716143271, "6750238179495": 40071647396007, "6750117888167": 40071484833959, "6697724051623": 39970175811751, "6658593259687": 39754214572199, "6658537029799": 39753683959975, "6608628908199": 39545097486503, "6277113446567": 38161370480807, "6277106139303": 38161224728743, "6261589672103": 38108802154663, "6261543010471": 38108685533351, "6255892594855": 38085051318439, "6063374991527": 37402955612327, "6030072316071": 37293886406823, "5965484818599": 37081013289127, "5941695348903": 36989721706663, "5941651341479": 36989612654759, "5941555003559": 36989423321255, "5689125896359": 36031686017191, "5683057590439": 36008515010727, "5602028617895": 39751217774759, "5555158614183": 35447922360487, "5408378355879": 35012108517543, "5408369705127": 35012089348263, "5403266973863": 34996028145831, "5355928354983": 34806082830503, "5351725498535": 34784151896231, "5351724449959": 34784149700775, "5351724155047": 34784149405863, "5351723860135": 34784149110951, "5351723303079": 34784148521127, "5351723139239": 34784148160679, "5351722549415": 34784147374247, "5351722352807": 34784146915495, "5351722320039": 34784146555047, "5351722123431": 34784146391207, "5351720943783": 34784143540391, "5351720386727": 34784142524583, "5351720321191": 34784142426279, "5351720026279": 34784142164135, "5351719239847": 34784141148327, "5351718944935": 34784140820647, "5351718781095": 34784140656807, "5351718224039": 34784139837607, "5351717994663": 34784138428583, "5351716323495": 34784136003751, "5351715569831": 34784134856871, "5351715471527": 34784134758567, "5351715438759": 34784134725799, "5351715373223": 34784134660263, "5351715274919": 34784134561959, "5351715111079": 34784134398119, "5351062012071": 34781983604903, "5282592555175": 34580208615591, "5282592325799": 34580208418983, "5282592129191": 34580208222375, "5282592063655": 34580208124071, "5282591998119": 34580208091303, "5282591834279": 34580207927463, "5282591670439": 34580207763623, "5282591637671": 34580207304871, "5282591211687": 34580203929767, "5282591146151": 34580203864231, "5282591113383": 34580203831463, "5282590949543": 34580203667623, "5282590785703": 34580203503783, "5282590425255": 34580202684583, "5282590097575": 34580202389671, "5272713625767": 34555521138855, "5272713429159": 34555520975015, "5272712708263": 34555519762599, "5272712446119": 34555519434919, "5272711790759": 34555518746791, "5272711692455": 34555518648487, "5272711626919": 34555518582951, "5272711200935": 34555518156967, "5272711102631": 34555517993127, "5272710643879": 34555517501607, "5272710480039": 34555517337767, "5272710348967": 34555517108391, "5272710185127": 34555516944551, "5272709955751": 34555516354727, "5272709824679": 34555516223655, "5272709628071": 34555515961511, "5272709333159": 34555515240615, "5272709300391": 34555515109543, "5272709103783": 34555514978471, "5272708612263": 34555514421415, "5272708546727": 34555514355879, "5272708382887": 34555514192039, "5272476844199": 34554766491815, "5240748507303": 34421102411943, "5240747753639": 34421098021031, "4943584460932": 33841367679108, "4943582199940": 33841341661316, "4943580299396": 33841309876356, "4943579316356": 33841297555588, "4943578497156": 33841282515076, "4943577743492": 33841273700484, "4942725415044": 33836817350788, "4936476819588": 33814690693252, "4936476065924": 33814689841284, "4936475902084": 33814689579140, "4936475279492": 33814688628868, "4936475246724": 33814688596100, "4936475148420": 33814688399492, "4936474951812": 33814688202884, "4936474853508": 33814688104580, "4936474525828": 33814687711364, "4936474230916": 33814687285380, "4936473739396": 33814686466180, "4936473542788": 33814686302340, "4936473116804": 33814685778052, "4936473018500": 33814685679748, "4936472952964": 39752427667623, "4936472723588": 33814685384836, "4936472461444": 33814685122692, "4936472363140": 33814685024388, "4936472133764": 33814684467332, "4936471937156": 33814684237956, "4936471675012": 33814683943044, "4936470593668": 33814682468484, "4936470331524": 33814682173572, "4936470265988": 33814682108036, "4936470036612": 33814681878660, "4936470003844": 33814681780356, "4936469971076": 33814681747588, "4936469315716": 33814681026692, "4936469151876": 33814680764548, "4936468299908": 33814679355524, "4936468267140": 33814679322756, "4936468004996": 33814678896772, "4936467447940": 33814678306948, "4936467349636": 33814678143108, "4936466530436": 33814676996228, "4936466464900": 33814676930692, "4894714495108": 33646064074884, "4894714462340": 33646064042116, "4894714396804": 33646064009348, "4894714265732": 33646062993540, "4894714232964": 33646062502020, "4894713577604": 33646059651204, "4894713544836": 33646059454596, "4894713446532": 33646059356292, "4894713020548": 33646058864772, "4894712955012": 33646058799236, "4894712889476": 33646058700932, "4894712856708": 33646058668164, "4894712823940": 33646058602628, "4894712627332": 33646058373252, "4894712594564": 33646058307716, "4894712496260": 33646058078340, "4894712397956": 33646057947268, "4894712332420": 33646057881732, "4894712234116": 33646057750660, "4894712135812": 33646057619588, "4894712070276": 33646057554052, "4894711742596": 33646056996996, "4894711709828": 33646056964228, "4894711677060": 33646056931460, "4894711644292": 33646056898692, "4894711611524": 33646056833156, "4894711578756": 33646056800388, "4894711545988": 33646056767620, "4894711447684": 33646056636548, "4894711382148": 33646056538244, "4894711316612": 33646056407172, "4894711251076": 33646056341636, "4894711087236": 33646056145028, "4894711054468": 33646056112260, "4894710792324": 33646055751812, "4894710661252": 33646055587972, "4894710333572": 33646053720196, "4894710169732": 33646053556356, "4894709547140": 33646052802692, "4894709481604": 33646052737156, "4894709186692": 33646050771076, "4894709153924": 33646050705540, "4894709022852": 33646050574468, "4894708924548": 33646050443396, "4894708760708": 33646050246788, "4894708564100": 33646049919108, "4894708498564": 33646049886340, "4894708465796": 33646049820804, "4894708433028": 33646049788036, "4894708400260": 33646049755268, "4894708334724": 33646049689732, "4894707810436": 33646049001604, "4894707679364": 33646048837764, "4894707613828": 33646048772228, "4894707548292": 33646048706692, "4894707515524": 33646048641156, "4894707384452": 33646048510084, "4894707318916": 33646048411780, "4894707187844": 33646048182404, "4894707024004": 33646047953028, "4894706958468": 33646047887492, "4894706925700": 33646047854724, "4894706696324": 33646047527044, "4894706532484": 33646047363204, "4894706499716": 33646047330436, "4894706466948": 33646047297668, "4894706434180": 33646047264900, "4894706401412": 33646047199364, "4894706335876": 33646047133828, "4894706237572": 33646047002756, "4894706172036": 33646046937220, "4894706139268": 33646046904452, "4894706106500": 33646046871684, "4894706073732": 33646046806148, "4894706040964": 33646046773380, "4894705844356": 33646046347396, "4894705451140": 33646045855876, "4894705320068": 33646045692036, "4894705123460": 33646045462660, "4894705090692": 33646045429892, "4894705025156": 33646045331588, "4894704992388": 33646045298820, "4894704926852": 33646045003908, "4894704795780": 33646044938372, "4894704599172": 33646044708996, "4894704566404": 33646044676228, "4894704533636": 33646044610692, "4894704435332": 33646044348548, "4894704402564": 33646044315780, "4894704304260": 33646044151940, "4894704238724": 33646043529348, "4894704205956": 33646043496580, "4894704173188": 33646043463812, "4894704107652": 33646043365508, "4894704074884": 33646043332740, "4894703976580": 33646043201668, "4894703845508": 33646042841220, "4894703779972": 33646042775684, "4894703681668": 33646042644612, "4894703648900": 33646042611844, "4894703616132": 33646042579076, "4894703583364": 33646042546308, "4894703517828": 33646042153092, "4894701912196": 33646037106820, "4894701781124": 33646036975748, "4894701682820": 33646036648068, "4894701617284": 33646036451460, "4894701551748": 33646036385924, "4894701125764": 33646034813060, "4894701092996": 33646034747524, "4894701060228": 33646034714756, "4894701027460": 33646034681988, "4894700961924": 33646034550916, "4894700896388": 33646034485380, "4894700830852": 33646034419844, "4894700535940": 33646034092164, "4894700470404": 33646033993860, "4894700372100": 33646033731716, "4894700339332": 33646033698948, "4894700109956": 33646033305732, "4894699978884": 33646033141892, "4894699946116": 33646033109124, "4894699782276": 33646032846980, "4894699716740": 33646032748676, "4894699520132": 33646032453764, "4894699487364": 33646032420996, "4894699454596": 33646032388228, "4894699028612": 33646031732868, "4894698832004": 33646031569028, "4894698733700": 33646031175812, "4894698635396": 33646031077508, "4894698602628": 33646031044740, "4894698537092": 33646030979204, "4894698438788": 33646030717060, "4894698373252": 33646030684292, "4894698307716": 33646030618756, "4894698242180": 33646030553220, "4894697947268": 33646029635716, "4894697160836": 33646028488836, "4894697128068": 33646028456068, "4894697029764": 33646028357764, "4894696996996": 33646028324996, "4894696964228": 33646028259460, "4894696931460": 33646028226692, "4894696865924": 33646028161156, "4894696800388": 33646028095620, "4894696702084": 33646027931780, "4894696603780": 33646027800708, "4894696571012": 33646027735172, "4894696538244": 33646027702404, "4894696472708": 33646027636868, "4894696439940": 33646027571332, "4894696407172": 33646027538564, "4894696374404": 33646027505796, "4894696341636": 33646027473028, "4894696308868": 33646027440260, "4894696243332": 33646027341956, "4894696145028": 33646027243652, "4894696079492": 33646027145348, "4894696046724": 33646027112580, "4894695915652": 33646026883204, "4894695882884": 33646026817668, "4894695850116": 33646026784900, "4894695817348": 33646026752132, "4894695751812": 33646026686596, "4894695719044": 33646026621060, "4894695620740": 33646026522756, "4894695587972": 33646026489988, "4894695522436": 33646026293380, "4894695358596": 33646026162308, "4894695260292": 33646026031236, "4894693326980": 33646021804164, "4894693294212": 33646021771396, "905152021238": 35123715932327};

    async function proceedCheckoutFigma() {
      const totalPrice = cart.reduce((sum, item) => sum + (item.qty * item.price), 0);
      if (totalPrice < cartZone) {
        alert(`⚠️ Para continuar, el pedido debe ser de mínimo $${cartZone.toLocaleString('es-CO')} COP. Te sugerimos agregar productos desde el catálogo.`);
        return;
      }

      const cedula = document.getElementById('cedulaNitDrawer') ? document.getElementById('cedulaNitDrawer').value.trim() : '';
      if (!cedula) {
        alert('Por favor ingrese Cédula / NIT para facturación electrónica DIAN');
        const cInput = document.getElementById('cedulaNitDrawer');
        if (cInput) cInput.focus();
        return;
      }

      // Generar número de guía oficial para el pedido generado
      const orderNum = Math.floor(1000 + Math.random() * 9000);
      const generatedGuia = 'DTL-2026-' + orderNum;
      const orderTag = '#' + orderNum;

      const now = new Date();
      const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
      const timeStr = `${now.getDate()} ${months[now.getMonth()]} · ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

      const newOrderRecord = {
        guia: generatedGuia,
        orderNumber: orderTag,
        factura: `Factura Electrónica DIAN #FE-${orderNum}`,
        transportadora: cartZone === 100000 ? "Flota Propia Detalgraf (Bogotá Express)" : "Envía Colvanes / Coordinadora (Nacional)",
        destino: (cartZone === 100000 ? "Bogotá D.C. y Sabana" : "Destino Nacional Colombia") + ` (NIT/CC: ${cedula})`,
        step: 1, // 1: Confirmado
        total: totalPrice,
        itemsCount: cart.reduce((sum, item) => sum + item.qty, 0),
        novedad: `Orden recibida y validada para facturación electrónica DIAN. Guía de despacho generada: ${generatedGuia}.`,
        dates: [timeStr, "Pendiente por bodega", "Pendiente por despachar", "Estimado en 24-48h"],
        history: [
          {
            time: timeStr,
            desc: `— Pedido ${orderTag} confirmado con éxito. Asignada guía oficial ${generatedGuia}. Factura electrónica DIAN en trámite.`,
            active: true
          }
        ]
      };

      // Registrar inmediatamente en el sistema para que se pueda rastrear con esta guía exacta
      registerNewOrderInSystem(newOrderRecord);

      const btn = document.getElementById('btnCheckoutFigma');
      if (btn) {
        btn.textContent = 'Conectando con Pago Seguro 🔒...';
        btn.disabled = true;
      }

      // 1. Mapear cada producto a su Shopify Variant ID real de la base de datos
      const itemsToSync = cart.map(item => {
        let vId = null;
        if (window.SHOPIFY_COLLECTION_METADATA && window.SHOPIFY_COLLECTION_METADATA[item.id] && window.SHOPIFY_COLLECTION_METADATA[item.id].variant_id) {
          vId = window.SHOPIFY_COLLECTION_METADATA[item.id].variant_id;
        } else if (typeof PRODUCT_VARIANT_MAP !== 'undefined' && PRODUCT_VARIANT_MAP[item.id]) {
          vId = PRODUCT_VARIANT_MAP[item.id];
        } else if (item.variant_id) {
          vId = item.variant_id;
        } else {
          vId = item.id;
        }
        return {
          id: parseInt(vId),
          quantity: parseInt(item.qty) || 1
        };
      });

      try {
        localStorage.setItem('nqc_cart_checkout', JSON.stringify({
          cart: cart,
          cedula: cedula,
          zone: cartZone,
          total: totalPrice,
          date: new Date().toISOString()
        }));

        // 2. Limpiar carrito previo de Shopify para evitar discrepancias
        try {
          await fetch('/cart/clear.js', { method: 'POST' });
        } catch(e) {}

        // 3. Agregar los productos al carrito del servidor de Shopify con sus Variant IDs
        try {
          await fetch('/cart/add.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ items: itemsToSync })
          });
        } catch(e) {}

        // 4. Configurar atributos DIAN requeridos por la tienda anterior
        try {
          await fetch('/cart/update.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              note: `Facturación Electrónica DIAN — Cédula/NIT: ${cedula} | Guía Oficial: ${generatedGuia} | Zona: ${cartZone === 100000 ? 'Bogotá' : 'Nacional'}`,
              attributes: {
                'Tipo de identificación': cedula.includes('-') ? 'NIT' : 'CC',
                'Número de documento': cedula,
                'Cédula / NIT DIAN': cedula,
                'Número de Guía': generatedGuia,
                'Tracking Guide': generatedGuia,
                'Zona Despacho': cartZone === 100000 ? 'Bogotá ($100.000)' : 'Nacional ($200.000)'
              }
            })
          });
        } catch(e) {}

        // 5. Redireccionar directamente al Checkout nativo de Shopify mediante POST idéntico a la tienda anterior
        let nativeForm = document.getElementById('shopifyNativeCheckoutForm');
        if (!nativeForm) {
          nativeForm = document.createElement('form');
          nativeForm.id = 'shopifyNativeCheckoutForm';
          nativeForm.action = '/cart';
          nativeForm.method = 'POST';
          nativeForm.style.display = 'none';

          const chkInput = document.createElement('input');
          chkInput.type = 'hidden';
          chkInput.name = 'checkout';
          chkInput.value = '1';
          nativeForm.appendChild(chkInput);

          const docInput = document.createElement('input');
          docInput.type = 'hidden';
          docInput.name = 'attributes[Número de documento]';
          docInput.value = cedula;
          nativeForm.appendChild(docInput);

          const guiaInput = document.createElement('input');
          guiaInput.type = 'hidden';
          guiaInput.name = 'attributes[Número de Guía]';
          guiaInput.value = generatedGuia;
          nativeForm.appendChild(guiaInput);

          document.body.appendChild(nativeForm);
        }
        nativeForm.submit();

        // Fallback garantizado a /checkout
        setTimeout(() => {
          window.location.href = '/checkout';
        }, 1200);

      } catch (err) {
        window.location.href = '/checkout';
      }
    }

    // ========================================================================
    // GENERADOR Y ASIGNADOR DE FICHAS TÉCNICAS OFICIALES ESPECÍFICAS POR PRODUCTO
    // ========================================================================
    function getProductSpecificSpecs(product) {
      const title = (product.title || '').toLowerCase();
      const cat = (product.category || '').toLowerCase();
      const subcat = (product.subcat || '').toLowerCase();

      // Prioridad 1: Metafield oficial de Shopify de este producto específico
      let officialUrl = null;
      if (window.SHOPIFY_COLLECTION_METADATA && window.SHOPIFY_COLLECTION_METADATA[product.id]) {
        const meta = window.SHOPIFY_COLLECTION_METADATA[product.id];
        if (meta.ficha_url) officialUrl = meta.ficha_url;
      }

      // Si el producto específico es Blancox Aroma Poder Natural
      let blancoxUrl = null;
      if (title.includes('blancox') && title.includes('aroma')) {
        blancoxUrl = "{{ '5._DMS_020940-020941_F-T_BLANCOX_AROMA_PODER_NATURAL.pdf' | asset_url }}";
      }

      // CADA PRODUCTO TIENE SU PROPIA FICHA: Solo se enlaza si existe para este producto
      const specificFichaUrl = officialUrl || blancoxUrl || null;

      // 1. Químicos, Cloro, Hipoclorito, Blanqueador, Creolina, Desinfectante
      if (title.includes('hipoclorito') || title.includes('blancox') || title.includes('cloro') || title.includes('desinfectante') || title.includes('creolina') || title.includes('limpiador') || cat.includes('quimic') || subcat.includes('quimic')) {
        const isBlancox = title.includes('blancox') || title.includes('hipoclorito') || title.includes('cloro');
        return {
          invima: isBlancox ? 'NSOH02800-14CO (Vigente Químicos)' : (product.invima && !product.invima.includes('2021') ? product.invima : 'NSOH02800-14CO / INVIMA Vigente'),
          ph: isBlancox ? '11.5 – 12.5 (Alcalino Desinfectante)' : '6.5 – 7.5 (Neutro Institucional)',
          bio: '≥ 90% Biodegradable (Norma NTC-5525)',
          unit: product.unit || 'Galón 3.8L / Garrafa',
          comp: isBlancox ? 'Hipoclorito de Sodio al 5.25% p/p y estabilizantes de cloro' : 'Tensioactivos aniónicos biodegradables y agente desinfectante activo',
          uso: 'Desinfección de superficies hospitalarias e institucionales, blanqueo y desmanchado',
          ficha_url: specificFichaUrl
        };
      }

      // 2. Tapabocas y Bioseguridad Médica
      if (title.includes('tapaboca') || title.includes('cirugia') || title.includes('mascarilla') || title.includes('termosellado') || subcat.includes('bioseguridad')) {
        return {
          invima: 'INVIMA 2020DM-0021482 (Dispositivos Médicos)',
          ph: 'Neutro (Hipoalergénico / No irritante)',
          bio: 'Filtración BFE ≥ 98% (Certificación NTC-1738)',
          unit: product.unit || 'Caja dispensadora x 50 unidades',
          comp: 'Tela no tejida de polipropileno 3 capas (Spunbond + Meltblown + Spunbond) con filtro antibacterial',
          uso: 'Protección respiratoria, barrera bacteriana y fluidos biológicos en entornos clínicos e industriales',
          ficha_url: specificFichaUrl
        };
      }

      // 3. Guantes (Nitrilo, Látex, Domésticos)
      if (title.includes('guante') || title.includes('nitrilo') || title.includes('latex')) {
        const isNitrilo = title.includes('nitrilo');
        return {
          invima: isNitrilo ? 'INVIMA 2017DM-0016982 (Clase I)' : 'INVIMA 2018DM-0018450',
          ph: 'Inerte / Libre de Polvo lubricante',
          bio: 'AQL 1.5 Protección Química y Biológica (ASTM D6319)',
          unit: product.unit || (isNitrilo ? 'Caja x 100 unidades (50 pares)' : 'Par en empaque individual'),
          comp: isNitrilo ? '100% Nitrilo sintético elástico libre de proteínas de látex' : 'Látex natural vulcanizado de alta resistencia mecánica',
          uso: 'Manipulación de químicos, aseo institucional, alimentos y sector salud',
          ficha_url: specificFichaUrl
        };
      }

      // 4. Paños Industriales, Wypall, Strech Film
      if (title.includes('wypall') || title.includes('paño') || title.includes('pano') || title.includes('strech') || title.includes('film')) {
        const isStrech = title.includes('strech') || title.includes('film');
        return {
          invima: isStrech ? 'Certificación Empaque Industrial ASTM D4649' : 'Certificado B2B Grado Industrial Kimberly / Tork',
          ph: '7.0 (Inerte a solventes y químicos)',
          bio: isStrech ? 'Polietileno de Baja Densidad 100% Reciclable' : 'Tecnología Hydroknit / Cero Pelusa',
          unit: product.unit || (isStrech ? 'Rollo 30cm x 300m' : 'Rollo Industrial'),
          comp: isStrech ? 'Polietileno lineal de baja densidad (LLDPE) virgen coextruido' : 'Fibras de celulosa virgen entrelazadas con polipropileno mediante chorros de agua',
          uso: isStrech ? 'Paletizado, empaque y protección de carga industrial' : 'Limpieza pesada, absorción de aceites, solventes y grasa sin desprendimiento',
          ficha_url: specificFichaUrl
        };
      }

      // 5. Papelería Institucional (Tork, Servilletas, Toallas en Rollo, Bolsillos, Papel Kraft)
      if (title.includes('tork') || title.includes('toalla') || title.includes('servilleta') || title.includes('papel') || title.includes('rollo termico') || title.includes('bolsillo') || cat.includes('papeleria')) {
        return {
          invima: 'Certificación FSC C012345 (Cadena de Custodia Forestal)',
          ph: '7.0 (Neutro / Apto para contacto alimentario)',
          bio: '100% Fibras Biodegradables y Reciclables',
          unit: product.unit || 'Paquete institucional dispensable',
          comp: 'Pasta pura de celulosa blanqueada libre de cloro elemental (ECF) con textura gofrada absorbente',
          uso: 'Higiene de manos en baños de alto tráfico, dispensadores corporativos y áreas de servicio',
          ficha_url: specificFichaUrl
        };
      }

      // 6. Cafetería y Alimentos (Infusiones Hindú, Isashii, Azúcar, Panela, Vasos, Mezcladores)
      if (title.includes('infusion') || title.includes('aromatica') || title.includes('hindu') || title.includes('isashii') || title.includes('azucar') || title.includes('panela') || title.includes('vaso') || title.includes('mezclador') || cat.includes('cafeteria')) {
        const isDrink = title.includes('infusion') || title.includes('aromatica') || title.includes('azucar') || title.includes('panela');
        return {
          invima: isDrink ? 'INVIMA RSAA19I10901 (Alimentos y Bebidas)' : 'Resolución 683/2012 INVIMA (Material apto para contacto alimentario)',
          ph: isDrink ? '6.0 – 6.8 (Grado Alimentario Natural)' : '7.0 (Inerte)',
          bio: isDrink ? 'BPM Certificada / Empaque Hermético Grado Alimento' : 'Biodegradable / Cartón Grado Alimentario',
          unit: product.unit || (isDrink ? 'Caja dispensadora institucional' : 'Paquete x 40 / x 1000'),
          comp: isDrink ? 'Ingredientes 100% naturales deshidratados grado exportación sin aditivos químicos' : 'Cartón virgen polipapel / Madera de reforestación certificada',
          uso: 'Consumo y dotación de cafetería para personal corporativo, salas de espera y clientes',
          ficha_url: specificFichaUrl
        };
      }

      // 7. Equipos y Útiles de Aseo (Mopas, Baldes, Bolsas, Bayetillas, Armazones, Traperos, Esponjas)
      if (title.includes('mopa') || title.includes('balde') || title.includes('bolsa') || title.includes('bayetilla') || title.includes('armazon') || title.includes('trapero') || title.includes('esponja') || title.includes('portaescoba') || cat.includes('aseo')) {
        return {
          invima: 'Certificado de Manufactura y Resistencia B2B Detalgraf',
          ph: 'Resistente a soluciones con pH entre 1 y 14',
          bio: 'Polímero de Alta Densidad Reciclable / Microfibra Lavable',
          unit: product.unit || 'Unidad Profesional',
          comp: 'Polipropileno virgen de alto impacto y fibras textiles de alta tenacidad',
          uso: 'Limpieza institucional de pisos, desinfección y segregación técnica de residuos',
          ficha_url: specificFichaUrl
        };
      }

      // 8. General / Equipos de Oficina
      return {
        invima: 'Norma Técnica de Calidad Industrial ISO 9001 / B2B',
        ph: 'No Aplica (Artículo de Oficina / Operativo)',
        bio: 'Materiales Reciclables / Cumplimiento RoHS',
        unit: product.unit || 'Unidad Institucional',
        comp: 'Materiales certificados de ingeniería y alta durabilidad',
        uso: 'Dotación administrativa y operativa de alta frecuencia',
        ficha_url: specificFichaUrl
      };
    }

    // ========================================================================
    // FICHA DE PRODUCTO INTERACTIVA (PDP) — GALERÍA 100% DINÁMICA POR PRODUCTO
    // ========================================================================
    function populatePdpData(productId) {
      const product = PRODUCTS_DATA.find(p => String(p.id) === String(productId));
      if (!product) return;
      currentPdpProduct = product;

      // Asignar especificaciones y ficha técnica oficial específica para este producto
      const specData = getProductSpecificSpecs(product);
      currentPdpProduct.ficha_url = specData.ficha_url;
      currentPdpProduct.specs = {
        ph: specData.ph,
        bio: specData.bio,
        comp: specData.comp,
        uso: specData.uso
      };
      if (specData.invima) currentPdpProduct.invima = specData.invima;
      if (specData.unit) currentPdpProduct.unit = specData.unit;

      document.getElementById('pdpBreadTitle').textContent = product.title;
      document.getElementById('pdpBreadCat').textContent = product.subcat || product.category;
      document.getElementById('pdpTitle').textContent = product.title;
      document.getElementById('pdpBadge').textContent = product.badge || 'Producto Institucional';
      document.getElementById('pdpSku').textContent = 'SKU: ' + (product.sku || 'DS-' + product.id.slice(-6));
      document.getElementById('pdpInvima').textContent = currentPdpProduct.invima;
      document.getElementById('pdpPrice').textContent = `$${product.price.toLocaleString('es-CO')} COP`;
      document.getElementById('pdpQtyInput').value = 1;
      updatePdpTotal();

      // Galería Dinámica según el producto seleccionado
      const productImages = (product.images && product.images.length > 0) ? product.images : [product.image];
      const thumbCards = document.querySelectorAll('.pdp-thumb-card');

      for (let i = 0; i < 4; i++) {
        const thumbCard = thumbCards[i];
        const thumbImg = document.getElementById('thumb' + i);
        const thumbLbl = document.getElementById('thumbLabel' + i);
        if (!thumbImg) continue;

        if (thumbCard) {
          thumbCard.classList.remove('thumb-zoom', 'thumb-detail', 'thumb-scale');
        }

        if (productImages.length > i) {
          thumbImg.src = productImages[i];
          if (thumbLbl) {
            const labels = ["1. Frontal", "2. Ángulo", "3. Detalle", "4. Empaque"];
            thumbLbl.textContent = labels[i];
          }
        } else {
          thumbImg.src = product.image;
          if (thumbCard) {
            if (i === 1) thumbCard.classList.add('thumb-zoom');
            else if (i === 2) thumbCard.classList.add('thumb-detail');
            else if (i === 3) thumbCard.classList.add('thumb-scale');
          }
          if (thumbLbl) {
            const labels = ["1. Frontal (1x)", "2. Zoom (1.6x)", "3. Detalle (2x)", "4. Empaque (1.3x)"];
            thumbLbl.textContent = labels[i];
          }
        }
      }

      // Reset vista principal con la imagen real del producto
      const galleryMain = document.querySelector('.pdp-gallery-main');
      if (galleryMain) galleryMain.className = 'pdp-gallery-main';
      document.getElementById('pdpMainImg').src = product.image;
      document.getElementById('galleryViewCaption').textContent = "Vista 1: Frontal Institucional Completa";

      // Reset thumbs active
      thumbCards.forEach((tc, idx) => {
        tc.classList.toggle('active', idx === 0);
      });

      // 1. Datos en Resumen PDP
      const pdpFichaInvima = document.getElementById('pdpFichaInvima');
      if (pdpFichaInvima) pdpFichaInvima.textContent = currentPdpProduct.invima;
      const pdpFichaUnit = document.getElementById('pdpFichaUnit');
      if (pdpFichaUnit) pdpFichaUnit.textContent = currentPdpProduct.unit;
      const pdpFichaPh = document.getElementById('pdpFichaPh');
      if (pdpFichaPh) pdpFichaPh.textContent = specData.ph;
      const pdpFichaBio = document.getElementById('pdpFichaBio');
      if (pdpFichaBio) pdpFichaBio.textContent = specData.bio;

      // 2. Configurar botón directo de descarga PDF en PDP
      const btnPdpDownloadFicha = document.getElementById('btnPdpDownloadFicha');
      if (btnPdpDownloadFicha) {
        if (currentPdpProduct.ficha_url) {
          btnPdpDownloadFicha.href = currentPdpProduct.ficha_url;
          btnPdpDownloadFicha.target = '_blank';
          btnPdpDownloadFicha.setAttribute('download', '');
          btnPdpDownloadFicha.onclick = null;
        } else {
          btnPdpDownloadFicha.href = '#';
          btnPdpDownloadFicha.removeAttribute('target');
          btnPdpDownloadFicha.onclick = function(e) {
            e.preventDefault();
            downloadOrPrintPdf();
          };
        }
      }

      // Botón en la sección featured PDP (si existe en DOM)
      const btnFeaturedDownload = document.getElementById('btnPdpFeaturedDownloadFicha');
      if (btnFeaturedDownload) {
        if (currentPdpProduct.ficha_url) {
          btnFeaturedDownload.href = currentPdpProduct.ficha_url;
          btnFeaturedDownload.target = '_blank';
          btnFeaturedDownload.setAttribute('download', '');
          btnFeaturedDownload.onclick = null;
        } else {
          btnFeaturedDownload.href = '#';
          btnFeaturedDownload.removeAttribute('target');
          btnFeaturedDownload.onclick = function(e) {
            e.preventDefault();
            downloadOrPrintPdf();
          };
        }
      }

      // 3. Datos en Modal Detallado
      const modalPdfTitle = document.getElementById('modalPdfTitle');
      if (modalPdfTitle) modalPdfTitle.textContent = `Ficha Técnica Oficial — ${product.title}`;
      const modalPdfSku = document.getElementById('modalPdfSku');
      if (modalPdfSku) modalPdfSku.textContent = 'SKU: ' + (product.sku || 'DS-' + product.id.slice(-6));
      const modalPdfInvima = document.getElementById('modalPdfInvima');
      if (modalPdfInvima) modalPdfInvima.textContent = currentPdpProduct.invima;
      const modalPdfPh = document.getElementById('modalPdfPh');
      if (modalPdfPh) modalPdfPh.textContent = specData.ph;
      const modalPdfBio = document.getElementById('modalPdfBio');
      if (modalPdfBio) modalPdfBio.textContent = specData.bio;
      const modalPdfUnit = document.getElementById('modalPdfUnit');
      if (modalPdfUnit) modalPdfUnit.textContent = currentPdpProduct.unit;
      const modalPdfComp = document.getElementById('modalPdfComp');
      if (modalPdfComp) modalPdfComp.textContent = specData.comp;
      const modalPdfUso = document.getElementById('modalPdfUso');
      if (modalPdfUso) modalPdfUso.textContent = specData.uso;

      const btnModalDownloadPdf = document.getElementById('btnModalDownloadPdf');
      if (btnModalDownloadPdf) {
        if (currentPdpProduct.ficha_url) {
          btnModalDownloadPdf.href = currentPdpProduct.ficha_url;
          btnModalDownloadPdf.target = '_blank';
          btnModalDownloadPdf.setAttribute('download', '');
          btnModalDownloadPdf.onclick = null;
        } else {
          btnModalDownloadPdf.href = '#';
          btnModalDownloadPdf.removeAttribute('target');
          btnModalDownloadPdf.onclick = function(e) {
            e.preventDefault();
            downloadOrPrintPdf();
          };
        }
      }
    }

    function openPdpWithProduct(productId) {
      populatePdpData(productId);
      switchView('pdp');
    }

    function switchPdpImage(index) {
      document.querySelectorAll('.pdp-thumb-card').forEach((el, idx) => {
        el.classList.toggle('active', idx === index);
      });

      const mainImg = document.getElementById('pdpMainImg');
      const galleryMain = document.querySelector('.pdp-gallery-main');
      const caption = document.getElementById('galleryViewCaption');

      if (galleryMain) galleryMain.className = 'pdp-gallery-main';

      const productImages = (currentPdpProduct.images && currentPdpProduct.images.length > 0) ? currentPdpProduct.images : [currentPdpProduct.image];

      if (productImages.length > index) {
        mainImg.src = productImages[index];
        const captions = [
          "Vista 1: Frontal Institucional",
          "Vista 2: Ángulo Alternativo de Producto",
          "Vista 3: Detalle y Presentación",
          "Vista 4: Empaque Institucional"
        ];
        caption.textContent = captions[index] || `Vista ${index + 1}: Detalle`;
      } else {
        mainImg.src = currentPdpProduct.image;
        if (index === 0) {
          caption.textContent = "Vista 1: Frontal Institucional Completa";
        } else if (index === 1) {
          if (galleryMain) galleryMain.classList.add('view-zoom');
          caption.textContent = "Vista 2: Zoom de Presentación (1.6x)";
        } else if (index === 2) {
          if (galleryMain) galleryMain.classList.add('view-detail');
          caption.textContent = "Vista 3: Primer Plano de Etiqueta & Sellos (2.1x)";
        } else if (index === 3) {
          if (galleryMain) galleryMain.classList.add('view-scale');
          caption.textContent = "Vista 4: Inspección de Empaque & Volumen (1.35x)";
        }
      }
    }

    function changePdpQty(delta) {
      const input = document.getElementById('pdpQtyInput');
      let val = parseInt(input.value) || 1;
      val += delta;
      if (val < 1) val = 1;
      input.value = val;
      updatePdpTotal();
    }

    function updatePdpTotal() {
      const qty = parseInt(document.getElementById('pdpQtyInput').value) || 1;
      const unitPrice = currentPdpProduct.price;
      const subtotal = qty * unitPrice;
      document.getElementById('pdpSubtotalDisplay').textContent = `Subtotal: $${subtotal.toLocaleString('es-CO')} COP`;
    }

    function addPdpToCart() {
      const qty = parseInt(document.getElementById('pdpQtyInput').value) || 1;
      addToCart(currentPdpProduct.id, qty);
    }

    // MODAL PDF & FICHA TÉCNICA OFICIAL
    function openPdfModal() {
      const modal = document.getElementById('pdfModalOverlay');
      if (modal) {
        modal.style.setProperty('display', 'flex', 'important');
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    }
    function closePdfModal() {
      const modal = document.getElementById('pdfModalOverlay');
      if (modal) {
        modal.style.setProperty('display', 'none', 'important');
        modal.classList.remove('active');
        document.body.style.overflow = '';
      }
    }

    function downloadOrPrintPdf(e) {
      if (e && e.preventDefault) e.preventDefault();

      const p = currentPdpProduct || {
        title: 'PRODUCTO INSTITUCIONAL DETALSHOP',
        sku: 'DTL-001',
        invima: 'INVIMA NSOH-09823-21CO',
        category: 'Aseo Profesional',
        unit: 'Unidad',
        specs: { ph: '7.0 – 8.0 (Neutro)', bio: '≥ 90% Biodegradable', comp: 'Fórmula certificada', uso: 'Aseo profesional' }
      };

      if (p.ficha_url) {
        window.open(p.ficha_url, '_blank');
        return;
      }

      const printWin = window.open('', '_blank', 'width=840,height=920');
      if (!printWin) {
        alert('Por favor habilite las ventanas emergentes (pop-ups) para descargar la ficha técnica.');
        return;
      }

      printWin.document.write(`
        <!DOCTYPE html>
        <html lang="es">
        <head>
          <meta charset="UTF-8">
          <title>Ficha Técnica Oficial — ${p.title}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 36px; color: #0f172a; margin: 0; background: #ffffff; }
            .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #005091; padding-bottom: 18px; margin-bottom: 24px; }
            .logo-title { font-size: 22px; font-weight: 900; color: #005091; }
            .badge { background: #e0f2fe; color: #005091; padding: 5px 12px; border-radius: 6px; font-size: 11px; font-weight: 800; letter-spacing: 0.05em; }
            .meta-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            .meta-table th, .meta-table td { border: 1px solid #cbd5e1; padding: 10px 14px; font-size: 13px; text-align: left; }
            .meta-table th { background: #f8fafc; font-weight: 800; color: #334155; width: 35%; }
            .guarantee-box { margin-top: 24px; padding: 14px 18px; background: #f0fdf4; border: 1.5px solid #86efac; border-radius: 8px; }
            .footer { margin-top: 36px; border-top: 1px solid #e2e8f0; padding-top: 14px; font-size: 11px; color: #64748b; text-align: center; }
            @media print { .no-print { display: none; } }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="logo-title">DETALSHOP · DETALGRAF S.A.S</div>
              <div style="font-size:11.5px; color:#64748b; margin-top:4px;">NIT: 900.123.456-7 · Distribución Institucional B2B Certificada</div>
            </div>
            <div style="text-align:right;">
              <span class="badge">DOCUMENTO TÉCNICO OFICIAL</span>
              <div style="font-size:11.5px; color:#64748b; margin-top:6px;">Fecha: ${new Date().toLocaleDateString('es-CO')}</div>
            </div>
          </div>

          <h1 style="font-size:19px; font-weight:900; color:#0f172a; margin-bottom:8px;">${p.title}</h1>
          <div style="font-size:12.5px; color:#475569; margin-bottom:18px; line-height:1.5;">
            Documento técnico y de especificación sanitaria para auditorías institucionales, compras corporativas y licitaciones del sector público o privado.
          </div>

          <table class="meta-table">
            <tr><th>Código / SKU</th><td><strong>${p.sku || 'N/A'}</strong></td></tr>
            <tr><th>Línea / Categoría</th><td>${p.category || 'General'} · ${p.subcat || ''}</td></tr>
            <tr><th>Unidad de Empaque</th><td>${p.unit || 'Unidad'}</td></tr>
            <tr><th>Registro Sanitario INVIMA</th><td><strong style="color:#005091;">${p.invima || 'Registro Institucional Vigente'}</strong></td></tr>
            <tr><th>pH Certificado / Concentración</th><td>${(p.specs && p.specs.ph) || '7.0 – 8.0 (Neutro)'}</td></tr>
            <tr><th>Biodegradabilidad / Norma</th><td>${(p.specs && p.specs.bio) || '≥ 90% Biodegradable'}</td></tr>
            <tr><th>Componente / Material</th><td>${(p.specs && p.specs.comp) || 'Fórmula institucional certificada'}</td></tr>
            <tr><th>Uso Recomendado</th><td>${(p.specs && p.specs.uso) || 'Aseo y mantenimiento institucional'}</td></tr>
            <tr><th>Cumplimiento Normativo</th><td>Resolución 683/2012 INVIMA & Estándares B2B</td></tr>
          </table>

          <div class="guarantee-box">
            <strong style="color:#166534; font-size:12.5px;">✓ Respaldo de Distribuidor Mayorista</strong>
            <p style="font-size:11.5px; color:#15803d; margin-top:4px; line-height:1.4;">
              Producto garantizado con despacho en flota propia, facturación electrónica DIAN y soporte de posventa por Detalgraf S.A.S.
            </p>
          </div>

          <div class="footer">
            DetalShop Colombia · Bogotá D.C. · www.detalshop.com · PBX: (601) 745-0000 · contacto@detalgraf.com
          </div>
          <script>
            window.onload = function() {
              window.print();
            };
          <\/script>
        </body>
        </html>
      `);
      printWin.document.close();
    }


    // TRACKING SIMULATION
    
    // ========================================================================
    // BASE DE DATOS Y GESTIÓN DE RASTREO LOGÍSTICO (MES 2 — FIGMA + WIX CMS)
    // ========================================================================
    const TRACKING_ORDERS_DB = {
      "DTL-2026-8941": {
        guia: "DTL-2026-8941",
        factura: "Factura B2B #FE-8942",
        transportadora: "Envía / Flota Propia Detalgraf",
        destino: "Total Office SAS — Cra 45 # 108-20, Bogotá D.C.",
        step: 3,
        novedad: "En despacho hacia Bogotá D.C. con vehículo propio N° 4 · Conductor: Carlos Mendoza",
        dates: ["12 Jun · 08:30", "12 Jun · 10:15", "13 Jun · 07:45", "Hoy antes de 5:00 PM"],
        history: [
          { time: "Hoy · 07:45 AM", desc: "— En despacho hacia Bogotá D.C. (Vehículo Propio N° 4 - Conductor: Carlos Mendoza)", active: true },
          { time: "Ayer · 10:15 PM", desc: "— Recibido en centro de distribución y alistado para ruta de entrega", active: false },
          { time: "Ayer · 08:30 AM", desc: "— Pedido recibido y facturado con éxito (Factura B2B #FE-8942)", active: false }
        ]
      },
      "DTL-2026-1001": {
        guia: "DTL-2026-1001",
        factura: "Factura B2B #FE-8720",
        transportadora: "Flota Propia Detalgraf",
        destino: "Clínica del Country — Sede Chía, Cundinamarca",
        step: 4,
        novedad: "Entregado a satisfacción en recepción con firma de remisión física y sello institucional",
        dates: ["10 Jun · 09:00", "10 Jun · 14:00", "11 Jun · 08:00", "11 Jun · 16:30"],
        history: [
          { time: "11 Jun · 04:30 PM", desc: "— Entregado a satisfacción con firma de remisión física y sello institucional", active: true },
          { time: "11 Jun · 08:00 AM", desc: "— En ruta con conductor asignado Carlos Mendoza", active: false },
          { time: "10 Jun · 02:00 PM", desc: "— Paletizado y rotulado en bodega central Detalgraf", active: false },
          { time: "10 Jun · 09:00 AM", desc: "— Pedido confirmado y emitido por Gerencia", active: false }
        ]
      },
      "DTL-2026-9050": {
        guia: "DTL-2026-9050",
        factura: "Factura B2B #FE-9011",
        transportadora: "Flota Propia Detalgraf",
        destino: "Compensar B2B — Calle 26, Bogotá D.C.",
        step: 2,
        novedad: "Alistamiento de mercancía y empaque industrial en estibas",
        dates: ["Hoy · 09:15", "Hoy · 11:30", "Pendiente", "Pendiente"],
        history: [
          { time: "Hoy · 11:30 AM", desc: "— Mercancía en proceso de embalaje y paletizado en bodega central", active: true },
          { time: "Hoy · 09:15 AM", desc: "— Orden confirmada por Gerencia y asignada a bodega central", active: false }
        ]
      }
    };

    // Inicialmente nulo para que el usuario entre con pantalla limpia en cero
    let currentTrackOrder = null;

    function registerNewOrderInSystem(orderRecord) {
      if (!orderRecord || !orderRecord.guia) return;
      TRACKING_ORDERS_DB[orderRecord.guia] = orderRecord;
      if (orderRecord.orderNumber) {
        TRACKING_ORDERS_DB[orderRecord.orderNumber] = orderRecord;
        TRACKING_ORDERS_DB[orderRecord.orderNumber.replace('#', '')] = orderRecord;
      }

      try {
        let registry = [];
        const saved = localStorage.getItem('detal_active_orders_registry');
        if (saved) registry = JSON.parse(saved);
        registry = registry.filter(o => o.guia !== orderRecord.guia);
        registry.unshift(orderRecord);
        localStorage.setItem('detal_active_orders_registry', JSON.stringify(registry));
        localStorage.setItem('detal_last_order_guia', orderRecord.guia);
      } catch(e) {}

      saveTrackingOverrides();
      updateGerenteOrderDropdown();
    }

    function initOrdersRegistry() {
      // 1. Cargar órdenes de localStorage
      try {
        const saved = localStorage.getItem('detal_active_orders_registry');
        if (saved) {
          const list = JSON.parse(saved);
          list.forEach(ord => {
            TRACKING_ORDERS_DB[ord.guia] = ord;
            if (ord.orderNumber) {
              TRACKING_ORDERS_DB[ord.orderNumber] = ord;
              TRACKING_ORDERS_DB[ord.orderNumber.replace('#', '')] = ord;
            }
          });
        }
      } catch(e) {}

      // 2. Cargar órdenes reales del cliente autenticado en Shopify
      if (window.SHOPIFY_CUSTOMER && Array.isArray(window.SHOPIFY_CUSTOMER.orders)) {
        window.SHOPIFY_CUSTOMER.orders.forEach(so => {
          const guiaNumber = so.tracking_number || `DTL-2026-${so.order_number}`;
          const shopifyOrderRecord = {
            guia: guiaNumber,
            orderNumber: so.name || `#${so.order_number}`,
            factura: `Factura Electrónica DIAN #${so.order_number}`,
            transportadora: so.tracking_company || "Flota Propia Detalgraf",
            destino: `Destino Registrado en Shopify · Cliente: ${window.SHOPIFY_CUSTOMER.name || window.SHOPIFY_CUSTOMER.email}`,
            step: so.fulfillment_status === 'Cumplido' || so.fulfillment_status === 'Fulfilled' ? 4 : (so.fulfillment_status ? 3 : 2),
            novedad: `Pedido ${so.name} registrado en Shopify. Estado: ${so.financial_status || 'Aprobado'} / ${so.fulfillment_status || 'En preparación'}.`,
            dates: [so.created_at || "Reciente", "En Bodega Central", "En Tránsito", so.fulfillment_status === 'Cumplido' ? "Entregado" : "Estimado 24-48h"],
            history: [
              { time: so.created_at || "Reciente", desc: `— Pedido ${so.name} verificado en sistema. Guía: ${guiaNumber}`, active: true }
            ]
          };
          TRACKING_ORDERS_DB[guiaNumber] = shopifyOrderRecord;
          TRACKING_ORDERS_DB[so.name] = shopifyOrderRecord;
          TRACKING_ORDERS_DB[String(so.order_number)] = shopifyOrderRecord;
        });
      }

      loadTrackingOverrides();
      updateGerenteOrderDropdown();
    }

    // ========================================================================
    // UX DE SESIÓN DE ORGANIZACIÓN B2B PARA RASTREO
    // ========================================================================
    function isCustomerSessionActive() {
      if (window.SHOPIFY_CUSTOMER && window.SHOPIFY_CUSTOMER.id) return true;
      const savedSession = sessionStorage.getItem('detal_customer_session');
      return !!savedSession;
    }

    function getOrganizationData() {
      if (window.SHOPIFY_CUSTOMER && window.SHOPIFY_CUSTOMER.id) {
        return {
          name: window.SHOPIFY_CUSTOMER.name || window.SHOPIFY_CUSTOMER.email,
          email: window.SHOPIFY_CUSTOMER.email,
          nit: "Cliente Registrado Shopify",
          isShopify: true
        };
      }
      try {
        const saved = sessionStorage.getItem('detal_customer_session');
        if (saved) return JSON.parse(saved);
      } catch(e) {}
      return null;
    }

    function initTrackingSessionUI() {
      const authGate = document.getElementById('trackingAuthGate');
      const sessionBar = document.getElementById('trackingActiveSessionBar');
      const searchWrap = document.getElementById('trackingMainSearchWrapper');
      const orgNameEl = document.getElementById('trackingSessionOrgName');
      const notFoundCard = document.getElementById('trackingLookupError');
      const resultCard = document.getElementById('nqcTrackingResult');

      if (isCustomerSessionActive()) {
        const orgData = getOrganizationData();
        if (authGate) authGate.style.display = 'none';
        if (sessionBar) sessionBar.style.display = 'flex';
        if (searchWrap) searchWrap.style.display = 'block';

        if (orgNameEl && orgData) {
          orgNameEl.textContent = `${orgData.name} ${orgData.nit ? `· (${orgData.nit})` : ''}`;
        }

        renderCustomerRecentOrderPills();
      } else {
        if (authGate) authGate.style.display = 'block';
        if (sessionBar) sessionBar.style.display = 'none';
        if (searchWrap) searchWrap.style.display = 'none';
        if (notFoundCard) notFoundCard.style.display = 'none';
        if (resultCard) resultCard.style.display = 'none';
      }
    }

    function verifyOrganizationSession() {
      const nitInput = document.getElementById('authGateNit');
      const emailInput = document.getElementById('authGateEmail');
      const errEl = document.getElementById('authGateError');

      const nit = nitInput ? nitInput.value.trim() : '';
      const email = emailInput ? emailInput.value.trim() : '';

      if (!nit || nit.length < 5) {
        if (errEl) {
          errEl.textContent = '⚠️ Ingrese un NIT o documento de empresa válido.';
          errEl.style.display = 'block';
        }
        if (nitInput) nitInput.focus();
        return;
      }

      if (!email || !email.includes('@')) {
        if (errEl) {
          errEl.textContent = '⚠️ Ingrese un correo corporativo válido.';
          errEl.style.display = 'block';
        }
        if (emailInput) emailInput.focus();
        return;
      }

      if (errEl) errEl.style.display = 'none';

      const companyName = email.split('@')[0].replace(/[._-]/g, ' ').toUpperCase();
      const sessionData = {
        name: companyName,
        nit: nit,
        email: email,
        authenticated_at: new Date().toISOString()
      };

      sessionStorage.setItem('detal_customer_session', JSON.stringify(sessionData));
      initTrackingSessionUI();
      showToastNotification(1, `Organización ${companyName} autenticada con éxito`, 0, false);
    }

    function logoutOrganizationSession() {
      sessionStorage.removeItem('detal_customer_session');
      currentTrackOrder = null;
      clearTrackingSearch();
      initTrackingSessionUI();
      showToastNotification(1, 'Sesión de organización finalizada', 0, true);
    }

    function renderCustomerRecentOrderPills() {
      const wrap = document.getElementById('trackingRecentOrdersWrap');
      const pillsContainer = document.getElementById('trackingRecentOrdersPills');
      if (!wrap || !pillsContainer) return;

      const ordersToShow = [];

      // 1. Órdenes nativas de Shopify
      if (window.SHOPIFY_CUSTOMER && Array.isArray(window.SHOPIFY_CUSTOMER.orders)) {
        window.SHOPIFY_CUSTOMER.orders.slice(0, 4).forEach(so => {
          ordersToShow.push({
            label: so.name || `#${so.order_number}`,
            guia: so.tracking_number || `DTL-2026-${so.order_number}`
          });
        });
      }

      // 2. Órdenes registradas en este navegador
      try {
        const saved = localStorage.getItem('detal_active_orders_registry');
        if (saved) {
          const list = JSON.parse(saved);
          list.slice(0, 4).forEach(o => {
            if (!ordersToShow.some(x => x.guia === o.guia)) {
              ordersToShow.push({
                label: o.orderNumber ? `${o.orderNumber} (${o.guia})` : o.guia,
                guia: o.guia
              });
            }
          });
        }
      } catch(e) {}

      if (ordersToShow.length > 0) {
        wrap.style.display = 'flex';
        pillsContainer.innerHTML = ordersToShow.map(ord => `
          <button type="button" class="recent-order-pill" onclick="setAndTrackGuia('${ord.guia}')">
            📦 ${ord.label}
          </button>
        `).join('');
      } else {
        wrap.style.display = 'none';
      }
    }

    function renderTrackingOrder(order) {
      if (!order) return;
      currentTrackOrder = order;

      // Actualizar tags superiores
      const guiaTag = document.getElementById("nqcGuiaText");
      if (guiaTag) guiaTag.textContent = order.guia;
      const facturaTag = document.getElementById("nqcFacturaText");
      if (facturaTag) facturaTag.textContent = order.factura;
      const transTag = document.getElementById("nqcTransportadoraText");
      if (transTag) transTag.textContent = `Transportadora: ${order.transportadora}`;
      const destTag = document.getElementById("nqcDestinoText");
      if (destTag) destTag.textContent = order.destino;
      const gerGuiaTag = document.getElementById("gerenteActiveGuiaTag");
      if (gerGuiaTag) gerGuiaTag.textContent = order.guia;

      // Actualizar Status Badge
      const badge = document.getElementById("nqcStatusBadge");
      const statusText = document.getElementById("nqcStatusText");
      if (badge && statusText) {
        badge.className = "nqc-status-badge";
        if (order.step === 1) {
          badge.classList.add("nqc-badge-confirmed");
          statusText.textContent = "Pedido confirmado y facturado";
        } else if (order.step === 2) {
          badge.classList.add("nqc-badge-prep");
          statusText.textContent = "En preparación en bodega central";
        } else if (order.step === 3) {
          badge.classList.add("nqc-badge-transit");
          statusText.textContent = "Pedido en tránsito hacia destino";
        } else if (order.step === 4) {
          badge.classList.add("nqc-badge-delivered");
          statusText.textContent = "Pedido entregado a satisfacción";
        }
      }

      // Actualizar Fechas en los 4 pasos
      if (order.dates) {
        for (let i = 1; i <= 4; i++) {
          const dateEl = document.getElementById(`nqcStep${i}Date`);
          if (dateEl && order.dates[i - 1]) dateEl.textContent = order.dates[i - 1];
        }
      }

      // Actualizar Stepper visual (Círculos y Líneas)
      for (let s = 1; s <= 4; s++) {
        const stepEl = document.getElementById(`nqcStep${s}`);
        const circEl = document.getElementById(`nqcStepCirc${s}`);
        if (!stepEl || !circEl) continue;

        stepEl.className = "nqc-step";
        if (s < order.step) {
          stepEl.classList.add("completed");
          circEl.innerHTML = "✓";
        } else if (s === order.step) {
          if (s === 4) {
            stepEl.classList.add("completed");
            circEl.innerHTML = "✓";
          } else {
            stepEl.classList.add("active");
            circEl.innerHTML = '<div class="nqc-inner-active-dot"></div>';
          }
        } else {
          circEl.innerHTML = "";
        }
      }

      // Líneas de conexión
      for (let l = 1; l <= 3; l++) {
        const lineEl = document.getElementById(`nqcLine${l}`);
        if (!lineEl) continue;
        if (l < order.step) {
          lineEl.className = "nqc-step-line nqc-line-completed";
        } else {
          lineEl.className = "nqc-step-line";
        }
      }

      // Actualizar Historial Cronológico
      const histList = document.getElementById("nqcHistoryList");
      if (histList && order.history) {
        histList.innerHTML = order.history.map((h, idx) => `
          <li class="nqc-history-item ${idx === 0 ? 'nqc-item-active' : ''}">
            <span class="nqc-history-bullet"></span>
            <span class="nqc-history-time">${h.time}</span>
            <span class="nqc-history-desc">${h.desc}</span>
          </li>
        `).join('');
      }

      // Actualizar WhatsApp Link
      const waBtn = document.getElementById("nqcBtnWhatsappLogistic");
      if (waBtn) {
        const phone = "573001234567";
        const msg = encodeURIComponent(`Hola Detalgraf, requiero información sobre el despacho de mi orden con guía: ${order.guia} (Estado: ${statusText ? statusText.textContent : 'En curso'})`);
        waBtn.href = `https://wa.me/${phone}?text=${msg}`;
      }

      // Sincronizar botones del Panel de Gerente
      for (let g = 1; g <= 4; g++) {
        const btnG = document.getElementById(`btnGerenteStep${g}`);
        if (btnG) btnG.classList.toggle("active-step", g === order.step);
      }
      const novInput = document.getElementById("gerenteNovedadInput");
      if (novInput && order.novedad) novInput.value = order.novedad;
    }

    function doTrackingLookup() {
      const input = document.getElementById("nqcTrackingInput");
      const errCard = document.getElementById("trackingLookupError");
      const errMsgEl = document.getElementById("trackingLookupErrorMsg");
      const resCard = document.getElementById("nqcTrackingResult");

      if (!input) return;
      const rawVal = input.value.trim();
      if (!rawVal) {
        input.focus();
        return;
      }

      const val = rawVal.toUpperCase();
      const cleanVal = val.replace(/^#/, '');

      let matchedOrder = null;

      // 1. Búsqueda exacta en la base de datos de órdenes
      if (TRACKING_ORDERS_DB[val]) {
        matchedOrder = TRACKING_ORDERS_DB[val];
      } else if (TRACKING_ORDERS_DB[cleanVal]) {
        matchedOrder = TRACKING_ORDERS_DB[cleanVal];
      } else if (TRACKING_ORDERS_DB["DTL-2026-" + cleanVal]) {
        matchedOrder = TRACKING_ORDERS_DB["DTL-2026-" + cleanVal];
      } else {
        // 2. Búsqueda por número de guía o número de orden dentro de los registros
        const allOrders = Object.values(TRACKING_ORDERS_DB);
        matchedOrder = allOrders.find(o => 
          (o.guia && o.guia.toUpperCase() === val) ||
          (o.orderNumber && (o.orderNumber.toUpperCase() === val || o.orderNumber.replace('#','') === cleanVal))
        );
      }

      if (matchedOrder) {
        // Encontrado: Ocultar error y mostrar resultado en vivo
        if (errCard) errCard.style.display = "none";
        renderTrackingOrder(matchedOrder);
        if (resCard) {
          resCard.style.display = "block";
          resCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      } else {
        // No inventar guías inexistentes: Mostrar error claro con UX institucional
        if (resCard) resCard.style.display = "none";
        if (errCard) {
          if (errMsgEl) {
            errMsgEl.textContent = `El número de guía o pedido "${rawVal}" no se encuentra registrado en el sistema logístico. Verifique que coincida con su confirmación de compra o factura electrónica DIAN.`;
          }
          const waLink = document.getElementById('btnErrorWhatsapp');
          if (waLink) {
            waLink.href = `https://api.whatsapp.com/send?phone=573102388040&text=${encodeURIComponent(`Hola Detalgraf, requiero verificar el estado de mi pedido o guía: ${rawVal}`)}`;
          }
          errCard.style.display = "block";
          errCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    }

    function clearTrackingSearch() {
      const input = document.getElementById("nqcTrackingInput");
      if (input) input.value = "";
      const resCard = document.getElementById("nqcTrackingResult");
      if (resCard) resCard.style.display = "none";
      const errCard = document.getElementById("trackingLookupError");
      if (errCard) errCard.style.display = "none";
    }

    function setAndTrackGuia(guia) {
      const input = document.getElementById("nqcTrackingInput");
      if (input) input.value = guia;
      doTrackingLookup();
    }

    // ACCIONES DEL GERENTE EN WIX CMS
    function gerenteSetStep(newStep) {
      if (!currentTrackOrder) return;
      currentTrackOrder.step = newStep;

      const stepNames = ["Confirmado", "En Preparación", "En Tránsito (Ruta)", "Entregado"];
      const novInput = document.getElementById("gerenteNovedadInput");

      if (newStep === 1) {
        currentTrackOrder.novedad = "Orden recibida, pago validado y factura electrónica DIAN emitida";
      } else if (newStep === 2) {
        currentTrackOrder.novedad = "Mercancía paletizada y embalada en estibas por bodega central";
      } else if (newStep === 3) {
        currentTrackOrder.novedad = "En despacho hacia destino con vehículo propio N° 4 · Conductor: Carlos Mendoza";
      } else if (newStep === 4) {
        currentTrackOrder.novedad = "Entregado a satisfacción en recepción con firma de remisión y sello";
      }

      if (novInput) novInput.value = currentTrackOrder.novedad;

      // Actualizar el historial cronológico con la novedad del gerente
      const now = new Date();
      const timeStr = `Hoy · ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      currentTrackOrder.history.unshift({
        time: timeStr,
        desc: `— [GERENCIA] Estado actualizado a: ${stepNames[newStep - 1]} (${currentTrackOrder.novedad})`,
        active: true
      });
      // Asegurar que solo el primero quede activo
      currentTrackOrder.history.forEach((h, i) => h.active = (i === 0));

      renderTrackingOrder(currentTrackOrder);
      saveTrackingOverrides();
      showToastNotification(1, `Estado actualizado por Gerencia a "${stepNames[newStep - 1]}"`, 0, false);
    }

    function gerenteApplyUpdate() {
      const novInput = document.getElementById("gerenteNovedadInput");
      if (!novInput || !currentTrackOrder) return;
      const customNote = novInput.value.trim();
      if (!customNote) return;

      currentTrackOrder.novedad = customNote;
      const now = new Date();
      const timeStr = `Hoy · ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      currentTrackOrder.history.unshift({
        time: timeStr,
        desc: `— [GERENCIA] ${customNote}`,
        active: true
      });
      currentTrackOrder.history.forEach((h, i) => h.active = (i === 0));

      renderTrackingOrder(currentTrackOrder);
      saveTrackingOverrides();
      showToastNotification(1, `Novedad de Gerencia publicada en vivo`, 0, false);
    }


    function openIconModal() {
      const modal = document.getElementById('iconModalOverlay');
      if (modal) modal.classList.add('active');
    }
    function closeIconModal(e) {
      if (!e || e.target === document.getElementById('iconModalOverlay') || !e.target.closest || !e.target.closest('#iconModalOverlay > div') || e.target.tagName === 'BUTTON') {
        const modal = document.getElementById('iconModalOverlay');
        if (modal) modal.classList.remove('active');
      }
    }


    function cotizarWhatsApp() {
      if (!currentPdpProduct) return;
      const qtyInput = document.getElementById('pdpQtyInput');
      const qty = qtyInput ? qtyInput.value : 1;
      const text = encodeURIComponent(`Hola DetalShop, solicito cotización formal B2B para:\n• Producto: ${currentPdpProduct.title}\n• Cantidad: ${qty} unidades\n• SKU: ${currentPdpProduct.sku || ''}`);
      window.open(`https://api.whatsapp.com/send?phone=573102388040&text=${text}`, '_blank');
    }

    function trackingWhatsAppSupport() {
      const guia = currentTrackOrder ? currentTrackOrder.guia : 'DTL-2026-8941';
      const text = encodeURIComponent(`Hola soporte logístico DetalShop, requiero asistencia con mi guía de despacho institucional: ${guia}`);
      window.open(`https://api.whatsapp.com/send?phone=573102388040&text=${text}`, '_blank');
    }



    // ========================================================================
    // CONTROL DE ACCESO EXCLUSIVO PARA GERENCIA / ADMINISTRADOR
    // ========================================================================
    const GERENTE_ACCESS_PIN = "Tracking2026"; // PIN Oficial de Gerencia

    function updateGerenteOrderDropdown() {
      const select = document.getElementById('gerenteOrderSelector');
      if (!select) return;

      const uniqueOrders = [];
      const seen = new Set();
      Object.values(TRACKING_ORDERS_DB).forEach(ord => {
        if (ord && ord.guia && !seen.has(ord.guia)) {
          seen.add(ord.guia);
          uniqueOrders.push(ord);
        }
      });

      const currentVal = select.value;
      select.innerHTML = '<option value="">-- Seleccionar Guía o Pedido Registrado --</option>' +
        uniqueOrders.map(o => `
          <option value="${o.guia}" ${currentTrackOrder && currentTrackOrder.guia === o.guia ? 'selected' : ''}>
            ${o.guia} · ${o.orderNumber || ''} (${o.destino ? o.destino.slice(0, 35) + '...' : ''})
          </option>
        `).join('');

      if (currentVal && seen.has(currentVal)) {
        select.value = currentVal;
      }
    }

    function gerenteSelectOrderFromDropdown(guia) {
      if (!guia || !TRACKING_ORDERS_DB[guia]) return;
      const order = TRACKING_ORDERS_DB[guia];
      renderTrackingOrder(order);
      const resCard = document.getElementById("nqcTrackingResult");
      if (resCard) resCard.style.display = "block";
      showToastNotification(1, `Orden ${order.guia} seleccionada en panel de Gerencia`, 0, false);
    }

    function saveTrackingOverrides() {
      try {
        localStorage.setItem('detal_tracking_overrides', JSON.stringify(TRACKING_ORDERS_DB));
      } catch(e) {}
    }

    function loadTrackingOverrides() {
      try {
        const saved = localStorage.getItem('detal_tracking_overrides');
        if (saved) {
          const parsed = JSON.parse(saved);
          Object.assign(TRACKING_ORDERS_DB, parsed);
        }
      } catch(e) {}
    }

    function checkGerenteAuth() {
      const isAuth = sessionStorage.getItem('detal_gerente_auth') === 'true';
      const urlParams = new URLSearchParams(window.location.search);
      const adminParam = urlParams.get('admin') || urlParams.get('gerente');
      
      const panel = document.getElementById('gerenteControlPanel');
      const trigger = document.getElementById('gerenteAuthTriggerWrap');

      if (isAuth || adminParam === '1' || adminParam === '2026') {
        sessionStorage.setItem('detal_gerente_auth', 'true');
        if (panel) panel.style.display = 'block';
        if (trigger) {
          trigger.innerHTML = `
            <div style="display: inline-flex; align-items: center; gap: 8px; background: #ecfdf5; border: 1.5px solid #6ee7b7; padding: 6px 14px; border-radius: 9999px;">
              <span style="font-size: 11.5px; font-weight: 800; color: #065f46;">👑 Sesión de Gerencia Activa (Solo visible para ti)</span>
              <button type="button" onclick="logoutGerente()" style="background: none; border: none; font-size: 11.5px; font-weight: 700; color: #dc2626; cursor: pointer; text-decoration: underline;">
                Cerrar Sesión ✕
              </button>
            </div>
          `;
        }
      } else {
        if (panel) panel.style.display = 'none';
        if (trigger) {
          trigger.innerHTML = `
            <button type="button" onclick="openGerenteAuthModal()" style="background: none; border: none; font-size: 11.5px; color: #64748b; cursor: pointer; text-decoration: underline; display: inline-flex; align-items: center; gap: 5px;">
              🔒 Acceso Gerencia (Actualizar Estados de Despacho)
            </button>
          `;
        }
      }
    }

    function openGerenteAuthModal() {
      const modal = document.getElementById('gerenteAuthModal');
      if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('active');
        const pinInput = document.getElementById('inputGerentePin');
        if (pinInput) {
          pinInput.value = '';
          setTimeout(() => pinInput.focus(), 100);
        }
        const err = document.getElementById('gerentePinError');
        if (err) err.style.display = 'none';
      }
    }

    function closeGerenteAuthModal(e) {
      if (!e || e.target === document.getElementById('gerenteAuthModal') || (e.target && e.target.classList.contains('btn-modal-close-pin'))) {
        const modal = document.getElementById('gerenteAuthModal');
        if (modal) {
          modal.style.display = 'none';
          modal.classList.remove('active');
        }
      }
    }

    function verifyGerentePin() {
      const pinInput = document.getElementById('inputGerentePin');
      const err = document.getElementById('gerentePinError');
      const enteredPin = pinInput ? pinInput.value.trim() : '';

      if (enteredPin === GERENTE_ACCESS_PIN || enteredPin.toLowerCase() === 'tracking2026') {
        sessionStorage.setItem('detal_gerente_auth', 'true');
        closeGerenteAuthModal();
        checkGerenteAuth();
        updateGerenteOrderDropdown();
        showToastNotification(1, 'Panel Gerencial desbloqueado con éxito (PIN Verificado)', 0, false);
      } else {
        if (err) err.style.display = 'block';
      }
    }

    function logoutGerente() {
      sessionStorage.removeItem('detal_gerente_auth');
      checkGerenteAuth();
      showToastNotification(1, 'Sesión de Gerencia cerrada con éxito', 0, true);
    }


    // Inicialización automática de persistencia y sesión de Gerencia
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => {
        loadTrackingOverrides();
        checkGerenteAuth();
      });
    } else {
      loadTrackingOverrides();
      checkGerenteAuth();
    }


    // EXPOSICIÓN GLOBAL DE FUNCIONES EN WINDOW (PARA EVENT HANDLERS EN LÍNEA)
    
    // MODAL ¿QUIÉNES SOMOS?
    function openQuienesSomosModal() {
      const modal = document.getElementById('quienesSomosModal');
      if (modal) {
        modal.style.setProperty('display', 'flex', 'important');
        modal.classList.add('active');
      }
    }
    window.openQuienesSomosModal = openQuienesSomosModal;

    function closeQuienesSomosModal(e) {
      if (!e || e.target === document.getElementById('quienesSomosModal') || (e.target.closest && e.target.closest('.btn-close-quienes')) || (e.target.tagName === 'BUTTON' && e.target.textContent.includes('Entendido'))) {
        const modal = document.getElementById('quienesSomosModal');
        if (modal) {
          modal.style.setProperty('display', 'none', 'important');
          modal.classList.remove('active');
        }
      }
    }
    window.closeQuienesSomosModal = closeQuienesSomosModal;

    window.openCartDrawer = openCartDrawer;
    window.closeCartDrawer = closeCartDrawer;
    window.addToCart = addToCart;
    window.removeFromCart = removeFromCart;
    window.removeCartItem = removeCartItem;
    window.updateCartItemQty = updateCartItemQty;
    window.changeCardQty = changeCardQty;
    window.handleCardQtyDirectChange = handleCardQtyDirectChange;
    window.addCardQtyToCart = addCardQtyToCart;
    window.setAndAddQty = setAndAddQty;
    window.setCartZone = setCartZone;
    window.proceedCheckoutFigma = proceedCheckoutFigma;
    window.switchView = switchView;
    window.filterHomeCatalog = filterHomeCatalog;
    window.handleCatalogSearch = handleCatalogSearch;
    window.clearCatalogSearch = clearCatalogSearch;
    window.doTrackingLookup = doTrackingLookup;
    window.setAndTrackGuia = setAndTrackGuia;
    window.gerenteSetStep = gerenteSetStep;
    window.gerenteApplyUpdate = gerenteApplyUpdate;
    window.openGerenteAuthModal = openGerenteAuthModal;
    window.closeGerenteAuthModal = closeGerenteAuthModal;
    window.verifyGerentePin = verifyGerentePin;
    window.logoutGerente = logoutGerente;
    window.openPdpWithProduct = openPdpWithProduct;
    window.openPdfModal = openPdfModal;
    window.closePdfModal = closePdfModal;
    window.downloadOrPrintPdf = downloadOrPrintPdf;
    window.openIconModal = openIconModal;
    window.closeIconModal = closeIconModal;

    // VINCULACIÓN GLOBAL DE TODOS LOS BOTONES DE CARRITO DE LA TIENDA
    document.addEventListener('click', function(e) {
      const cartTrigger = e.target.closest('.cart-link, .js-drawer-open-button-right, .btn-sticky-open-cart, .btn-toast-view, a[href="/cart"], .header-icon-action[title="Carrito"]');
      if (cartTrigger) {
        e.preventDefault();
        openCartDrawer();
      }
    });

    // ENRUTAMIENTO POR HASH (#tracking, #track, #home)
    function handleHashNavigation() {
      const hash = window.location.hash.toLowerCase();
      if (hash === '#tracking' || hash === '#track' || hash === '#viewtrack') {
        if (typeof switchView === 'function') switchView('track');
      } else if (hash === '#home' || hash === '#inicio' || hash === '#viewhome') {
        if (typeof switchView === 'function') switchView('home');
      }
    }
    window.addEventListener('hashchange', handleHashNavigation);
    window.addEventListener('load', handleHashNavigation);

    window.loadMoreProducts = loadMoreProducts;

    // VINCULACIÓN DE LA BARRA DE MENÚ Y ENLACES GLOBALES CON LA NUEVA INTERFAZ REACTIVA
    document.addEventListener('click', function(e) {
      const link = e.target.closest('a');
      if (!link) return;

      const href = (link.getAttribute('href') || '').toLowerCase().trim();
      const text = (link.textContent || '').toLowerCase().trim();

      // Cerrar menú móvil si está abierto al interactuar
      function maybeCloseMobileNav() {
        if (window.timber && window.timber.LeftDrawer && typeof window.timber.LeftDrawer.close === 'function') {
          window.timber.LeftDrawer.close();
        }
        const navDrawer = document.getElementById('NavDrawer');
        if (navDrawer && navDrawer.classList.contains('is-open')) {
          const closeBtn = navDrawer.querySelector('.drawer__close-button');
          if (closeBtn) closeBtn.click();
        }
      }

      // 1. Quiénes Somos (Modal)
      if (text.includes('quiénes somos') || text.includes('quienes somos') || href.includes('quienes-somos')) {
        e.preventDefault();
        maybeCloseMobileNav();
        openQuienesSomosModal();
        return;
      }

      // 2. Rastrear Pedido / Tracking
      if (text.includes('tracking') || text.includes('rastrear') || text.includes('rastreo') || text.includes('seguimiento') || href.includes('tracking') || href.includes('#track')) {
        e.preventDefault();
        maybeCloseMobileNav();
        switchView('track');
        return;
      }

      // 3. Inicio / Home
      if (href === '/' || href === '#home' || href === '#inicio' || text === 'inicio' || text === 'home') {
        if (document.getElementById('viewHome')) {
          e.preventDefault();
          maybeCloseMobileNav();
          switchView('home');
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return;
        }
      }

      // 4. Categorías / Líneas de productos vinculadas con el catálogo interactivo
      if (document.getElementById('catalogSection')) {
        if (text.includes('aseo') || href.includes('/aseo') || href.includes('linea-aseo')) {
          e.preventDefault();
          maybeCloseMobileNav();
          switchView('home');
          filterHomeCatalog('Aseo');
          scrollToCatalog();
          return;
        }
        if (text.includes('seguridad') || text.includes('bioseguridad') || href.includes('/seguridad') || href.includes('/bioseguridad')) {
          e.preventDefault();
          maybeCloseMobileNav();
          switchView('home');
          filterHomeCatalog('Seguridad');
          scrollToCatalog();
          return;
        }
        if (text.includes('cafetería') || text.includes('cafeteria') || href.includes('/cafeteria')) {
          e.preventDefault();
          maybeCloseMobileNav();
          switchView('home');
          filterHomeCatalog('Cafeteria');
          scrollToCatalog();
          return;
        }
        if (text.includes('papelería') || text.includes('papeleria') || href.includes('/papeleria')) {
          e.preventDefault();
          maybeCloseMobileNav();
          switchView('home');
          filterHomeCatalog('Papeleria');
          scrollToCatalog();
          return;
        }
        if (text.includes('químicos') || text.includes('quimicos') || href.includes('/quimicos')) {
          e.preventDefault();
          maybeCloseMobileNav();
          switchView('home');
          filterHomeCatalog('Quimicos');
          scrollToCatalog();
          return;
        }
        if (text.includes('catálogo') || text.includes('catalogo') || text.includes('todas las líneas') || text.includes('productos') || href.includes('/collections/all')) {
          e.preventDefault();
          maybeCloseMobileNav();
          switchView('home');
          filterHomeCatalog('Todos');
          scrollToCatalog();
          return;
        }
      }
    });

    // SOPORTE DEL BOTÓN DE RETORNO NATIVO DEL NAVEGADOR (POPSTATE)
    window.addEventListener('popstate', function(e) {
      if (e.state && e.state.view === 'pdp' && e.state.productId) {
        populatePdpData(e.state.productId);
        document.querySelectorAll('.page-view-block').forEach(el => el.classList.remove('active'));
        var vp = document.getElementById('viewPdp'); if (vp) vp.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else if (e.state && (e.state.view === 'track' || e.state.view === 'tracking')) {
        document.querySelectorAll('.page-view-block').forEach(el => el.classList.remove('active'));
        var vt = document.getElementById('viewTrack'); if (vt) vt.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        document.querySelectorAll('.page-view-block').forEach(el => el.classList.remove('active'));
        var vh = document.getElementById('viewHome'); if (vh) vh.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });

    // INICIALIZAR CATÁLOGO Y PROCESAR PARÁMETROS URL CUANDO EL DOM ESTÉ LISTO
    document.addEventListener('DOMContentLoaded', function() {
      if (typeof renderCatalog === 'function') {
        renderCatalog(true);
      }
      if (typeof updateCartUI === 'function') {
        updateCartUI();
      }
      if (typeof populatePdpData === 'function' && typeof PRODUCTS_DATA !== 'undefined' && PRODUCTS_DATA.length > 0) {
        populatePdpData(PRODUCTS_DATA[0].id);
      }

      // Parámetros de URL para navegación integrada
      try {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('openCart') === '1' || window.location.hash === '#cart') {
          setTimeout(openCartDrawer, 350);
        }
        const pdpParam = urlParams.get('pdp') || urlParams.get('product');
        if (pdpParam) {
          setTimeout(function() {
            openPdpWithProduct(pdpParam);
          }, 300);
        }
        const colParam = urlParams.get('collection');
        if (colParam && typeof filterHomeCatalog === 'function') {
          setTimeout(function() {
            filterHomeCatalog(colParam);
            scrollToCatalog();
          }, 300);
        }
      } catch(e) {}
    });
